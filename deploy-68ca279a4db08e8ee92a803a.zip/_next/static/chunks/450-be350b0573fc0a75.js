"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [450], {
        3635: (t, e, i) => {
            i.d(e, {
                useDrag: () => Y
            });
            let n = {
                toVector: (t, e) => (void 0 === t && (t = e), Array.isArray(t) ? t : [t, t]),
                add: (t, e) => [t[0] + e[0], t[1] + e[1]],
                sub: (t, e) => [t[0] - e[0], t[1] - e[1]],
                addTo(t, e) {
                    t[0] += e[0], t[1] += e[1]
                },
                subTo(t, e) {
                    t[0] -= e[0], t[1] -= e[1]
                }
            };

            function r(t, e, i) {
                return 0 === e || Math.abs(e) === 1 / 0 ? Math.pow(t, 5 * i) : t * e * i / (e + i * t)
            }

            function s(t, e, i, n = .15) {
                return 0 === n ? Math.max(e, Math.min(t, i)) : t < e ? -r(e - t, i - e, n) + e : t > i ? +r(t - i, i - e, n) + i : t
            }

            function o(t, e, i) {
                var n;
                return (e = "symbol" == typeof(n = function(t, e) {
                    if ("object" != typeof t || null === t) return t;
                    var i = t[Symbol.toPrimitive];
                    if (void 0 !== i) {
                        var n = i.call(t, e || "default");
                        if ("object" != typeof n) return n;
                        throw TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === e ? String : Number)(t)
                }(e, "string")) ? n : String(n)) in t ? Object.defineProperty(t, e, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = i, t
            }

            function a(t, e) {
                var i = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    })), i.push.apply(i, n)
                }
                return i
            }

            function l(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? a(Object(i), !0).forEach(function(e) {
                        o(t, e, i[e])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : a(Object(i)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e))
                    })
                }
                return t
            }
            let u = {
                pointer: {
                    start: "down",
                    change: "move",
                    end: "up"
                },
                mouse: {
                    start: "down",
                    change: "move",
                    end: "up"
                },
                touch: {
                    start: "start",
                    change: "move",
                    end: "end"
                },
                gesture: {
                    start: "start",
                    change: "change",
                    end: "end"
                }
            };

            function h(t) {
                return t ? t[0].toUpperCase() + t.slice(1) : ""
            }
            let d = ["enter", "leave"],
                c = ["gotpointercapture", "lostpointercapture"];

            function p(t) {
                return "touches" in t
            }

            function m(t) {
                return p(t) ? "touch" : "pointerType" in t ? t.pointerType : "mouse"
            }

            function f(t) {
                return p(t) ? ("touchend" === t.type || "touchcancel" === t.type ? t.changedTouches : t.targetTouches)[0] : t
            }

            function v(t) {
                let e = f(t);
                return p(t) ? e.identifier : e.pointerId
            }

            function g(t) {
                let e = f(t);
                return [e.clientX, e.clientY]
            }

            function y(t, ...e) {
                return "function" == typeof t ? t(...e) : t
            }

            function x() {}

            function b(t, e) {
                return Object.assign({}, e, t || {})
            }
            class w {
                constructor(t, e, i) {
                    this.ctrl = t, this.args = e, this.key = i, this.state || (this.state = {}, this.computeValues([0, 0]), this.computeInitial(), this.init && this.init(), this.reset())
                }
                get state() {
                    return this.ctrl.state[this.key]
                }
                set state(t) {
                    this.ctrl.state[this.key] = t
                }
                get shared() {
                    return this.ctrl.state.shared
                }
                get eventStore() {
                    return this.ctrl.gestureEventStores[this.key]
                }
                get timeoutStore() {
                    return this.ctrl.gestureTimeoutStores[this.key]
                }
                get config() {
                    return this.ctrl.config[this.key]
                }
                get sharedConfig() {
                    return this.ctrl.config.shared
                }
                get handler() {
                    return this.ctrl.handlers[this.key]
                }
                reset() {
                    let {
                        state: t,
                        shared: e,
                        ingKey: i,
                        args: n
                    } = this;
                    e[i] = t._active = t.active = t._blocked = t._force = !1, t._step = [!1, !1], t.intentional = !1, t._movement = [0, 0], t._distance = [0, 0], t._direction = [0, 0], t._delta = [0, 0], t._bounds = [
                        [-1 / 0, 1 / 0],
                        [-1 / 0, 1 / 0]
                    ], t.args = n, t.axis = void 0, t.memo = void 0, t.elapsedTime = t.timeDelta = 0, t.direction = [0, 0], t.distance = [0, 0], t.overflow = [0, 0], t._movementBound = [!1, !1], t.velocity = [0, 0], t.movement = [0, 0], t.delta = [0, 0], t.timeStamp = 0
                }
                start(t) {
                    let e = this.state,
                        i = this.config;
                    e._active || (this.reset(), this.computeInitial(), e._active = !0, e.target = t.target, e.currentTarget = t.currentTarget, e.lastOffset = i.from ? y(i.from, e) : e.offset, e.offset = e.lastOffset, e.startTime = e.timeStamp = t.timeStamp)
                }
                computeValues(t) {
                    let e = this.state;
                    e._values = t, e.values = this.config.transform(t)
                }
                computeInitial() {
                    let t = this.state;
                    t._initial = t._values, t.initial = t.values
                }
                compute(t) {
                    let {
                        state: e,
                        config: i,
                        shared: r
                    } = this;
                    e.args = this.args;
                    let o = 0;
                    if (t && (e.event = t, i.preventDefault && t.cancelable && e.event.preventDefault(), e.type = t.type, r.touches = this.ctrl.pointerIds.size || this.ctrl.touchIds.size, r.locked = !!document.pointerLockElement, Object.assign(r, function(t) {
                            let e = {};
                            if ("buttons" in t && (e.buttons = t.buttons), "shiftKey" in t) {
                                let {
                                    shiftKey: i,
                                    altKey: n,
                                    metaKey: r,
                                    ctrlKey: s
                                } = t;
                                Object.assign(e, {
                                    shiftKey: i,
                                    altKey: n,
                                    metaKey: r,
                                    ctrlKey: s
                                })
                            }
                            return e
                        }(t)), r.down = r.pressed = r.buttons % 2 == 1 || r.touches > 0, o = t.timeStamp - e.timeStamp, e.timeStamp = t.timeStamp, e.elapsedTime = e.timeStamp - e.startTime), e._active) {
                        let t = e._delta.map(Math.abs);
                        n.addTo(e._distance, t)
                    }
                    this.axisIntent && this.axisIntent(t);
                    let [a, l] = e._movement, [u, h] = i.threshold, {
                        _step: d,
                        values: c
                    } = e;
                    if (i.hasCustomTransform ? (!1 === d[0] && (d[0] = Math.abs(a) >= u && c[0]), !1 === d[1] && (d[1] = Math.abs(l) >= h && c[1])) : (!1 === d[0] && (d[0] = Math.abs(a) >= u && Math.sign(a) * u), !1 === d[1] && (d[1] = Math.abs(l) >= h && Math.sign(l) * h)), e.intentional = !1 !== d[0] || !1 !== d[1], !e.intentional) return;
                    let p = [0, 0];
                    if (i.hasCustomTransform) {
                        let [t, e] = c;
                        p[0] = !1 !== d[0] ? t - d[0] : 0, p[1] = !1 !== d[1] ? e - d[1] : 0
                    } else p[0] = !1 !== d[0] ? a - d[0] : 0, p[1] = !1 !== d[1] ? l - d[1] : 0;
                    this.restrictToAxis && !e._blocked && this.restrictToAxis(p);
                    let m = e.offset,
                        f = e._active && !e._blocked || e.active;
                    f && (e.first = e._active && !e.active, e.last = !e._active && e.active, e.active = r[this.ingKey] = e._active, t && (e.first && ("bounds" in i && (e._bounds = y(i.bounds, e)), this.setup && this.setup()), e.movement = p, this.computeOffset()));
                    let [v, g] = e.offset, [
                        [x, b],
                        [w, P]
                    ] = e._bounds;
                    e.overflow = [v < x ? -1 : v > b ? 1 : 0, g < w ? -1 : g > P ? 1 : 0], e._movementBound[0] = !!e.overflow[0] && (!1 === e._movementBound[0] ? e._movement[0] : e._movementBound[0]), e._movementBound[1] = !!e.overflow[1] && (!1 === e._movementBound[1] ? e._movement[1] : e._movementBound[1]);
                    let S = e._active && i.rubberband || [0, 0];
                    if (e.offset = function(t, [e, i], [n, r]) {
                            let [
                                [o, a],
                                [l, u]
                            ] = t;
                            return [s(e, o, a, n), s(i, l, u, r)]
                        }(e._bounds, e.offset, S), e.delta = n.sub(e.offset, m), this.computeMovement(), f && (!e.last || o > 32)) {
                        e.delta = n.sub(e.offset, m);
                        let t = e.delta.map(Math.abs);
                        n.addTo(e.distance, t), e.direction = e.delta.map(Math.sign), e._direction = e._delta.map(Math.sign), !e.first && o > 0 && (e.velocity = [t[0] / o, t[1] / o], e.timeDelta = o)
                    }
                }
                emit() {
                    let t = this.state,
                        e = this.shared,
                        i = this.config;
                    if (t._active || this.clean(), (t._blocked || !t.intentional) && !t._force && !i.triggerAllEvents) return;
                    let n = this.handler(l(l(l({}, e), t), {}, {
                        [this.aliasKey]: t.values
                    }));
                    void 0 !== n && (t.memo = n)
                }
                clean() {
                    this.eventStore.clean(), this.timeoutStore.clean()
                }
            }
            class P extends w {
                constructor(...t) {
                    super(...t), o(this, "aliasKey", "xy")
                }
                reset() {
                    super.reset(), this.state.axis = void 0
                }
                init() {
                    this.state.offset = [0, 0], this.state.lastOffset = [0, 0]
                }
                computeOffset() {
                    this.state.offset = n.add(this.state.lastOffset, this.state.movement)
                }
                computeMovement() {
                    this.state.movement = n.sub(this.state.offset, this.state.lastOffset)
                }
                axisIntent(t) {
                    let e = this.state,
                        i = this.config;
                    if (!e.axis && t) {
                        let n = "object" == typeof i.axisThreshold ? i.axisThreshold[m(t)] : i.axisThreshold;
                        e.axis = function([t, e], i) {
                            let n = Math.abs(t),
                                r = Math.abs(e);
                            return n > r && n > i ? "x" : r > n && r > i ? "y" : void 0
                        }(e._movement, n)
                    }
                    e._blocked = (i.lockDirection || !!i.axis) && !e.axis || !!i.axis && i.axis !== e.axis
                }
                restrictToAxis(t) {
                    if (this.config.axis || this.config.lockDirection) switch (this.state.axis) {
                        case "x":
                            t[1] = 0;
                            break;
                        case "y":
                            t[0] = 0
                    }
                }
            }
            let S = t => t,
                T = {
                    enabled: (t = !0) => t,
                    eventOptions: (t, e, i) => l(l({}, i.shared.eventOptions), t),
                    preventDefault: (t = !1) => t,
                    triggerAllEvents: (t = !1) => t,
                    rubberband(t = 0) {
                        switch (t) {
                            case !0:
                                return [.15, .15];
                            case !1:
                                return [0, 0];
                            default:
                                return n.toVector(t)
                        }
                    },
                    from: t => "function" == typeof t ? t : null != t ? n.toVector(t) : void 0,
                    transform(t, e, i) {
                        let n = t || i.shared.transform;
                        return this.hasCustomTransform = !!n, n || S
                    },
                    threshold: t => n.toVector(t, 0)
                },
                A = 0,
                M = l(l({}, T), {}, {
                    axis(t, e, {
                        axis: i
                    }) {
                        if (this.lockDirection = "lock" === i, !this.lockDirection) return i
                    },
                    axisThreshold: (t = A) => t,
                    bounds(t = {}) {
                        if ("function" == typeof t) return e => M.bounds(t(e));
                        if ("current" in t) return () => t.current;
                        if ("function" == typeof HTMLElement && t instanceof HTMLElement) return t;
                        let {
                            left: e = -1 / 0,
                            right: i = 1 / 0,
                            top: n = -1 / 0,
                            bottom: r = 1 / 0
                        } = t;
                        return [
                            [e, i],
                            [n, r]
                        ]
                    }
                }),
                E = {
                    ArrowRight: (t, e = 1) => [t * e, 0],
                    ArrowLeft: (t, e = 1) => [-1 * t * e, 0],
                    ArrowUp: (t, e = 1) => [0, -1 * t * e],
                    ArrowDown: (t, e = 1) => [0, t * e]
                };
            class C extends P {
                constructor(...t) {
                    super(...t), o(this, "ingKey", "dragging")
                }
                reset() {
                    super.reset();
                    let t = this.state;
                    t._pointerId = void 0, t._pointerActive = !1, t._keyboardActive = !1, t._preventScroll = !1, t._delayed = !1, t.swipe = [0, 0], t.tap = !1, t.canceled = !1, t.cancel = this.cancel.bind(this)
                }
                setup() {
                    let t = this.state;
                    if (t._bounds instanceof HTMLElement) {
                        let e = t._bounds.getBoundingClientRect(),
                            i = t.currentTarget.getBoundingClientRect(),
                            n = {
                                left: e.left - i.left + t.offset[0],
                                right: e.right - i.right + t.offset[0],
                                top: e.top - i.top + t.offset[1],
                                bottom: e.bottom - i.bottom + t.offset[1]
                            };
                        t._bounds = M.bounds(n)
                    }
                }
                cancel() {
                    let t = this.state;
                    t.canceled || (t.canceled = !0, t._active = !1, setTimeout(() => {
                        this.compute(), this.emit()
                    }, 0))
                }
                setActive() {
                    this.state._active = this.state._pointerActive || this.state._keyboardActive
                }
                clean() {
                    this.pointerClean(), this.state._pointerActive = !1, this.state._keyboardActive = !1, super.clean()
                }
                pointerDown(t) {
                    let e = this.config,
                        i = this.state;
                    if (null != t.buttons && (Array.isArray(e.pointerButtons) ? !e.pointerButtons.includes(t.buttons) : -1 !== e.pointerButtons && e.pointerButtons !== t.buttons)) return;
                    let n = this.ctrl.setEventIds(t);
                    e.pointerCapture && t.target.setPointerCapture(t.pointerId), n && n.size > 1 && i._pointerActive || (this.start(t), this.setupPointer(t), i._pointerId = v(t), i._pointerActive = !0, this.computeValues(g(t)), this.computeInitial(), e.preventScrollAxis && "mouse" !== m(t) ? (i._active = !1, this.setupScrollPrevention(t)) : e.delay > 0 ? (this.setupDelayTrigger(t), e.triggerAllEvents && (this.compute(t), this.emit())) : this.startPointerDrag(t))
                }
                startPointerDrag(t) {
                    let e = this.state;
                    e._active = !0, e._preventScroll = !0, e._delayed = !1, this.compute(t), this.emit()
                }
                pointerMove(t) {
                    let e = this.state,
                        i = this.config;
                    if (!e._pointerActive) return;
                    let r = v(t);
                    if (void 0 !== e._pointerId && r !== e._pointerId) return;
                    let s = g(t);
                    if (document.pointerLockElement === t.target ? e._delta = [t.movementX, t.movementY] : (e._delta = n.sub(s, e._values), this.computeValues(s)), n.addTo(e._movement, e._delta), this.compute(t), e._delayed && e.intentional) {
                        this.timeoutStore.remove("dragDelay"), e.active = !1, this.startPointerDrag(t);
                        return
                    }
                    if (i.preventScrollAxis && !e._preventScroll) {
                        if (!e.axis) return;
                        if (e.axis === i.preventScrollAxis || "xy" === i.preventScrollAxis) {
                            e._active = !1, this.clean();
                            return
                        }
                        this.timeoutStore.remove("startPointerDrag"), this.startPointerDrag(t);
                        return
                    }
                    this.emit()
                }
                pointerUp(t) {
                    this.ctrl.setEventIds(t);
                    try {
                        this.config.pointerCapture && t.target.hasPointerCapture(t.pointerId) && t.target.releasePointerCapture(t.pointerId)
                    } catch (t) {}
                    let e = this.state,
                        i = this.config;
                    if (!e._active || !e._pointerActive) return;
                    let n = v(t);
                    if (void 0 !== e._pointerId && n !== e._pointerId) return;
                    this.state._pointerActive = !1, this.setActive(), this.compute(t);
                    let [r, s] = e._distance;
                    if (e.tap = r <= i.tapsThreshold && s <= i.tapsThreshold, e.tap && i.filterTaps) e._force = !0;
                    else {
                        let [t, n] = e._delta, [r, s] = e._movement, [o, a] = i.swipe.velocity, [l, u] = i.swipe.distance, h = i.swipe.duration;
                        if (e.elapsedTime < h) {
                            let i = Math.abs(t / e.timeDelta),
                                h = Math.abs(n / e.timeDelta);
                            i > o && Math.abs(r) > l && (e.swipe[0] = Math.sign(t)), h > a && Math.abs(s) > u && (e.swipe[1] = Math.sign(n))
                        }
                    }
                    this.emit()
                }
                pointerClick(t) {
                    !this.state.tap && t.detail > 0 && (t.preventDefault(), t.stopPropagation())
                }
                setupPointer(t) {
                    let e = this.config,
                        i = e.device;
                    e.pointerLock && t.currentTarget.requestPointerLock(), e.pointerCapture || (this.eventStore.add(this.sharedConfig.window, i, "change", this.pointerMove.bind(this)), this.eventStore.add(this.sharedConfig.window, i, "end", this.pointerUp.bind(this)), this.eventStore.add(this.sharedConfig.window, i, "cancel", this.pointerUp.bind(this)))
                }
                pointerClean() {
                    this.config.pointerLock && document.pointerLockElement === this.state.currentTarget && document.exitPointerLock()
                }
                preventScroll(t) {
                    this.state._preventScroll && t.cancelable && t.preventDefault()
                }
                setupScrollPrevention(t) {
                    this.state._preventScroll = !1, "persist" in t && "function" == typeof t.persist && t.persist();
                    let e = this.eventStore.add(this.sharedConfig.window, "touch", "change", this.preventScroll.bind(this), {
                        passive: !1
                    });
                    this.eventStore.add(this.sharedConfig.window, "touch", "end", e), this.eventStore.add(this.sharedConfig.window, "touch", "cancel", e), this.timeoutStore.add("startPointerDrag", this.startPointerDrag.bind(this), this.config.preventScrollDelay, t)
                }
                setupDelayTrigger(t) {
                    this.state._delayed = !0, this.timeoutStore.add("dragDelay", () => {
                        this.state._step = [0, 0], this.startPointerDrag(t)
                    }, this.config.delay)
                }
                keyDown(t) {
                    let e = E[t.key];
                    if (e) {
                        let i = this.state,
                            r = t.shiftKey ? 10 : t.altKey ? .1 : 1;
                        this.start(t), i._delta = e(this.config.keyboardDisplacement, r), i._keyboardActive = !0, n.addTo(i._movement, i._delta), this.compute(t), this.emit()
                    }
                }
                keyUp(t) {
                    t.key in E && (this.state._keyboardActive = !1, this.setActive(), this.compute(t), this.emit())
                }
                bind(t) {
                    let e = this.config.device;
                    t(e, "start", this.pointerDown.bind(this)), this.config.pointerCapture && (t(e, "change", this.pointerMove.bind(this)), t(e, "end", this.pointerUp.bind(this)), t(e, "cancel", this.pointerUp.bind(this)), t("lostPointerCapture", "", this.pointerUp.bind(this))), this.config.keys && (t("key", "down", this.keyDown.bind(this)), t("key", "up", this.keyUp.bind(this))), this.config.filterTaps && t("click", "", this.pointerClick.bind(this), {
                        capture: !0,
                        passive: !1
                    })
                }
            }
            let k = "undefined" != typeof window && window.document && window.document.createElement;

            function D() {
                return k && "ontouchstart" in window
            }
            let V = {
                    isBrowser: k,
                    gesture: function() {
                        try {
                            return "constructor" in GestureEvent
                        } catch (t) {
                            return !1
                        }
                    }(),
                    touch: D(),
                    touchscreen: D() || k && window.navigator.maxTouchPoints > 1,
                    pointer: k && "onpointerdown" in window,
                    pointerLock: k && "exitPointerLock" in window.document
                },
                j = 10,
                _ = {
                    mouse: 0,
                    touch: 0,
                    pen: 8
                },
                R = l(l({}, M), {}, {
                    device(t, e, {
                        pointer: {
                            touch: i = !1,
                            lock: n = !1,
                            mouse: r = !1
                        } = {}
                    }) {
                        return (this.pointerLock = n && V.pointerLock, V.touch && i) ? "touch" : this.pointerLock ? "mouse" : V.pointer && !r ? "pointer" : V.touch ? "touch" : "mouse"
                    },
                    preventScrollAxis(t, e, {
                        preventScroll: i
                    }) {
                        if (this.preventScrollDelay = "number" == typeof i ? i : i || void 0 === i && t ? 250 : void 0, V.touchscreen && !1 !== i) return t || (void 0 !== i ? "y" : void 0)
                    },
                    pointerCapture(t, e, {
                        pointer: {
                            capture: i = !0,
                            buttons: n = 1,
                            keys: r = !0
                        } = {}
                    }) {
                        return this.pointerButtons = n, this.keys = r, !this.pointerLock && "pointer" === this.device && i
                    },
                    threshold(t, e, {
                        filterTaps: i = !1,
                        tapsThreshold: r = 3,
                        axis: s
                    }) {
                        let o = n.toVector(t, i ? r : s ? 1 : 0);
                        return this.filterTaps = i, this.tapsThreshold = r, o
                    },
                    swipe({
                        velocity: t = .5,
                        distance: e = 50,
                        duration: i = 250
                    } = {}) {
                        return {
                            velocity: this.transform(n.toVector(t)),
                            distance: this.transform(n.toVector(e)),
                            duration: i
                        }
                    },
                    delay(t = 0) {
                        switch (t) {
                            case !0:
                                return 180;
                            case !1:
                                return 0;
                            default:
                                return t
                        }
                    },
                    axisThreshold: t => t ? l(l({}, _), t) : _,
                    keyboardDisplacement: (t = j) => t
                });
            l(l({}, T), {}, {
                device(t, e, {
                    shared: i,
                    pointer: {
                        touch: n = !1
                    } = {}
                }) {
                    if (i.target && !V.touch && V.gesture) return "gesture";
                    if (V.touch && n) return "touch";
                    if (V.touchscreen) {
                        if (V.pointer) return "pointer";
                        if (V.touch) return "touch"
                    }
                },
                bounds(t, e, {
                    scaleBounds: i = {},
                    angleBounds: n = {}
                }) {
                    let r = t => {
                            let e = b(y(i, t), {
                                min: -1 / 0,
                                max: 1 / 0
                            });
                            return [e.min, e.max]
                        },
                        s = t => {
                            let e = b(y(n, t), {
                                min: -1 / 0,
                                max: 1 / 0
                            });
                            return [e.min, e.max]
                        };
                    return "function" != typeof i && "function" != typeof n ? [r(), s()] : t => [r(t), s(t)]
                },
                threshold(t, e, i) {
                    return this.lockDirection = "lock" === i.axis, n.toVector(t, this.lockDirection ? [.1, 3] : 0)
                },
                modifierKey: t => void 0 === t ? "ctrlKey" : t,
                pinchOnWheel: (t = !0) => t
            }), l(l({}, M), {}, {
                mouseOnly: (t = !0) => t
            }), l(l({}, M), {}, {
                mouseOnly: (t = !0) => t
            });
            let O = new Map,
                L = new Map,
                I = {
                    key: "drag",
                    engine: C,
                    resolver: R
                };
            var F = i(2115);
            let B = {
                    target(t) {
                        if (t) return () => "current" in t ? t.current : t
                    },
                    enabled: (t = !0) => t,
                    window: (t = V.isBrowser ? window : void 0) => t,
                    eventOptions: ({
                        passive: t = !0,
                        capture: e = !1
                    } = {}) => ({
                        passive: t,
                        capture: e
                    }),
                    transform: t => t
                },
                U = ["target", "eventOptions", "window", "enabled", "transform"];

            function z(t = {}, e) {
                let i = {};
                for (let [n, r] of Object.entries(e)) switch (typeof r) {
                    case "function":
                        i[n] = r.call(i, t[n], n, t);
                        break;
                    case "object":
                        i[n] = z(t[n], r);
                        break;
                    case "boolean":
                        r && (i[n] = t[n])
                }
                return i
            }
            class N {
                constructor(t, e) {
                    o(this, "_listeners", new Set), this._ctrl = t, this._gestureKey = e
                }
                add(t, e, i, n, r) {
                    let s = this._listeners,
                        o = function(t, e = "") {
                            let i = u[t];
                            return t + (i && i[e] || e)
                        }(e, i),
                        a = l(l({}, this._gestureKey ? this._ctrl.config[this._gestureKey].eventOptions : {}), r);
                    t.addEventListener(o, n, a);
                    let h = () => {
                        t.removeEventListener(o, n, a), s.delete(h)
                    };
                    return s.add(h), h
                }
                clean() {
                    this._listeners.forEach(t => t()), this._listeners.clear()
                }
            }
            class $ {
                constructor() {
                    o(this, "_timeouts", new Map)
                }
                add(t, e, i = 140, ...n) {
                    this.remove(t), this._timeouts.set(t, window.setTimeout(e, i, ...n))
                }
                remove(t) {
                    let e = this._timeouts.get(t);
                    e && window.clearTimeout(e)
                }
                clean() {
                    this._timeouts.forEach(t => void window.clearTimeout(t)), this._timeouts.clear()
                }
            }
            class W {
                constructor(t) {
                    o(this, "gestures", new Set), o(this, "_targetEventStore", new N(this)), o(this, "gestureEventStores", {}), o(this, "gestureTimeoutStores", {}), o(this, "handlers", {}), o(this, "config", {}), o(this, "pointerIds", new Set), o(this, "touchIds", new Set), o(this, "state", {
                            shared: {
                                shiftKey: !1,
                                metaKey: !1,
                                ctrlKey: !1,
                                altKey: !1
                            }
                        }),
                        function(t, e) {
                            e.drag && H(t, "drag"), e.wheel && H(t, "wheel"), e.scroll && H(t, "scroll"), e.move && H(t, "move"), e.pinch && H(t, "pinch"), e.hover && H(t, "hover")
                        }(this, t)
                }
                setEventIds(t) {
                    return p(t) ? (this.touchIds = new Set(Array.from(t.touches).filter(e => {
                        var i, n;
                        return e.target === t.currentTarget || (null === (i = t.currentTarget) || void 0 === i || null === (n = i.contains) || void 0 === n ? void 0 : n.call(i, e.target))
                    }).map(t => t.identifier)), this.touchIds) : "pointerId" in t ? ("pointerup" === t.type || "pointercancel" === t.type ? this.pointerIds.delete(t.pointerId) : "pointerdown" === t.type && this.pointerIds.add(t.pointerId), this.pointerIds) : void 0
                }
                applyHandlers(t, e) {
                    this.handlers = t, this.nativeHandlers = e
                }
                applyConfig(t, e) {
                    this.config = function(t, e, i = {}) {
                        let {
                            target: n,
                            eventOptions: r,
                            window: s,
                            enabled: o,
                            transform: a
                        } = t, u = function(t, e) {
                            if (null == t) return {};
                            var i, n, r = function(t, e) {
                                if (null == t) return {};
                                var i, n, r = {},
                                    s = Object.keys(t);
                                for (n = 0; n < s.length; n++) i = s[n], e.indexOf(i) >= 0 || (r[i] = t[i]);
                                return r
                            }(t, e);
                            if (Object.getOwnPropertySymbols) {
                                var s = Object.getOwnPropertySymbols(t);
                                for (n = 0; n < s.length; n++) i = s[n], !(e.indexOf(i) >= 0) && Object.prototype.propertyIsEnumerable.call(t, i) && (r[i] = t[i])
                            }
                            return r
                        }(t, U);
                        if (i.shared = z({
                                target: n,
                                eventOptions: r,
                                window: s,
                                enabled: o,
                                transform: a
                            }, B), e) {
                            let t = L.get(e);
                            i[e] = z(l({
                                shared: i.shared
                            }, u), t)
                        } else
                            for (let t in u) {
                                let e = L.get(t);
                                e && (i[t] = z(l({
                                    shared: i.shared
                                }, u[t]), e))
                            }
                        return i
                    }(t, e, this.config)
                }
                clean() {
                    for (let t of (this._targetEventStore.clean(), this.gestures)) this.gestureEventStores[t].clean(), this.gestureTimeoutStores[t].clean()
                }
                effect() {
                    return this.config.shared.target && this.bind(), () => this._targetEventStore.clean()
                }
                bind(...t) {
                    let e;
                    let i = this.config.shared,
                        n = {};
                    if (!i.target || (e = i.target())) {
                        if (i.enabled) {
                            for (let i of this.gestures) {
                                let r = this.config[i],
                                    s = K(n, r.eventOptions, !!e);
                                r.enabled && new(O.get(i))(this, t, i).bind(s)
                            }
                            let r = K(n, i.eventOptions, !!e);
                            for (let e in this.nativeHandlers) r(e, "", i => this.nativeHandlers[e](l(l({}, this.state.shared), {}, {
                                event: i,
                                args: t
                            })), void 0, !0)
                        }
                        for (let t in n) n[t] = function(...t) {
                            return 0 === t.length ? x : 1 === t.length ? t[0] : function() {
                                let e;
                                for (let i of t) e = i.apply(this, arguments) || e;
                                return e
                            }
                        }(...n[t]);
                        if (!e) return n;
                        for (let t in n) {
                            let {
                                device: i,
                                capture: r,
                                passive: s
                            } = function(t) {
                                let e = t.substring(2).toLowerCase(),
                                    i = !!~e.indexOf("passive");
                                i && (e = e.replace("passive", ""));
                                let n = c.includes(e) ? "capturecapture" : "capture",
                                    r = !!~e.indexOf(n);
                                return r && (e = e.replace("capture", "")), {
                                    device: e,
                                    capture: r,
                                    passive: i
                                }
                            }(t);
                            this._targetEventStore.add(e, i, "", n[t], {
                                capture: r,
                                passive: s
                            })
                        }
                    }
                }
            }

            function H(t, e) {
                t.gestures.add(e), t.gestureEventStores[e] = new N(t, e), t.gestureTimeoutStores[e] = new $
            }
            let K = (t, e, i) => (n, r, s, o = {}, a = !1) => {
                var l, c;
                let p = null !== (l = o.capture) && void 0 !== l ? l : e.capture,
                    m = null !== (c = o.passive) && void 0 !== c ? c : e.passive,
                    f = a ? n : function(t, e = "", i = !1) {
                        let n = u[t],
                            r = n && n[e] || e;
                        return "on" + h(t) + h(r) + (! function(t = !1, e) {
                            return t && !d.includes(e)
                        }(i, r) ? "" : "Capture")
                    }(n, r, p);
                i && m && (f += "Passive"), t[f] = t[f] || [], t[f].push(s)
            };

            function Y(t, e) {
                return O.set(I.key, I.engine), L.set(I.key, I.resolver),
                    function(t, e = {}, i, n) {
                        let r = F.useMemo(() => new W(t), []);
                        if (r.applyHandlers(t, void 0), r.applyConfig(e, i), F.useEffect(r.effect.bind(r)), F.useEffect(() => r.clean.bind(r), []), void 0 === e.target) return r.bind.bind(r)
                    }({
                        drag: t
                    }, e || {}, "drag")
            }
        },
        5565: (t, e, i) => {
            i.d(e, {
                default: () => r.a
            });
            var n = i(4146),
                r = i.n(n)
        },
        7970: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "Image", {
                enumerable: !0,
                get: function() {
                    return b
                }
            });
            let n = i(306),
                r = i(9955),
                s = i(5155),
                o = r._(i(2115)),
                a = n._(i(7650)),
                l = n._(i(6107)),
                u = i(666),
                h = i(1159),
                d = i(3621);
            i(2363);
            let c = i(3576),
                p = n._(i(5514)),
                m = i(5353),
                f = {
                    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                    path: "/_next/image",
                    loader: "default",
                    dangerouslyAllowSVG: !1,
                    unoptimized: !1
                };

            function v(t, e, i, n, r, s, o) {
                let a = null == t ? void 0 : t.src;
                t && t["data-loaded-src"] !== a && (t["data-loaded-src"] = a, ("decode" in t ? t.decode() : Promise.resolve()).catch(() => {}).then(() => {
                    if (t.parentElement && t.isConnected) {
                        if ("empty" !== e && r(!0), null == i ? void 0 : i.current) {
                            let e = new Event("load");
                            Object.defineProperty(e, "target", {
                                writable: !1,
                                value: t
                            });
                            let n = !1,
                                r = !1;
                            i.current({ ...e,
                                nativeEvent: e,
                                currentTarget: t,
                                target: t,
                                isDefaultPrevented: () => n,
                                isPropagationStopped: () => r,
                                persist: () => {},
                                preventDefault: () => {
                                    n = !0, e.preventDefault()
                                },
                                stopPropagation: () => {
                                    r = !0, e.stopPropagation()
                                }
                            })
                        }(null == n ? void 0 : n.current) && n.current(t)
                    }
                }))
            }

            function g(t) {
                return o.use ? {
                    fetchPriority: t
                } : {
                    fetchpriority: t
                }
            }
            "undefined" == typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
            let y = (0, o.forwardRef)((t, e) => {
                let {
                    src: i,
                    srcSet: n,
                    sizes: r,
                    height: a,
                    width: l,
                    decoding: u,
                    className: h,
                    style: d,
                    fetchPriority: c,
                    placeholder: p,
                    loading: f,
                    unoptimized: y,
                    fill: x,
                    onLoadRef: b,
                    onLoadingCompleteRef: w,
                    setBlurComplete: P,
                    setShowAltText: S,
                    sizesInput: T,
                    onLoad: A,
                    onError: M,
                    ...E
                } = t, C = (0, o.useCallback)(t => {
                    t && (M && (t.src = t.src), t.complete && v(t, p, b, w, P, y, T))
                }, [i, p, b, w, P, M, y, T]), k = (0, m.useMergedRef)(e, C);
                return (0, s.jsx)("img", { ...E,
                    ...g(c),
                    loading: f,
                    width: l,
                    height: a,
                    decoding: u,
                    "data-nimg": x ? "fill" : "1",
                    className: h,
                    style: d,
                    sizes: r,
                    srcSet: n,
                    src: i,
                    ref: k,
                    onLoad: t => {
                        v(t.currentTarget, p, b, w, P, y, T)
                    },
                    onError: t => {
                        S(!0), "empty" !== p && P(!0), M && M(t)
                    }
                })
            });

            function x(t) {
                let {
                    isAppRouter: e,
                    imgAttributes: i
                } = t, n = {
                    as: "image",
                    imageSrcSet: i.srcSet,
                    imageSizes: i.sizes,
                    crossOrigin: i.crossOrigin,
                    referrerPolicy: i.referrerPolicy,
                    ...g(i.fetchPriority)
                };
                return e && a.default.preload ? (a.default.preload(i.src, n), null) : (0, s.jsx)(l.default, {
                    children: (0, s.jsx)("link", {
                        rel: "preload",
                        href: i.srcSet ? void 0 : i.src,
                        ...n
                    }, "__nimg-" + i.src + i.srcSet + i.sizes)
                })
            }
            let b = (0, o.forwardRef)((t, e) => {
                let i = (0, o.useContext)(c.RouterContext),
                    n = (0, o.useContext)(d.ImageConfigContext),
                    r = (0, o.useMemo)(() => {
                        let t = f || n || h.imageConfigDefault,
                            e = [...t.deviceSizes, ...t.imageSizes].sort((t, e) => t - e),
                            i = t.deviceSizes.sort((t, e) => t - e);
                        return { ...t,
                            allSizes: e,
                            deviceSizes: i
                        }
                    }, [n]),
                    {
                        onLoad: a,
                        onLoadingComplete: l
                    } = t,
                    m = (0, o.useRef)(a);
                (0, o.useEffect)(() => {
                    m.current = a
                }, [a]);
                let v = (0, o.useRef)(l);
                (0, o.useEffect)(() => {
                    v.current = l
                }, [l]);
                let [g, b] = (0, o.useState)(!1), [w, P] = (0, o.useState)(!1), {
                    props: S,
                    meta: T
                } = (0, u.getImgProps)(t, {
                    defaultLoader: p.default,
                    imgConf: r,
                    blurComplete: g,
                    showAltText: w
                });
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)(y, { ...S,
                        unoptimized: T.unoptimized,
                        placeholder: T.placeholder,
                        fill: T.fill,
                        onLoadRef: m,
                        onLoadingCompleteRef: v,
                        setBlurComplete: b,
                        setShowAltText: P,
                        sizesInput: t.sizes,
                        ref: e
                    }), T.priority ? (0, s.jsx)(x, {
                        isAppRouter: !i,
                        imgAttributes: S
                    }) : null]
                })
            });
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        5353: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "useMergedRef", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let n = i(2115);

            function r(t, e) {
                let i = (0, n.useRef)(() => {}),
                    r = (0, n.useRef)(() => {});
                return (0, n.useMemo)(() => t && e ? n => {
                    null === n ? (i.current(), r.current()) : (i.current = s(t, n), r.current = s(e, n))
                } : t || e, [t, e])
            }

            function s(t, e) {
                if ("function" != typeof t) return t.current = e, () => {
                    t.current = null
                }; {
                    let i = t(e);
                    return "function" == typeof i ? i : () => t(null)
                }
            }("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        3003: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "AmpStateContext", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let n = i(306)._(i(2115)).default.createContext({})
        },
        675: (t, e) => {
            function i(t) {
                let {
                    ampFirst: e = !1,
                    hybrid: i = !1,
                    hasQuery: n = !1
                } = void 0 === t ? {} : t;
                return e || i && n
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "isInAmpMode", {
                enumerable: !0,
                get: function() {
                    return i
                }
            })
        },
        666: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getImgProps", {
                enumerable: !0,
                get: function() {
                    return a
                }
            }), i(2363);
            let n = i(5859),
                r = i(1159);

            function s(t) {
                return void 0 !== t.default
            }

            function o(t) {
                return void 0 === t ? t : "number" == typeof t ? Number.isFinite(t) ? t : NaN : "string" == typeof t && /^[0-9]+$/.test(t) ? parseInt(t, 10) : NaN
            }

            function a(t, e) {
                var i;
                let a, l, u, {
                        src: h,
                        sizes: d,
                        unoptimized: c = !1,
                        priority: p = !1,
                        loading: m,
                        className: f,
                        quality: v,
                        width: g,
                        height: y,
                        fill: x = !1,
                        style: b,
                        overrideSrc: w,
                        onLoad: P,
                        onLoadingComplete: S,
                        placeholder: T = "empty",
                        blurDataURL: A,
                        fetchPriority: M,
                        decoding: E = "async",
                        layout: C,
                        objectFit: k,
                        objectPosition: D,
                        lazyBoundary: V,
                        lazyRoot: j,
                        ..._
                    } = t,
                    {
                        imgConf: R,
                        showAltText: O,
                        blurComplete: L,
                        defaultLoader: I
                    } = e,
                    F = R || r.imageConfigDefault;
                if ("allSizes" in F) a = F;
                else {
                    let t = [...F.deviceSizes, ...F.imageSizes].sort((t, e) => t - e),
                        e = F.deviceSizes.sort((t, e) => t - e);
                    a = { ...F,
                        allSizes: t,
                        deviceSizes: e
                    }
                }
                if (void 0 === I) throw Error("images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config");
                let B = _.loader || I;
                delete _.loader, delete _.srcSet;
                let U = "__next_img_default" in B;
                if (U) {
                    if ("custom" === a.loader) throw Error('Image with src "' + h + '" is missing "loader" prop.\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader')
                } else {
                    let t = B;
                    B = e => {
                        let {
                            config: i,
                            ...n
                        } = e;
                        return t(n)
                    }
                }
                if (C) {
                    "fill" === C && (x = !0);
                    let t = {
                        intrinsic: {
                            maxWidth: "100%",
                            height: "auto"
                        },
                        responsive: {
                            width: "100%",
                            height: "auto"
                        }
                    }[C];
                    t && (b = { ...b,
                        ...t
                    });
                    let e = {
                        responsive: "100vw",
                        fill: "100vw"
                    }[C];
                    e && !d && (d = e)
                }
                let z = "",
                    N = o(g),
                    $ = o(y);
                if ((i = h) && "object" == typeof i && (s(i) || void 0 !== i.src)) {
                    let t = s(h) ? h.default : h;
                    if (!t.src) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received " + JSON.stringify(t));
                    if (!t.height || !t.width) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received " + JSON.stringify(t));
                    if (l = t.blurWidth, u = t.blurHeight, A = A || t.blurDataURL, z = t.src, !x) {
                        if (N || $) {
                            if (N && !$) {
                                let e = N / t.width;
                                $ = Math.round(t.height * e)
                            } else if (!N && $) {
                                let e = $ / t.height;
                                N = Math.round(t.width * e)
                            }
                        } else N = t.width, $ = t.height
                    }
                }
                let W = !p && ("lazy" === m || void 0 === m);
                (!(h = "string" == typeof h ? h : z) || h.startsWith("data:") || h.startsWith("blob:")) && (c = !0, W = !1), a.unoptimized && (c = !0), U && !a.dangerouslyAllowSVG && h.split("?", 1)[0].endsWith(".svg") && (c = !0);
                let H = o(v),
                    K = Object.assign(x ? {
                        position: "absolute",
                        height: "100%",
                        width: "100%",
                        left: 0,
                        top: 0,
                        right: 0,
                        bottom: 0,
                        objectFit: k,
                        objectPosition: D
                    } : {}, O ? {} : {
                        color: "transparent"
                    }, b),
                    Y = L || "empty" === T ? null : "blur" === T ? 'url("data:image/svg+xml;charset=utf-8,' + (0, n.getImageBlurSvg)({
                        widthInt: N,
                        heightInt: $,
                        blurWidth: l,
                        blurHeight: u,
                        blurDataURL: A || "",
                        objectFit: K.objectFit
                    }) + '")' : 'url("' + T + '")',
                    X = Y ? {
                        backgroundSize: K.objectFit || "cover",
                        backgroundPosition: K.objectPosition || "50% 50%",
                        backgroundRepeat: "no-repeat",
                        backgroundImage: Y
                    } : {},
                    G = function(t) {
                        let {
                            config: e,
                            src: i,
                            unoptimized: n,
                            width: r,
                            quality: s,
                            sizes: o,
                            loader: a
                        } = t;
                        if (n) return {
                            src: i,
                            srcSet: void 0,
                            sizes: void 0
                        };
                        let {
                            widths: l,
                            kind: u
                        } = function(t, e, i) {
                            let {
                                deviceSizes: n,
                                allSizes: r
                            } = t;
                            if (i) {
                                let t = /(^|\s)(1?\d?\d)vw/g,
                                    e = [];
                                for (let n; n = t.exec(i); n) e.push(parseInt(n[2]));
                                if (e.length) {
                                    let t = .01 * Math.min(...e);
                                    return {
                                        widths: r.filter(e => e >= n[0] * t),
                                        kind: "w"
                                    }
                                }
                                return {
                                    widths: r,
                                    kind: "w"
                                }
                            }
                            return "number" != typeof e ? {
                                widths: n,
                                kind: "w"
                            } : {
                                widths: [...new Set([e, 2 * e].map(t => r.find(e => e >= t) || r[r.length - 1]))],
                                kind: "x"
                            }
                        }(e, r, o), h = l.length - 1;
                        return {
                            sizes: o || "w" !== u ? o : "100vw",
                            srcSet: l.map((t, n) => a({
                                config: e,
                                src: i,
                                quality: s,
                                width: t
                            }) + " " + ("w" === u ? t : n + 1) + u).join(", "),
                            src: a({
                                config: e,
                                src: i,
                                quality: s,
                                width: l[h]
                            })
                        }
                    }({
                        config: a,
                        src: h,
                        unoptimized: c,
                        width: N,
                        quality: H,
                        sizes: d,
                        loader: B
                    });
                return {
                    props: { ..._,
                        loading: W ? "lazy" : m,
                        fetchPriority: M,
                        width: N,
                        height: $,
                        decoding: E,
                        className: f,
                        style: { ...K,
                            ...X
                        },
                        sizes: G.sizes,
                        srcSet: G.srcSet,
                        src: w || G.src
                    },
                    meta: {
                        unoptimized: c,
                        priority: p,
                        placeholder: T,
                        fill: x
                    }
                }
            }
        },
        6107: (t, e, i) => {
            var n = i(2818);
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    default: function() {
                        return v
                    },
                    defaultHead: function() {
                        return c
                    }
                });
            let r = i(306),
                s = i(9955),
                o = i(5155),
                a = s._(i(2115)),
                l = r._(i(1172)),
                u = i(3003),
                h = i(1147),
                d = i(675);

            function c(t) {
                void 0 === t && (t = !1);
                let e = [(0, o.jsx)("meta", {
                    charSet: "utf-8"
                }, "charset")];
                return t || e.push((0, o.jsx)("meta", {
                    name: "viewport",
                    content: "width=device-width"
                }, "viewport")), e
            }

            function p(t, e) {
                return "string" == typeof e || "number" == typeof e ? t : e.type === a.default.Fragment ? t.concat(a.default.Children.toArray(e.props.children).reduce((t, e) => "string" == typeof e || "number" == typeof e ? t : t.concat(e), [])) : t.concat(e)
            }
            i(2363);
            let m = ["name", "httpEquiv", "charSet", "itemProp"];

            function f(t, e) {
                let {
                    inAmpMode: i
                } = e;
                return t.reduce(p, []).reverse().concat(c(i).reverse()).filter(function() {
                    let t = new Set,
                        e = new Set,
                        i = new Set,
                        n = {};
                    return r => {
                        let s = !0,
                            o = !1;
                        if (r.key && "number" != typeof r.key && r.key.indexOf("$") > 0) {
                            o = !0;
                            let e = r.key.slice(r.key.indexOf("$") + 1);
                            t.has(e) ? s = !1 : t.add(e)
                        }
                        switch (r.type) {
                            case "title":
                            case "base":
                                e.has(r.type) ? s = !1 : e.add(r.type);
                                break;
                            case "meta":
                                for (let t = 0, e = m.length; t < e; t++) {
                                    let e = m[t];
                                    if (r.props.hasOwnProperty(e)) {
                                        if ("charSet" === e) i.has(e) ? s = !1 : i.add(e);
                                        else {
                                            let t = r.props[e],
                                                i = n[e] || new Set;
                                            ("name" !== e || !o) && i.has(t) ? s = !1 : (i.add(t), n[e] = i)
                                        }
                                    }
                                }
                        }
                        return s
                    }
                }()).reverse().map((t, e) => {
                    let r = t.key || e;
                    if (n.env.__NEXT_OPTIMIZE_FONTS && !i && "link" === t.type && t.props.href && ["https://fonts.googleapis.com/css", "https://use.typekit.net/"].some(e => t.props.href.startsWith(e))) {
                        let e = { ...t.props || {}
                        };
                        return e["data-href"] = e.href, e.href = void 0, e["data-optimized-fonts"] = !0, a.default.cloneElement(t, e)
                    }
                    return a.default.cloneElement(t, {
                        key: r
                    })
                })
            }
            let v = function(t) {
                let {
                    children: e
                } = t, i = (0, a.useContext)(u.AmpStateContext), n = (0, a.useContext)(h.HeadManagerContext);
                return (0, o.jsx)(l.default, {
                    reduceComponentsToState: f,
                    headManager: n,
                    inAmpMode: (0, d.isInAmpMode)(i),
                    children: e
                })
            };
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        5859: (t, e) => {
            function i(t) {
                let {
                    widthInt: e,
                    heightInt: i,
                    blurWidth: n,
                    blurHeight: r,
                    blurDataURL: s,
                    objectFit: o
                } = t, a = n ? 40 * n : e, l = r ? 40 * r : i, u = a && l ? "viewBox='0 0 " + a + " " + l + "'" : "";
                return "%3Csvg xmlns='http://www.w3.org/2000/svg' " + u + "%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='" + (u ? "none" : "contain" === o ? "xMidYMid" : "cover" === o ? "xMidYMid slice" : "none") + "' style='filter: url(%23b);' href='" + s + "'/%3E%3C/svg%3E"
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getImageBlurSvg", {
                enumerable: !0,
                get: function() {
                    return i
                }
            })
        },
        3621: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "ImageConfigContext", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = i(306)._(i(2115)),
                r = i(1159),
                s = n.default.createContext(r.imageConfigDefault)
        },
        1159: (t, e) => {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    VALID_LOADERS: function() {
                        return i
                    },
                    imageConfigDefault: function() {
                        return n
                    }
                });
            let i = ["default", "imgix", "cloudinary", "akamai", "custom"],
                n = {
                    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                    path: "/_next/image",
                    loader: "default",
                    loaderFile: "",
                    domains: [],
                    disableStaticImages: !1,
                    minimumCacheTTL: 60,
                    formats: ["image/webp"],
                    dangerouslyAllowSVG: !1,
                    contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
                    contentDispositionType: "attachment",
                    localPatterns: void 0,
                    remotePatterns: [],
                    unoptimized: !1
                }
        },
        4146: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    default: function() {
                        return l
                    },
                    getImageProps: function() {
                        return a
                    }
                });
            let n = i(306),
                r = i(666),
                s = i(7970),
                o = n._(i(5514));

            function a(t) {
                let {
                    props: e
                } = (0, r.getImgProps)(t, {
                    defaultLoader: o.default,
                    imgConf: {
                        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                        path: "/_next/image",
                        loader: "default",
                        dangerouslyAllowSVG: !1,
                        unoptimized: !1
                    }
                });
                for (let [t, i] of Object.entries(e)) void 0 === i && delete e[t];
                return {
                    props: e
                }
            }
            let l = s.Image
        },
        5514: (t, e) => {
            function i(t) {
                let {
                    config: e,
                    src: i,
                    width: n,
                    quality: r
                } = t;
                return e.path + "?url=" + encodeURIComponent(i) + "&w=" + n + "&q=" + (r || 75) + (i.startsWith("/_next/static/media/"), "")
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), i.__next_img_default = !0;
            let n = i
        },
        3576: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "RouterContext", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let n = i(306)._(i(2115)).default.createContext(null)
        },
        1172: (t, e, i) => {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return a
                }
            });
            let n = i(2115),
                r = "undefined" == typeof window,
                s = r ? () => {} : n.useLayoutEffect,
                o = r ? () => {} : n.useEffect;

            function a(t) {
                let {
                    headManager: e,
                    reduceComponentsToState: i
                } = t;

                function a() {
                    if (e && e.mountedInstances) {
                        let r = n.Children.toArray(Array.from(e.mountedInstances).filter(Boolean));
                        e.updateHead(i(r, t))
                    }
                }
                if (r) {
                    var l;
                    null == e || null == (l = e.mountedInstances) || l.add(t.children), a()
                }
                return s(() => {
                    var i;
                    return null == e || null == (i = e.mountedInstances) || i.add(t.children), () => {
                        var i;
                        null == e || null == (i = e.mountedInstances) || i.delete(t.children)
                    }
                }), s(() => (e && (e._pendingUpdate = a), () => {
                    e && (e._pendingUpdate = a)
                })), o(() => (e && e._pendingUpdate && (e._pendingUpdate(), e._pendingUpdate = null), () => {
                    e && e._pendingUpdate && (e._pendingUpdate(), e._pendingUpdate = null)
                })), null
            }
        },
        5683: (t, e, i) => {
            i.d(e, {
                N: () => g
            });
            var n = i(5155),
                r = i(2115),
                s = i(9656),
                o = i(9234),
                a = i(7249);
            class l extends r.Component {
                getSnapshotBeforeUpdate(t) {
                    let e = this.props.childRef.current;
                    if (e && t.isPresent && !this.props.isPresent) {
                        let t = this.props.sizeRef.current;
                        t.height = e.offsetHeight || 0, t.width = e.offsetWidth || 0, t.top = e.offsetTop, t.left = e.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function u(t) {
                let {
                    children: e,
                    isPresent: i
                } = t, s = (0, r.useId)(), o = (0, r.useRef)(null), u = (0, r.useRef)({
                    width: 0,
                    height: 0,
                    top: 0,
                    left: 0
                }), {
                    nonce: h
                } = (0, r.useContext)(a.Q);
                return (0, r.useInsertionEffect)(() => {
                    let {
                        width: t,
                        height: e,
                        top: n,
                        left: r
                    } = u.current;
                    if (i || !o.current || !t || !e) return;
                    o.current.dataset.motionPopId = s;
                    let a = document.createElement("style");
                    return h && (a.nonce = h), document.head.appendChild(a), a.sheet && a.sheet.insertRule('\n          [data-motion-pop-id="'.concat(s, '"] {\n            position: absolute !important;\n            width: ').concat(t, "px !important;\n            height: ").concat(e, "px !important;\n            top: ").concat(n, "px !important;\n            left: ").concat(r, "px !important;\n          }\n        ")), () => {
                        document.head.removeChild(a)
                    }
                }, [i]), (0, n.jsx)(l, {
                    isPresent: i,
                    childRef: o,
                    sizeRef: u,
                    children: r.cloneElement(e, {
                        ref: o
                    })
                })
            }
            let h = t => {
                let {
                    children: e,
                    initial: i,
                    isPresent: a,
                    onExitComplete: l,
                    custom: h,
                    presenceAffectsLayout: c,
                    mode: p
                } = t, m = (0, o.M)(d), f = (0, r.useId)(), v = (0, r.useCallback)(t => {
                    for (let e of (m.set(t, !0), m.values()))
                        if (!e) return;
                    l && l()
                }, [m, l]), g = (0, r.useMemo)(() => ({
                    id: f,
                    initial: i,
                    isPresent: a,
                    custom: h,
                    onExitComplete: v,
                    register: t => (m.set(t, !1), () => m.delete(t))
                }), c ? [Math.random(), v] : [a, v]);
                return (0, r.useMemo)(() => {
                    m.forEach((t, e) => m.set(e, !1))
                }, [a]), r.useEffect(() => {
                    a || m.size || !l || l()
                }, [a]), "popLayout" === p && (e = (0, n.jsx)(u, {
                    isPresent: a,
                    children: e
                })), (0, n.jsx)(s.t.Provider, {
                    value: g,
                    children: e
                })
            };

            function d() {
                return new Map
            }
            var c = i(4710),
                p = i(5107);
            let m = t => t.key || "";

            function f(t) {
                let e = [];
                return r.Children.forEach(t, t => {
                    (0, r.isValidElement)(t) && e.push(t)
                }), e
            }
            var v = i(5403);
            let g = t => {
                let {
                    children: e,
                    exitBeforeEnter: i,
                    custom: s,
                    initial: a = !0,
                    onExitComplete: l,
                    presenceAffectsLayout: u = !0,
                    mode: d = "sync"
                } = t;
                (0, p.V)(!i, "Replace exitBeforeEnter with mode='wait'");
                let g = (0, r.useMemo)(() => f(e), [e]),
                    y = g.map(m),
                    x = (0, r.useRef)(!0),
                    b = (0, r.useRef)(g),
                    w = (0, o.M)(() => new Map),
                    [P, S] = (0, r.useState)(g),
                    [T, A] = (0, r.useState)(g);
                (0, v.E)(() => {
                    x.current = !1, b.current = g;
                    for (let t = 0; t < T.length; t++) {
                        let e = m(T[t]);
                        y.includes(e) ? w.delete(e) : !0 !== w.get(e) && w.set(e, !1)
                    }
                }, [T, y.length, y.join("-")]);
                let M = [];
                if (g !== P) {
                    let t = [...g];
                    for (let e = 0; e < T.length; e++) {
                        let i = T[e],
                            n = m(i);
                        y.includes(n) || (t.splice(e, 0, i), M.push(i))
                    }
                    "wait" === d && M.length && (t = M), A(f(t)), S(g);
                    return
                }
                let {
                    forceRender: E
                } = (0, r.useContext)(c.L);
                return (0, n.jsx)(n.Fragment, {
                    children: T.map(t => {
                        let e = m(t),
                            i = g === T || y.includes(e);
                        return (0, n.jsx)(h, {
                            isPresent: i,
                            initial: (!x.current || !!a) && void 0,
                            custom: i ? void 0 : s,
                            presenceAffectsLayout: u,
                            mode: d,
                            onExitComplete: i ? void 0 : () => {
                                if (!w.has(e)) return;
                                w.set(e, !0);
                                let t = !0;
                                w.forEach(e => {
                                    e || (t = !1)
                                }), t && (null == E || E(), A(b.current), l && l())
                            },
                            children: t
                        }, e)
                    })
                })
            }
        },
        4710: (t, e, i) => {
            i.d(e, {
                L: () => n
            });
            let n = (0, i(2115).createContext)({})
        },
        7249: (t, e, i) => {
            i.d(e, {
                Q: () => n
            });
            let n = (0, i(2115).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        9656: (t, e, i) => {
            i.d(e, {
                t: () => n
            });
            let n = (0, i(2115).createContext)(null)
        },
        1714: (t, e, i) => {
            let n;

            function r(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
            i.d(e, {
                P: () => sc
            });
            let s = t => Array.isArray(t);

            function o(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let n = 0; n < i; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }

            function a(t) {
                return "string" == typeof t || Array.isArray(t)
            }

            function l(t, e, i, n) {
                if ("function" == typeof e || ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e)) {
                    let [r, s] = function(t) {
                        let e = [{}, {}];
                        return null == t || t.values.forEach((t, i) => {
                            e[0][i] = t.get(), e[1][i] = t.getVelocity()
                        }), e
                    }(n);
                    e = e(void 0 !== i ? i : t.custom, r, s)
                }
                return e
            }

            function u(t, e, i) {
                let n = t.getProps();
                return l(n, e, void 0 !== i ? i : n.custom, t)
            }
            let h = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                d = ["initial", ...h],
                c = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                p = new Set(c),
                m = t => 1e3 * t,
                f = t => t / 1e3,
                v = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                g = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                y = {
                    type: "keyframes",
                    duration: .8
                },
                x = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                b = (t, {
                    keyframes: e
                }) => e.length > 2 ? y : p.has(t) ? t.startsWith("scale") ? g(e[1]) : v : x;

            function w(t, e) {
                return t ? t[e] || t.default || t : void 0
            }
            let P = {
                    skipAnimations: !1,
                    useManualTiming: !1
                },
                S = {
                    current: !1
                },
                T = t => null !== t;

            function A(t, {
                repeat: e,
                repeatType: i = "loop"
            }, n) {
                let r = t.filter(T),
                    s = e && "loop" !== i && e % 2 == 1 ? 0 : r.length - 1;
                return s && void 0 !== n ? n : r[s]
            }
            var M, E, C = i(6054);
            let k = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function D(t, e) {
                let i = !1,
                    n = !0,
                    r = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    s = () => i = !0,
                    o = k.reduce((t, e) => (t[e] = function(t) {
                        let e = new Set,
                            i = new Set,
                            n = !1,
                            r = !1,
                            s = new WeakSet,
                            o = {
                                delta: 0,
                                timestamp: 0,
                                isProcessing: !1
                            };

                        function a(e) {
                            s.has(e) && (l.schedule(e), t()), e(o)
                        }
                        let l = {
                            schedule: (t, r = !1, o = !1) => {
                                let a = o && n ? e : i;
                                return r && s.add(t), a.has(t) || a.add(t), t
                            },
                            cancel: t => {
                                i.delete(t), s.delete(t)
                            },
                            process: t => {
                                if (o = t, n) {
                                    r = !0;
                                    return
                                }
                                n = !0, [e, i] = [i, e], i.clear(), e.forEach(a), n = !1, r && (r = !1, l.process(t))
                            }
                        };
                        return l
                    }(s), t), {}),
                    {
                        read: a,
                        resolveKeyframes: l,
                        update: u,
                        preRender: h,
                        render: d,
                        postRender: c
                    } = o,
                    p = () => {
                        let s = P.useManualTiming ? r.timestamp : performance.now();
                        i = !1, r.delta = n ? 1e3 / 60 : Math.max(Math.min(s - r.timestamp, 40), 1), r.timestamp = s, r.isProcessing = !0, a.process(r), l.process(r), u.process(r), h.process(r), d.process(r), c.process(r), r.isProcessing = !1, i && e && (n = !1, t(p))
                    },
                    m = () => {
                        i = !0, n = !0, r.isProcessing || t(p)
                    };
                return {
                    schedule: k.reduce((t, e) => {
                        let n = o[e];
                        return t[e] = (t, e = !1, r = !1) => (i || m(), n.schedule(t, e, r)), t
                    }, {}),
                    cancel: t => {
                        for (let e = 0; e < k.length; e++) o[k[e]].cancel(t)
                    },
                    state: r,
                    steps: o
                }
            }
            let {
                schedule: V,
                cancel: j,
                state: _,
                steps: R
            } = D("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : C.l, !0), O = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

            function L(t, e, i, n) {
                if (t === e && i === n) return C.l;
                let r = e => (function(t, e, i, n, r) {
                    let s, o;
                    let a = 0;
                    do(s = O(o = e + (i - e) / 2, n, r) - t) > 0 ? i = o : e = o; while (Math.abs(s) > 1e-7 && ++a < 12);
                    return o
                })(e, 0, 1, t, i);
                return t => 0 === t || 1 === t ? t : O(r(t), e, n)
            }
            let I = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
                F = t => e => 1 - t(1 - e),
                B = L(.33, 1.53, .69, .99),
                U = F(B),
                z = I(U),
                N = t => (t *= 2) < 1 ? .5 * U(t) : .5 * (2 - Math.pow(2, -10 * (t - 1))),
                $ = t => 1 - Math.sin(Math.acos(t)),
                W = F($),
                H = I($),
                K = t => /^0[^.\s]+$/u.test(t);
            var Y = i(5107);
            let X = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t),
                G = t => e => "string" == typeof e && e.startsWith(t),
                q = G("--"),
                Z = G("var(--"),
                Q = t => !!Z(t) && J.test(t.split("/*")[0].trim()),
                J = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
                tt = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u,
                te = (t, e, i) => i > e ? e : i < t ? t : i,
                ti = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                tn = { ...ti,
                    transform: t => te(0, 1, t)
                },
                tr = { ...ti,
                    default: 1
                },
                ts = t => ({
                    test: e => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                to = ts("deg"),
                ta = ts("%"),
                tl = ts("px"),
                tu = ts("vh"),
                th = ts("vw"),
                td = { ...ta,
                    parse: t => ta.parse(t) / 100,
                    transform: t => ta.transform(100 * t)
                },
                tc = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                tp = t => t === ti || t === tl,
                tm = (t, e) => parseFloat(t.split(", ")[e]),
                tf = (t, e) => (i, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let r = n.match(/^matrix3d\((.+)\)$/u);
                    if (r) return tm(r[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/u);
                        return e ? tm(e[1], t) : 0
                    }
                },
                tv = new Set(["x", "y", "z"]),
                tg = c.filter(t => !tv.has(t)),
                ty = {
                    width: ({
                        x: t
                    }, {
                        paddingLeft: e = "0",
                        paddingRight: i = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                    height: ({
                        y: t
                    }, {
                        paddingTop: e = "0",
                        paddingBottom: i = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                    top: (t, {
                        top: e
                    }) => parseFloat(e),
                    left: (t, {
                        left: e
                    }) => parseFloat(e),
                    bottom: ({
                        y: t
                    }, {
                        top: e
                    }) => parseFloat(e) + (t.max - t.min),
                    right: ({
                        x: t
                    }, {
                        left: e
                    }) => parseFloat(e) + (t.max - t.min),
                    x: tf(4, 13),
                    y: tf(5, 14)
                };
            ty.translateX = ty.x, ty.translateY = ty.y;
            let tx = t => e => e.test(t),
                tb = [ti, tl, ta, to, th, tu, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                tw = t => tb.find(tx(t)),
                tP = new Set,
                tS = !1,
                tT = !1;

            function tA() {
                if (tT) {
                    let t = Array.from(tP).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        i = new Map;
                    e.forEach(t => {
                        let e = function(t) {
                            let e = [];
                            return tg.forEach(i => {
                                let n = t.getValue(i);
                                void 0 !== n && (e.push([i, n.get()]), n.set(i.startsWith("scale") ? 1 : 0))
                            }), e
                        }(t);
                        e.length && (i.set(t, e), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render();
                        let e = i.get(t);
                        e && e.forEach(([e, i]) => {
                            var n;
                            null === (n = t.getValue(e)) || void 0 === n || n.set(i)
                        })
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                tT = !1, tS = !1, tP.forEach(t => t.complete()), tP.clear()
            }

            function tM() {
                tP.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (tT = !0)
                })
            }
            class tE {
                constructor(t, e, i, n, r, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = n, this.element = r, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (tP.add(this), tS || (tS = !0, V.read(tM), V.resolveKeyframes(tA))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: n
                    } = this;
                    for (let r = 0; r < t.length; r++)
                        if (null === t[r]) {
                            if (0 === r) {
                                let r = null == n ? void 0 : n.get(),
                                    s = t[t.length - 1];
                                if (void 0 !== r) t[0] = r;
                                else if (i && e) {
                                    let n = i.readValue(e, s);
                                    null != n && (t[0] = n)
                                }
                                void 0 === t[0] && (t[0] = s), n && void 0 === r && n.set(t[0])
                            } else t[r] = t[r - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), tP.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, tP.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
            let tC = t => Math.round(1e5 * t) / 1e5,
                tk = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
                tD = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
                tV = (t, e) => i => !!("string" == typeof i && tD.test(i) && i.startsWith(t) || e && null != i && Object.prototype.hasOwnProperty.call(i, e)),
                tj = (t, e, i) => n => {
                    if ("string" != typeof n) return n;
                    let [r, s, o, a] = n.match(tk);
                    return {
                        [t]: parseFloat(r),
                        [e]: parseFloat(s),
                        [i]: parseFloat(o),
                        alpha: void 0 !== a ? parseFloat(a) : 1
                    }
                },
                t_ = t => te(0, 255, t),
                tR = { ...ti,
                    transform: t => Math.round(t_(t))
                },
                tO = {
                    test: tV("rgb", "red"),
                    parse: tj("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: i,
                        alpha: n = 1
                    }) => "rgba(" + tR.transform(t) + ", " + tR.transform(e) + ", " + tR.transform(i) + ", " + tC(tn.transform(n)) + ")"
                },
                tL = {
                    test: tV("#"),
                    parse: function(t) {
                        let e = "",
                            i = "",
                            n = "",
                            r = "";
                        return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), n = t.substring(5, 7), r = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), n = t.substring(3, 4), r = t.substring(4, 5), e += e, i += i, n += n, r += r), {
                            red: parseInt(e, 16),
                            green: parseInt(i, 16),
                            blue: parseInt(n, 16),
                            alpha: r ? parseInt(r, 16) / 255 : 1
                        }
                    },
                    transform: tO.transform
                },
                tI = {
                    test: tV("hsl", "hue"),
                    parse: tj("hue", "saturation", "lightness"),
                    transform: ({
                        hue: t,
                        saturation: e,
                        lightness: i,
                        alpha: n = 1
                    }) => "hsla(" + Math.round(t) + ", " + ta.transform(tC(e)) + ", " + ta.transform(tC(i)) + ", " + tC(tn.transform(n)) + ")"
                },
                tF = {
                    test: t => tO.test(t) || tL.test(t) || tI.test(t),
                    parse: t => tO.test(t) ? tO.parse(t) : tI.test(t) ? tI.parse(t) : tL.parse(t),
                    transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? tO.transform(t) : tI.transform(t)
                },
                tB = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
                tU = "number",
                tz = "color",
                tN = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function t$(t) {
                let e = t.toString(),
                    i = [],
                    n = {
                        color: [],
                        number: [],
                        var: []
                    },
                    r = [],
                    s = 0,
                    o = e.replace(tN, t => (tF.test(t) ? (n.color.push(s), r.push(tz), i.push(tF.parse(t))) : t.startsWith("var(") ? (n.var.push(s), r.push("var"), i.push(t)) : (n.number.push(s), r.push(tU), i.push(parseFloat(t))), ++s, "${}")).split("${}");
                return {
                    values: i,
                    split: o,
                    indexes: n,
                    types: r
                }
            }

            function tW(t) {
                return t$(t).values
            }

            function tH(t) {
                let {
                    split: e,
                    types: i
                } = t$(t), n = e.length;
                return t => {
                    let r = "";
                    for (let s = 0; s < n; s++)
                        if (r += e[s], void 0 !== t[s]) {
                            let e = i[s];
                            e === tU ? r += tC(t[s]) : e === tz ? r += tF.transform(t[s]) : r += t[s]
                        }
                    return r
                }
            }
            let tK = t => "number" == typeof t ? 0 : t,
                tY = {
                    test: function(t) {
                        var e, i;
                        return isNaN(t) && "string" == typeof t && ((null === (e = t.match(tk)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (i = t.match(tB)) || void 0 === i ? void 0 : i.length) || 0) > 0
                    },
                    parse: tW,
                    createTransformer: tH,
                    getAnimatableNone: function(t) {
                        let e = tW(t);
                        return tH(t)(e.map(tK))
                    }
                },
                tX = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function tG(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = i.match(tk) || [];
                if (!n) return t;
                let r = i.replace(n, ""),
                    s = tX.has(e) ? 1 : 0;
                return n !== i && (s *= 100), e + "(" + s + r + ")"
            }
            let tq = /\b([a-z-]*)\(.*?\)/gu,
                tZ = { ...tY,
                    getAnimatableNone: t => {
                        let e = t.match(tq);
                        return e ? e.map(tG).join(" ") : t
                    }
                },
                tQ = { ...ti,
                    transform: Math.round
                },
                tJ = {
                    borderWidth: tl,
                    borderTopWidth: tl,
                    borderRightWidth: tl,
                    borderBottomWidth: tl,
                    borderLeftWidth: tl,
                    borderRadius: tl,
                    radius: tl,
                    borderTopLeftRadius: tl,
                    borderTopRightRadius: tl,
                    borderBottomRightRadius: tl,
                    borderBottomLeftRadius: tl,
                    width: tl,
                    maxWidth: tl,
                    height: tl,
                    maxHeight: tl,
                    top: tl,
                    right: tl,
                    bottom: tl,
                    left: tl,
                    padding: tl,
                    paddingTop: tl,
                    paddingRight: tl,
                    paddingBottom: tl,
                    paddingLeft: tl,
                    margin: tl,
                    marginTop: tl,
                    marginRight: tl,
                    marginBottom: tl,
                    marginLeft: tl,
                    backgroundPositionX: tl,
                    backgroundPositionY: tl,
                    rotate: to,
                    rotateX: to,
                    rotateY: to,
                    rotateZ: to,
                    scale: tr,
                    scaleX: tr,
                    scaleY: tr,
                    scaleZ: tr,
                    skew: to,
                    skewX: to,
                    skewY: to,
                    distance: tl,
                    translateX: tl,
                    translateY: tl,
                    translateZ: tl,
                    x: tl,
                    y: tl,
                    z: tl,
                    perspective: tl,
                    transformPerspective: tl,
                    opacity: tn,
                    originX: td,
                    originY: td,
                    originZ: tl,
                    zIndex: tQ,
                    size: tl,
                    fillOpacity: tn,
                    strokeOpacity: tn,
                    numOctaves: tQ
                },
                t0 = { ...tJ,
                    color: tF,
                    backgroundColor: tF,
                    outlineColor: tF,
                    fill: tF,
                    stroke: tF,
                    borderColor: tF,
                    borderTopColor: tF,
                    borderRightColor: tF,
                    borderBottomColor: tF,
                    borderLeftColor: tF,
                    filter: tZ,
                    WebkitFilter: tZ
                },
                t1 = t => t0[t];

            function t5(t, e) {
                let i = t1(t);
                return i !== tZ && (i = tY), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
            let t2 = new Set(["auto", "none", "0"]);
            class t3 extends tE {
                constructor(t, e, i, n, r) {
                    super(t, e, i, n, r, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e || !e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let n = t[i];
                        if ("string" == typeof n && Q(n = n.trim())) {
                            let r = function t(e, i, n = 1) {
                                (0, Y.V)(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
                                let [r, s] = function(t) {
                                    let e = tt.exec(t);
                                    if (!e) return [, ];
                                    let [, i, n, r] = e;
                                    return [`--${null!=i?i:n}`, r]
                                }(e);
                                if (!r) return;
                                let o = window.getComputedStyle(i).getPropertyValue(r);
                                if (o) {
                                    let t = o.trim();
                                    return X(t) ? parseFloat(t) : t
                                }
                                return Q(s) ? t(s, i, n + 1) : s
                            }(n, e.current);
                            void 0 !== r && (t[i] = r), i === t.length - 1 && (this.finalKeyframe = n)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !tc.has(i) || 2 !== t.length) return;
                    let [n, r] = t, s = tw(n), o = tw(r);
                    if (s !== o) {
                        if (tp(s) && tp(o))
                            for (let e = 0; e < t.length; e++) {
                                let i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++) {
                        var n;
                        ("number" == typeof(n = t[e]) ? 0 === n : null === n || "none" === n || "0" === n || K(n)) && i.push(e)
                    }
                    i.length && function(t, e, i) {
                        let n, r = 0;
                        for (; r < t.length && !n;) {
                            let e = t[r];
                            "string" == typeof e && !t2.has(e) && t$(e).values.length && (n = t[r]), r++
                        }
                        if (n && i)
                            for (let r of e) t[r] = t5(i, n)
                    }(t, i, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t || !t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = ty[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let n = e[e.length - 1];
                    void 0 !== n && t.getValue(i, n).jump(n, !1)
                }
                measureEndState() {
                    var t;
                    let {
                        element: e,
                        name: i,
                        unresolvedKeyframes: n
                    } = this;
                    if (!e || !e.current) return;
                    let r = e.getValue(i);
                    r && r.jump(this.measuredOrigin, !1);
                    let s = n.length - 1,
                        o = n[s];
                    n[s] = ty[i](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach(([t, i]) => {
                        e.getValue(t).set(i)
                    }), this.resolveNoneKeyframes()
                }
            }

            function t6(t) {
                return "function" == typeof t
            }

            function t4() {
                n = void 0
            }
            let t9 = {
                    now: () => (void 0 === n && t9.set(_.isProcessing || P.useManualTiming ? _.timestamp : performance.now()), n),
                    set: t => {
                        n = t, queueMicrotask(t4)
                    }
                },
                t8 = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (tY.test(t) || "0" === t) && !t.startsWith("url("));
            class t7 {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: n = 0,
                    repeatDelay: r = 0,
                    repeatType: s = "loop",
                    ...o
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = t9.now(), this.options = {
                        autoplay: t,
                        delay: e,
                        type: i,
                        repeat: n,
                        repeatDelay: r,
                        repeatType: s,
                        ...o
                    }, this.updateFinishedPromise()
                }
                calcStartTime() {
                    return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (tM(), tA()), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.resolvedAt = t9.now(), this.hasAttemptedResolve = !0;
                    let {
                        name: i,
                        type: n,
                        velocity: r,
                        delay: s,
                        onComplete: o,
                        onUpdate: a,
                        isGenerator: l
                    } = this.options;
                    if (!l && ! function(t, e, i, n) {
                            let r = t[0];
                            if (null === r) return !1;
                            if ("display" === e || "visibility" === e) return !0;
                            let s = t[t.length - 1],
                                o = t8(r, e),
                                a = t8(s, e);
                            return (0, Y.$)(o === a, `You are trying to animate ${e} from "${r}" to "${s}". ${r} is not an animatable value - to enable this animation set ${r} to a value animatable to ${s} via the \`style\` property.`), !!o && !!a && (function(t) {
                                let e = t[0];
                                if (1 === t.length) return !0;
                                for (let i = 0; i < t.length; i++)
                                    if (t[i] !== e) return !0
                            }(t) || ("spring" === i || t6(i)) && n)
                        }(t, i, n, r)) {
                        if (S.current || !s) {
                            null == a || a(A(t, this.options, e)), null == o || o(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let u = this.initPlayback(t, e);
                    !1 !== u && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...u
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                flatten() {
                    this.options.type = "keyframes", this.options.ease = "linear"
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(t => {
                        this.resolveFinishedPromise = t
                    })
                }
            }
            let et = (t, e, i) => {
                    let n = e - t;
                    return 0 === n ? 1 : (i - t) / n
                },
                ee = (t, e, i = 10) => {
                    let n = "",
                        r = Math.max(Math.round(e / i), 2);
                    for (let e = 0; e < r; e++) n += t(et(0, r - 1, e)) + ", ";
                    return `linear(${n.substring(0,n.length-2)})`
                };

            function ei(t, e, i) {
                var n, r;
                let s = Math.max(e - 5, 0);
                return n = i - t(s), (r = e - s) ? 1e3 / r * n : 0
            }
            let en = {
                stiffness: 100,
                damping: 10,
                mass: 1,
                velocity: 0,
                duration: 800,
                bounce: .3,
                visualDuration: .3,
                restSpeed: {
                    granular: .01,
                    default: 2
                },
                restDelta: {
                    granular: .005,
                    default: .5
                },
                minDuration: .01,
                maxDuration: 10,
                minDamping: .05,
                maxDamping: 1
            };

            function er(t, e) {
                return t * Math.sqrt(1 - e * e)
            }

            function es(t) {
                let e = 0,
                    i = t.next(e);
                for (; !i.done && e < 2e4;) e += 50, i = t.next(e);
                return e >= 2e4 ? 1 / 0 : e
            }
            let eo = ["duration", "bounce"],
                ea = ["stiffness", "damping", "mass"];

            function el(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function eu(t = en.visualDuration, e = en.bounce) {
                let i;
                let n = "object" != typeof t ? {
                        visualDuration: t,
                        keyframes: [0, 1],
                        bounce: e
                    } : t,
                    {
                        restSpeed: r,
                        restDelta: s
                    } = n,
                    o = n.keyframes[0],
                    a = n.keyframes[n.keyframes.length - 1],
                    l = {
                        done: !1,
                        value: o
                    },
                    {
                        stiffness: u,
                        damping: h,
                        mass: d,
                        duration: c,
                        velocity: p,
                        isResolvedFromDuration: v
                    } = function(t) {
                        let e = {
                            velocity: en.velocity,
                            stiffness: en.stiffness,
                            damping: en.damping,
                            mass: en.mass,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!el(t, ea) && el(t, eo)) {
                            if (t.visualDuration) {
                                let i = 2 * Math.PI / (1.2 * t.visualDuration),
                                    n = i * i,
                                    r = 2 * te(.05, 1, 1 - t.bounce) * Math.sqrt(n);
                                e = { ...e,
                                    mass: en.mass,
                                    stiffness: n,
                                    damping: r
                                }
                            } else {
                                let i = function({
                                    duration: t = en.duration,
                                    bounce: e = en.bounce,
                                    velocity: i = en.velocity,
                                    mass: n = en.mass
                                }) {
                                    let r, s;
                                    (0, Y.$)(t <= m(en.maxDuration), "Spring duration must be 10 seconds or less");
                                    let o = 1 - e;
                                    o = te(en.minDamping, en.maxDamping, o), t = te(en.minDuration, en.maxDuration, f(t)), o < 1 ? (r = e => {
                                        let n = e * o,
                                            r = n * t;
                                        return .001 - (n - i) / er(e, o) * Math.exp(-r)
                                    }, s = e => {
                                        let n = e * o * t,
                                            s = Math.pow(o, 2) * Math.pow(e, 2) * t,
                                            a = Math.exp(-n),
                                            l = er(Math.pow(e, 2), o);
                                        return (n * i + i - s) * a * (-r(e) + .001 > 0 ? -1 : 1) / l
                                    }) : (r = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), s = e => t * t * (i - e) * Math.exp(-e * t));
                                    let a = function(t, e, i) {
                                        let n = i;
                                        for (let i = 1; i < 12; i++) n -= t(n) / e(n);
                                        return n
                                    }(r, s, 5 / t);
                                    if (t = m(t), isNaN(a)) return {
                                        stiffness: en.stiffness,
                                        damping: en.damping,
                                        duration: t
                                    }; {
                                        let e = Math.pow(a, 2) * n;
                                        return {
                                            stiffness: e,
                                            damping: 2 * o * Math.sqrt(n * e),
                                            duration: t
                                        }
                                    }
                                }(t);
                                (e = { ...e,
                                    ...i,
                                    mass: en.mass
                                }).isResolvedFromDuration = !0
                            }
                        }
                        return e
                    }({ ...n,
                        velocity: -f(n.velocity || 0)
                    }),
                    g = p || 0,
                    y = h / (2 * Math.sqrt(u * d)),
                    x = a - o,
                    b = f(Math.sqrt(u / d)),
                    w = 5 > Math.abs(x);
                if (r || (r = w ? en.restSpeed.granular : en.restSpeed.default), s || (s = w ? en.restDelta.granular : en.restDelta.default), y < 1) {
                    let t = er(b, y);
                    i = e => a - Math.exp(-y * b * e) * ((g + y * b * x) / t * Math.sin(t * e) + x * Math.cos(t * e))
                } else if (1 === y) i = t => a - Math.exp(-b * t) * (x + (g + b * x) * t);
                else {
                    let t = b * Math.sqrt(y * y - 1);
                    i = e => {
                        let i = Math.exp(-y * b * e),
                            n = Math.min(t * e, 300);
                        return a - i * ((g + y * b * x) * Math.sinh(n) + t * x * Math.cosh(n)) / t
                    }
                }
                let P = {
                    calculatedDuration: v && c || null,
                    next: t => {
                        let e = i(t);
                        if (v) l.done = t >= c;
                        else {
                            let n = 0;
                            y < 1 && (n = 0 === t ? m(g) : ei(i, t, e));
                            let o = Math.abs(n) <= r,
                                u = Math.abs(a - e) <= s;
                            l.done = o && u
                        }
                        return l.value = l.done ? a : e, l
                    },
                    toString: () => {
                        let t = Math.min(es(P), 2e4),
                            e = ee(e => P.next(t * e).value, t, 30);
                        return t + "ms " + e
                    }
                };
                return P
            }

            function eh({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: n = 325,
                bounceDamping: r = 10,
                bounceStiffness: s = 500,
                modifyTarget: o,
                min: a,
                max: l,
                restDelta: u = .5,
                restSpeed: h
            }) {
                let d, c;
                let p = t[0],
                    m = {
                        done: !1,
                        value: p
                    },
                    f = t => void 0 !== a && t < a || void 0 !== l && t > l,
                    v = t => void 0 === a ? l : void 0 === l ? a : Math.abs(a - t) < Math.abs(l - t) ? a : l,
                    g = i * e,
                    y = p + g,
                    x = void 0 === o ? y : o(y);
                x !== y && (g = x - p);
                let b = t => -g * Math.exp(-t / n),
                    w = t => x + b(t),
                    P = t => {
                        let e = b(t),
                            i = w(t);
                        m.done = Math.abs(e) <= u, m.value = m.done ? x : i
                    },
                    S = t => {
                        f(m.value) && (d = t, c = eu({
                            keyframes: [m.value, v(m.value)],
                            velocity: ei(w, t, m.value),
                            damping: r,
                            stiffness: s,
                            restDelta: u,
                            restSpeed: h
                        }))
                    };
                return S(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (c || void 0 !== d || (e = !0, P(t), S(t)), void 0 !== d && t >= d) ? c.next(t - d) : (e || P(t), m)
                    }
                }
            }
            let ed = L(.42, 0, 1, 1),
                ec = L(0, 0, .58, 1),
                ep = L(.42, 0, .58, 1),
                em = t => Array.isArray(t) && "number" != typeof t[0],
                ef = t => Array.isArray(t) && "number" == typeof t[0],
                ev = {
                    linear: C.l,
                    easeIn: ed,
                    easeInOut: ep,
                    easeOut: ec,
                    circIn: $,
                    circInOut: H,
                    circOut: W,
                    backIn: U,
                    backInOut: z,
                    backOut: B,
                    anticipate: N
                },
                eg = t => {
                    if (ef(t)) {
                        (0, Y.V)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        let [e, i, n, r] = t;
                        return L(e, i, n, r)
                    }
                    return "string" == typeof t ? ((0, Y.V)(void 0 !== ev[t], `Invalid easing type '${t}'`), ev[t]) : t
                },
                ey = (t, e) => i => e(t(i)),
                ex = (...t) => t.reduce(ey),
                eb = (t, e, i) => t + (e - t) * i;

            function ew(t, e, i) {
                return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
            }

            function eP(t, e) {
                return i => i > 0 ? e : t
            }
            let eS = (t, e, i) => {
                    let n = t * t,
                        r = i * (e * e - n) + n;
                    return r < 0 ? 0 : Math.sqrt(r)
                },
                eT = [tL, tO, tI],
                eA = t => eT.find(e => e.test(t));

            function eM(t) {
                let e = eA(t);
                if ((0, Y.$)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`), !e) return !1;
                let i = e.parse(t);
                return e === tI && (i = function({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: n
                }) {
                    t /= 360, i /= 100;
                    let r = 0,
                        s = 0,
                        o = 0;
                    if (e /= 100) {
                        let n = i < .5 ? i * (1 + e) : i + e - i * e,
                            a = 2 * i - n;
                        r = ew(a, n, t + 1 / 3), s = ew(a, n, t), o = ew(a, n, t - 1 / 3)
                    } else r = s = o = i;
                    return {
                        red: Math.round(255 * r),
                        green: Math.round(255 * s),
                        blue: Math.round(255 * o),
                        alpha: n
                    }
                }(i)), i
            }
            let eE = (t, e) => {
                    let i = eM(t),
                        n = eM(e);
                    if (!i || !n) return eP(t, e);
                    let r = { ...i
                    };
                    return t => (r.red = eS(i.red, n.red, t), r.green = eS(i.green, n.green, t), r.blue = eS(i.blue, n.blue, t), r.alpha = eb(i.alpha, n.alpha, t), tO.transform(r))
                },
                eC = new Set(["none", "hidden"]);

            function ek(t, e) {
                return i => eb(t, e, i)
            }

            function eD(t) {
                return "number" == typeof t ? ek : "string" == typeof t ? Q(t) ? eP : tF.test(t) ? eE : e_ : Array.isArray(t) ? eV : "object" == typeof t ? tF.test(t) ? eE : ej : eP
            }

            function eV(t, e) {
                let i = [...t],
                    n = i.length,
                    r = t.map((t, i) => eD(t)(t, e[i]));
                return t => {
                    for (let e = 0; e < n; e++) i[e] = r[e](t);
                    return i
                }
            }

            function ej(t, e) {
                let i = { ...t,
                        ...e
                    },
                    n = {};
                for (let r in i) void 0 !== t[r] && void 0 !== e[r] && (n[r] = eD(t[r])(t[r], e[r]));
                return t => {
                    for (let e in n) i[e] = n[e](t);
                    return i
                }
            }
            let e_ = (t, e) => {
                let i = tY.createTransformer(e),
                    n = t$(t),
                    r = t$(e);
                return n.indexes.var.length === r.indexes.var.length && n.indexes.color.length === r.indexes.color.length && n.indexes.number.length >= r.indexes.number.length ? eC.has(t) && !r.values.length || eC.has(e) && !n.values.length ? function(t, e) {
                    return eC.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t
                }(t, e) : ex(eV(function(t, e) {
                    var i;
                    let n = [],
                        r = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < e.values.length; s++) {
                        let o = e.types[s],
                            a = t.indexes[o][r[o]],
                            l = null !== (i = t.values[a]) && void 0 !== i ? i : 0;
                        n[s] = l, r[o]++
                    }
                    return n
                }(n, r), r.values), i) : ((0, Y.$)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), eP(t, e))
            };

            function eR(t, e, i) {
                return "number" == typeof t && "number" == typeof e && "number" == typeof i ? eb(t, e, i) : eD(t)(t, e)
            }

            function eO({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: n = "easeInOut"
            }) {
                let r = em(n) ? n.map(eg) : eg(n),
                    s = {
                        done: !1,
                        value: e[0]
                    },
                    o = function(t, e, {
                        clamp: i = !0,
                        ease: n,
                        mixer: r
                    } = {}) {
                        let s = t.length;
                        if ((0, Y.V)(s === e.length, "Both input and output ranges must be the same length"), 1 === s) return () => e[0];
                        if (2 === s && t[0] === t[1]) return () => e[1];
                        t[0] > t[s - 1] && (t = [...t].reverse(), e = [...e].reverse());
                        let o = function(t, e, i) {
                                let n = [],
                                    r = i || eR,
                                    s = t.length - 1;
                                for (let i = 0; i < s; i++) {
                                    let s = r(t[i], t[i + 1]);
                                    e && (s = ex(Array.isArray(e) ? e[i] || C.l : e, s)), n.push(s)
                                }
                                return n
                            }(e, n, r),
                            a = o.length,
                            l = e => {
                                let i = 0;
                                if (a > 1)
                                    for (; i < t.length - 2 && !(e < t[i + 1]); i++);
                                let n = et(t[i], t[i + 1], e);
                                return o[i](n)
                            };
                        return i ? e => l(te(t[0], t[s - 1], e)) : l
                    }((i && i.length === e.length ? i : function(t) {
                        let e = [0];
                        return function(t, e) {
                            let i = t[t.length - 1];
                            for (let n = 1; n <= e; n++) {
                                let r = et(0, e, n);
                                t.push(eb(i, 1, r))
                            }
                        }(e, t.length - 1), e
                    }(e)).map(e => e * t), e, {
                        ease: Array.isArray(r) ? r : e.map(() => r || ep).splice(0, e.length - 1)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (s.value = o(e), s.done = e >= t, s)
                }
            }
            let eL = t => {
                    let e = ({
                        timestamp: e
                    }) => t(e);
                    return {
                        start: () => V.update(e, !0),
                        stop: () => j(e),
                        now: () => _.isProcessing ? _.timestamp : t9.now()
                    }
                },
                eI = {
                    decay: eh,
                    inertia: eh,
                    tween: eO,
                    keyframes: eO,
                    spring: eu
                },
                eF = t => t / 100;
            class eB extends t7 {
                constructor(t) {
                    super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        let {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    let {
                        name: e,
                        motionValue: i,
                        element: n,
                        keyframes: r
                    } = this.options, s = (null == n ? void 0 : n.KeyframeResolver) || tE;
                    this.resolver = new s(r, (t, e) => this.onKeyframesResolved(t, e), e, i, n), this.resolver.scheduleResolve()
                }
                flatten() {
                    super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
                }
                initPlayback(t) {
                    let e, i;
                    let {
                        type: n = "keyframes",
                        repeat: r = 0,
                        repeatDelay: s = 0,
                        repeatType: o,
                        velocity: a = 0
                    } = this.options, l = t6(n) ? n : eI[n] || eO;
                    l !== eO && "number" != typeof t[0] && (e = ex(eF, eR(t[0], t[1])), t = [0, 100]);
                    let u = l({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === o && (i = l({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = es(u));
                    let {
                        calculatedDuration: h
                    } = u, d = h + s;
                    return {
                        generator: u,
                        mirroredGenerator: i,
                        mapPercentToKeyframes: e,
                        calculatedDuration: h,
                        resolvedDuration: d,
                        totalDuration: d * (r + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    let {
                        resolved: i
                    } = this;
                    if (!i) {
                        let {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: n,
                        generator: r,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: o,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: u,
                        resolvedDuration: h
                    } = i;
                    if (null === this.startTime) return r.next(0);
                    let {
                        delay: d,
                        repeat: c,
                        repeatType: p,
                        repeatDelay: m,
                        onUpdate: f
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - u / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    let v = this.currentTime - d * (this.speed >= 0 ? 1 : -1),
                        g = this.speed >= 0 ? v < 0 : v > u;
                    this.currentTime = Math.max(v, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = u);
                    let y = this.currentTime,
                        x = r;
                    if (c) {
                        let t = Math.min(this.currentTime, u) / h,
                            e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, c + 1)) % 2 && ("reverse" === p ? (i = 1 - i, m && (i -= m / h)) : "mirror" === p && (x = s)), y = te(0, 1, i) * h
                    }
                    let b = g ? {
                        done: !1,
                        value: a[0]
                    } : x.next(y);
                    o && (b.value = o(b.value));
                    let {
                        done: w
                    } = b;
                    g || null === l || (w = this.speed >= 0 ? this.currentTime >= u : this.currentTime <= 0);
                    let P = null === this.holdTime && ("finished" === this.state || "running" === this.state && w);
                    return P && void 0 !== n && (b.value = A(a, this.options, n)), f && f(b.value), P && this.finish(), b
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    return t ? f(t.calculatedDuration) : 0
                }
                get time() {
                    return f(this.currentTime)
                }
                set time(t) {
                    t = m(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = f(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: t = eL,
                        onPlay: e,
                        startTime: i
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), e && e();
                    let n = this.driver.now();
                    null !== this.holdTime ? this.startTime = n - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = n) : this.startTime = null != i ? i : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }
            let eU = new Set(["opacity", "clipPath", "filter", "transform"]);

            function ez(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
            let eN = {
                    linearEasing: void 0
                },
                e$ = function(t, e) {
                    let i = ez(t);
                    return () => {
                        var t;
                        return null !== (t = eN[e]) && void 0 !== t ? t : i()
                    }
                }(() => {
                    try {
                        document.createElement("div").animate({
                            opacity: 0
                        }, {
                            easing: "linear(0, 1)"
                        })
                    } catch (t) {
                        return !1
                    }
                    return !0
                }, "linearEasing"),
                eW = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
                eH = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: eW([0, .65, .55, 1]),
                    circOut: eW([.55, 0, 1, .45]),
                    backIn: eW([.31, .01, .66, -.59]),
                    backOut: eW([.33, 1.53, .69, .99])
                };

            function eK(t, e) {
                t.timeline = e, t.onfinish = null
            }
            let eY = ez(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
                eX = {
                    anticipate: N,
                    backInOut: z,
                    circInOut: H
                };
            class eG extends t7 {
                constructor(t) {
                    super(t);
                    let {
                        name: e,
                        motionValue: i,
                        element: n,
                        keyframes: r
                    } = this.options;
                    this.resolver = new t3(r, (t, e) => this.onKeyframesResolved(t, e), e, i, n), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    var i, n;
                    let {
                        duration: r = 300,
                        times: s,
                        ease: o,
                        type: a,
                        motionValue: l,
                        name: u,
                        startTime: h
                    } = this.options;
                    if (!(null === (i = l.owner) || void 0 === i ? void 0 : i.current)) return !1;
                    if ("string" == typeof o && e$() && o in eX && (o = eX[o]), t6((n = this.options).type) || "spring" === n.type || ! function t(e) {
                            return !!("function" == typeof e && e$() || !e || "string" == typeof e && (e in eH || e$()) || ef(e) || Array.isArray(e) && e.every(t))
                        }(n.ease)) {
                        let {
                            onComplete: e,
                            onUpdate: i,
                            motionValue: n,
                            element: l,
                            ...u
                        } = this.options, h = function(t, e) {
                            let i = new eB({ ...e,
                                    keyframes: t,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                n = {
                                    done: !1,
                                    value: t[0]
                                },
                                r = [],
                                s = 0;
                            for (; !n.done && s < 2e4;) r.push((n = i.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: r,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(t, u);
                        1 === (t = h.keyframes).length && (t[1] = t[0]), r = h.duration, s = h.times, o = h.ease, a = "keyframes"
                    }
                    let d = function(t, e, i, {
                        delay: n = 0,
                        duration: r = 300,
                        repeat: s = 0,
                        repeatType: o = "loop",
                        ease: a = "easeInOut",
                        times: l
                    } = {}) {
                        let u = {
                            [e]: i
                        };
                        l && (u.offset = l);
                        let h = function t(e, i) {
                            if (e) return "function" == typeof e && e$() ? ee(e, i) : ef(e) ? eW(e) : Array.isArray(e) ? e.map(e => t(e, i) || eH.easeOut) : eH[e]
                        }(a, r);
                        return Array.isArray(h) && (u.easing = h), t.animate(u, {
                            delay: n,
                            duration: r,
                            easing: Array.isArray(h) ? "linear" : h,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === o ? "alternate" : "normal"
                        })
                    }(l.owner.current, u, t, { ...this.options,
                        duration: r,
                        times: s,
                        ease: o
                    });
                    return d.startTime = null != h ? h : this.calcStartTime(), this.pendingTimeline ? (eK(d, this.pendingTimeline), this.pendingTimeline = void 0) : d.onfinish = () => {
                        let {
                            onComplete: i
                        } = this.options;
                        l.set(A(t, this.options, e)), i && i(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: d,
                        duration: r,
                        times: s,
                        type: a,
                        ease: o,
                        keyframes: t
                    }
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        duration: e
                    } = t;
                    return f(e)
                }
                get time() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        animation: e
                    } = t;
                    return f(e.currentTime || 0)
                }
                set time(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.currentTime = m(t)
                }
                get speed() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    let {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.playbackRate = t
                }
                get state() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    let {
                        animation: e
                    } = t;
                    return e.playState
                }
                get startTime() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return null;
                    let {
                        animation: e
                    } = t;
                    return e.startTime
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        let {
                            resolved: e
                        } = this;
                        if (!e) return C.l;
                        let {
                            animation: i
                        } = e;
                        eK(i, t)
                    } else this.pendingTimeline = t;
                    return C.l
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.resolveFinishedPromise(), this.updateFinishedPromise();
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e,
                        keyframes: i,
                        duration: n,
                        type: r,
                        ease: s,
                        times: o
                    } = t;
                    if ("idle" === e.playState || "finished" === e.playState) return;
                    if (this.time) {
                        let {
                            motionValue: t,
                            onUpdate: e,
                            onComplete: a,
                            element: l,
                            ...u
                        } = this.options, h = new eB({ ...u,
                            keyframes: i,
                            duration: n,
                            type: r,
                            ease: s,
                            times: o,
                            isGenerator: !0
                        }), d = m(this.time);
                        t.setWithVelocity(h.sample(d - 10).value, h.sample(d).value, 10)
                    }
                    let {
                        onStop: a
                    } = this.options;
                    a && a(), this.cancel()
                }
                complete() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: n,
                        repeatType: r,
                        damping: s,
                        type: o
                    } = t;
                    return eY() && i && eU.has(i) && e && e.owner && e.owner.current instanceof HTMLElement && !e.owner.getProps().onUpdate && !n && "mirror" !== r && 0 !== s && "inertia" !== o
                }
            }
            let eq = ez(() => void 0 !== window.ScrollTimeline);
            class eZ {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let i = 0; i < this.animations.length; i++) this.animations[i][t] = e
                }
                attachTimeline(t, e) {
                    let i = this.animations.map(i => eq() && i.attachTimeline ? i.attachTimeline(t) : e(i));
                    return () => {
                        i.forEach((t, e) => {
                            t && t(), this.animations[e].stop()
                        })
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get startTime() {
                    return this.getAll("startTime")
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach(e => e[t]())
                }
                flatten() {
                    this.runAll("flatten")
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            let eQ = (t, e, i, n = {}, r, s) => o => {
                    let a = w(n, t) || {},
                        l = a.delay || n.delay || 0,
                        {
                            elapsed: u = 0
                        } = n;
                    u -= m(l);
                    let h = {
                        keyframes: Array.isArray(i) ? i : [null, i],
                        ease: "easeOut",
                        velocity: e.getVelocity(),
                        ...a,
                        delay: -u,
                        onUpdate: t => {
                            e.set(t), a.onUpdate && a.onUpdate(t)
                        },
                        onComplete: () => {
                            o(), a.onComplete && a.onComplete()
                        },
                        name: t,
                        motionValue: e,
                        element: s ? void 0 : r
                    };
                    ! function({
                        when: t,
                        delay: e,
                        delayChildren: i,
                        staggerChildren: n,
                        staggerDirection: r,
                        repeat: s,
                        repeatType: o,
                        repeatDelay: a,
                        from: l,
                        elapsed: u,
                        ...h
                    }) {
                        return !!Object.keys(h).length
                    }(a) && (h = { ...h,
                        ...b(t, h)
                    }), h.duration && (h.duration = m(h.duration)), h.repeatDelay && (h.repeatDelay = m(h.repeatDelay)), void 0 !== h.from && (h.keyframes[0] = h.from);
                    let d = !1;
                    if (!1 !== h.type && (0 !== h.duration || h.repeatDelay) || (h.duration = 0, 0 !== h.delay || (d = !0)), (S.current || P.skipAnimations) && (d = !0, h.duration = 0, h.delay = 0), d && !s && void 0 !== e.get()) {
                        let t = A(h.keyframes, a);
                        if (void 0 !== t) return V.update(() => {
                            h.onUpdate(t), h.onComplete()
                        }), new eZ([])
                    }
                    return !s && eG.supports(h) ? new eG(h) : new eB(h)
                },
                eJ = t => !!(t && "object" == typeof t && t.mix && t.toValue),
                e0 = t => s(t) ? t[t.length - 1] || 0 : t;

            function e1(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function e5(t, e) {
                let i = t.indexOf(e);
                i > -1 && t.splice(i, 1)
            }
            class e2 {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return e1(this.subscriptions, t), () => e5(this.subscriptions, t)
                }
                notify(t, e, i) {
                    let n = this.subscriptions.length;
                    if (n) {
                        if (1 === n) this.subscriptions[0](t, e, i);
                        else
                            for (let r = 0; r < n; r++) {
                                let n = this.subscriptions[r];
                                n && n(t, e, i)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
            let e3 = t => !isNaN(parseFloat(t)),
                e6 = {
                    current: void 0
                };
            class e4 {
                constructor(t, e = {}) {
                    this.version = "11.14.1", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        let i = t9.now();
                        this.updatedAt !== i && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    this.current = t, this.updatedAt = t9.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = e3(this.current))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new e2);
                    let i = this.events[t].add(e);
                    return "change" === t ? () => {
                        i(), V.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : i
                }
                clearListeners() {
                    for (let t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, i) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return e6.current && e6.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    var t;
                    let e = t9.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
                    let i = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return t = parseFloat(this.current) - parseFloat(this.prevFrameValue), i ? 1e3 / i * t : 0
                }
                start(t) {
                    return this.stop(), new Promise(e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function e9(t, e) {
                return new e4(t, e)
            }
            let e8 = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
                e7 = "data-" + e8("framerAppearId"),
                it = t => !!(t && t.getVelocity);

            function ie(t, e) {
                let i = t.getValue("willChange");
                if (it(i) && i.add) return i.add(e)
            }

            function ii(t, e, {
                delay: i = 0,
                transitionOverride: n,
                type: r
            } = {}) {
                var s;
                let {
                    transition: o = t.getDefaultTransition(),
                    transitionEnd: a,
                    ...l
                } = e;
                n && (o = n);
                let h = [],
                    d = r && t.animationState && t.animationState.getState()[r];
                for (let e in l) {
                    let n = t.getValue(e, null !== (s = t.latestValues[e]) && void 0 !== s ? s : null),
                        r = l[e];
                    if (void 0 === r || d && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let n = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, n
                        }(d, e)) continue;
                    let a = {
                            delay: i,
                            ...w(o || {}, e)
                        },
                        u = !1;
                    if (window.MotionHandoffAnimation) {
                        let i = t.props[e7];
                        if (i) {
                            let t = window.MotionHandoffAnimation(i, e, V);
                            null !== t && (a.startTime = t, u = !0)
                        }
                    }
                    ie(t, e), n.start(eQ(e, n, r, t.shouldReduceMotion && p.has(e) ? {
                        type: !1
                    } : a, t, u));
                    let c = n.animation;
                    c && h.push(c)
                }
                return a && Promise.all(h).then(() => {
                    V.update(() => {
                        a && function(t, e) {
                            let {
                                transitionEnd: i = {},
                                transition: n = {},
                                ...r
                            } = u(t, e) || {};
                            for (let e in r = { ...r,
                                    ...i
                                }) {
                                let i = e0(r[e]);
                                t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, e9(i))
                            }
                        }(t, a)
                    })
                }), h
            }

            function ir(t, e, i = {}) {
                var n;
                let r = u(t, e, "exit" === i.type ? null === (n = t.presenceContext) || void 0 === n ? void 0 : n.custom : void 0),
                    {
                        transition: s = t.getDefaultTransition() || {}
                    } = r || {};
                i.transitionOverride && (s = i.transitionOverride);
                let o = r ? () => Promise.all(ii(t, r, i)) : () => Promise.resolve(),
                    a = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                        let {
                            delayChildren: r = 0,
                            staggerChildren: o,
                            staggerDirection: a
                        } = s;
                        return function(t, e, i = 0, n = 0, r = 1, s) {
                            let o = [],
                                a = (t.variantChildren.size - 1) * n,
                                l = 1 === r ? (t = 0) => t * n : (t = 0) => a - t * n;
                            return Array.from(t.variantChildren).sort(is).forEach((t, n) => {
                                t.notify("AnimationStart", e), o.push(ir(t, e, { ...s,
                                    delay: i + l(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(o)
                        }(t, e, r + n, o, a, i)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = s;
                if (!l) return Promise.all([o(), a(i.delay)]); {
                    let [t, e] = "beforeChildren" === l ? [o, a] : [a, o];
                    return t().then(() => e())
                }
            }

            function is(t, e) {
                return t.sortNodePosition(e)
            }
            let io = d.length,
                ia = [...h].reverse(),
                il = h.length;

            function iu(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function ih() {
                return {
                    animate: iu(!0),
                    whileInView: iu(),
                    whileHover: iu(),
                    whileTap: iu(),
                    whileDrag: iu(),
                    whileFocus: iu(),
                    exit: iu()
                }
            }
            class id {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }
            class ic extends id {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (function(t, e, i = {}) {
                                let n;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) n = Promise.all(e.map(e => ir(t, e, i)));
                                else if ("string" == typeof e) n = ir(t, e, i);
                                else {
                                    let r = "function" == typeof e ? u(t, e, i.custom) : e;
                                    n = Promise.all(ii(t, r, i))
                                }
                                return n.then(() => {
                                    t.notify("AnimationComplete", e)
                                })
                            })(t, e, i))),
                            i = ih(),
                            n = !0,
                            l = e => (i, n) => {
                                var r;
                                let s = u(t, n, "exit" === e ? null === (r = t.presenceContext) || void 0 === r ? void 0 : r.custom : void 0);
                                if (s) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...n
                                    } = s;
                                    i = { ...i,
                                        ...n,
                                        ...e
                                    }
                                }
                                return i
                            };

                        function h(u) {
                            let {
                                props: h
                            } = t, c = function t(e) {
                                if (!e) return;
                                if (!e.isControllingVariants) {
                                    let i = e.parent && t(e.parent) || {};
                                    return void 0 !== e.props.initial && (i.initial = e.props.initial), i
                                }
                                let i = {};
                                for (let t = 0; t < io; t++) {
                                    let n = d[t],
                                        r = e.props[n];
                                    (a(r) || !1 === r) && (i[n] = r)
                                }
                                return i
                            }(t.parent) || {}, p = [], m = new Set, f = {}, v = 1 / 0;
                            for (let e = 0; e < il; e++) {
                                var g;
                                let d = ia[e],
                                    y = i[d],
                                    x = void 0 !== h[d] ? h[d] : c[d],
                                    b = a(x),
                                    w = d === u ? y.isActive : null;
                                !1 === w && (v = e);
                                let P = x === c[d] && x !== h[d] && b;
                                if (P && n && t.manuallyAnimateOnMount && (P = !1), y.protectedKeys = { ...f
                                    }, !y.isActive && null === w || !x && !y.prevProp || r(x) || "boolean" == typeof x) continue;
                                let S = (g = y.prevProp, "string" == typeof x ? x !== g : !!Array.isArray(x) && !o(x, g)),
                                    T = S || d === u && y.isActive && !P && b || e > v && b,
                                    A = !1,
                                    M = Array.isArray(x) ? x : [x],
                                    E = M.reduce(l(d), {});
                                !1 === w && (E = {});
                                let {
                                    prevResolvedValues: C = {}
                                } = y, k = { ...C,
                                    ...E
                                }, D = e => {
                                    T = !0, m.has(e) && (A = !0, m.delete(e)), y.needsAnimating[e] = !0;
                                    let i = t.getValue(e);
                                    i && (i.liveStyle = !1)
                                };
                                for (let t in k) {
                                    let e = E[t],
                                        i = C[t];
                                    if (!f.hasOwnProperty(t))(s(e) && s(i) ? o(e, i) : e === i) ? void 0 !== e && m.has(t) ? D(t) : y.protectedKeys[t] = !0 : null != e ? D(t) : m.add(t)
                                }
                                y.prevProp = x, y.prevResolvedValues = E, y.isActive && (f = { ...f,
                                    ...E
                                }), n && t.blockInitialAnimation && (T = !1);
                                let V = !(P && S) || A;
                                T && V && p.push(...M.map(t => ({
                                    animation: t,
                                    options: {
                                        type: d
                                    }
                                })))
                            }
                            if (m.size) {
                                let e = {};
                                m.forEach(i => {
                                    let n = t.getBaseTarget(i),
                                        r = t.getValue(i);
                                    r && (r.liveStyle = !0), e[i] = null != n ? n : null
                                }), p.push({
                                    animation: e
                                })
                            }
                            let y = !!p.length;
                            return n && (!1 === h.initial || h.initial === h.animate) && !t.manuallyAnimateOnMount && (y = !1), n = !1, y ? e(p) : Promise.resolve()
                        }
                        return {
                            animateChanges: h,
                            setActive: function(e, n) {
                                var r;
                                if (i[e].isActive === n) return Promise.resolve();
                                null === (r = t.variantChildren) || void 0 === r || r.forEach(t => {
                                    var i;
                                    return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, n)
                                }), i[e].isActive = n;
                                let s = h(e);
                                for (let t in i) i[t].protectedKeys = {};
                                return s
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i,
                            reset: () => {
                                i = ih(), n = !0
                            }
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    r(t) && (this.unmountControls = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {
                    var t;
                    this.node.animationState.reset(), null === (t = this.unmountControls) || void 0 === t || t.call(this)
                }
            }
            let ip = 0;
            class im extends id {
                constructor() {
                    super(...arguments), this.id = ip++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: i
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === i) return;
                    let n = this.node.animationState.setActive("exit", !t);
                    e && !t && n.then(() => e(this.id))
                }
                mount() {
                    let {
                        register: t
                    } = this.node.presenceContext || {};
                    t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            let iv = {
                x: !1,
                y: !1
            };

            function ig(t, e) {
                let i = function(t, e, i) {
                        if (t instanceof Element) return [t];
                        if ("string" == typeof t) {
                            let e = document.querySelectorAll(t);
                            return e ? Array.from(e) : []
                        }
                        return Array.from(t)
                    }(t),
                    n = new AbortController;
                return [i, {
                    passive: !0,
                    ...e,
                    signal: n.signal
                }, () => n.abort()]
            }

            function iy(t) {
                return e => {
                    "touch" === e.pointerType || iv.x || iv.y || t(e)
                }
            }
            let ix = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary,
                ib = new WeakSet;

            function iw(t) {
                return e => {
                    "Enter" === e.key && t(e)
                }
            }

            function iP(t, e) {
                t.dispatchEvent(new PointerEvent("pointer" + e, {
                    isPrimary: !0,
                    bubbles: !0
                }))
            }
            let iS = (t, e) => {
                    let i = t.currentTarget;
                    if (!i) return;
                    let n = iw(() => {
                        if (ib.has(i)) return;
                        iP(i, "down");
                        let t = iw(() => {
                            iP(i, "up")
                        });
                        i.addEventListener("keyup", t, e), i.addEventListener("blur", () => iP(i, "cancel"), e)
                    });
                    i.addEventListener("keydown", n, e), i.addEventListener("blur", () => i.removeEventListener("keydown", n), e)
                },
                iT = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]),
                iA = (t, e) => !!e && (t === e || iA(t, e.parentElement));

            function iM(t) {
                return ix(t) && !(iv.x || iv.y)
            }

            function iE(t) {
                return {
                    point: {
                        x: t.pageX,
                        y: t.pageY
                    }
                }
            }
            let iC = t => e => ix(e) && t(e, iE(e));

            function ik(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }

            function iD(t, e, i, n) {
                return ik(t, e, iC(i), n)
            }
            let iV = (t, e) => Math.abs(t - e);
            class ij {
                constructor(t, e, {
                    transformPagePoint: i,
                    contextWindow: n,
                    dragSnapToOrigin: r = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let t = iO(this.lastMoveEventInfo, this.history),
                                e = null !== this.startEvent,
                                i = function(t, e) {
                                    return Math.sqrt(iV(t.x, e.x) ** 2 + iV(t.y, e.y) ** 2)
                                }(t.offset, {
                                    x: 0,
                                    y: 0
                                }) >= 3;
                            if (!e && !i) return;
                            let {
                                point: n
                            } = t, {
                                timestamp: r
                            } = _;
                            this.history.push({ ...n,
                                timestamp: r
                            });
                            let {
                                onStart: s,
                                onMove: o
                            } = this.handlers;
                            e || (s && s(this.lastMoveEvent, t), this.startEvent = this.lastMoveEvent), o && o(this.lastMoveEvent, t)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = i_(e, this.transformPagePoint), V.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: i,
                                onSessionEnd: n,
                                resumeAnimation: r
                            } = this.handlers;
                            if (this.dragSnapToOrigin && r && r(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = iO("pointercancel" === t.type ? this.lastMoveEventInfo : i_(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, s), n && n(t, s)
                        }, !ix(t)) return;
                    this.dragSnapToOrigin = r, this.handlers = e, this.transformPagePoint = i, this.contextWindow = n || window;
                    let s = i_(iE(t), this.transformPagePoint),
                        {
                            point: o
                        } = s,
                        {
                            timestamp: a
                        } = _;
                    this.history = [{ ...o,
                        timestamp: a
                    }];
                    let {
                        onSessionStart: l
                    } = e;
                    l && l(t, iO(s, this.history)), this.removeListeners = ex(iD(this.contextWindow, "pointermove", this.handlePointerMove), iD(this.contextWindow, "pointerup", this.handlePointerUp), iD(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), j(this.updatePoint)
                }
            }

            function i_(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function iR(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function iO({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: iR(t, iL(e)),
                    offset: iR(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let i = t.length - 1,
                            n = null,
                            r = iL(t);
                        for (; i >= 0 && (n = t[i], !(r.timestamp - n.timestamp > m(.1)));) i--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let s = f(r.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (r.x - n.x) / s,
                            y: (r.y - n.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(e, 0)
                }
            }

            function iL(t) {
                return t[t.length - 1]
            }

            function iI(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }

            function iF(t) {
                return t.max - t.min
            }

            function iB(t, e, i, n = .5) {
                t.origin = n, t.originPoint = eb(e.min, e.max, t.origin), t.scale = iF(i) / iF(e), t.translate = eb(i.min, i.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
            }

            function iU(t, e, i, n) {
                iB(t.x, e.x, i.x, n ? n.originX : void 0), iB(t.y, e.y, i.y, n ? n.originY : void 0)
            }

            function iz(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + iF(e)
            }

            function iN(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + iF(e)
            }

            function i$(t, e, i) {
                iN(t.x, e.x, i.x), iN(t.y, e.y, i.y)
            }

            function iW(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function iH(t, e) {
                let i = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
                    min: i,
                    max: n
                }
            }

            function iK(t, e, i) {
                return {
                    min: iY(t, e),
                    max: iY(t, i)
                }
            }

            function iY(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            let iX = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                iG = () => ({
                    x: iX(),
                    y: iX()
                }),
                iq = () => ({
                    min: 0,
                    max: 0
                }),
                iZ = () => ({
                    x: iq(),
                    y: iq()
                });

            function iQ(t) {
                return [t("x"), t("y")]
            }

            function iJ({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function i0(t) {
                return void 0 === t || 1 === t
            }

            function i1({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !i0(t) || !i0(e) || !i0(i)
            }

            function i5(t) {
                return i1(t) || i2(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function i2(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }

            function i3(t, e, i, n, r) {
                return void 0 !== r && (t = n + r * (t - n)), n + i * (t - n) + e
            }

            function i6(t, e = 0, i = 1, n, r) {
                t.min = i3(t.min, e, i, n, r), t.max = i3(t.max, e, i, n, r)
            }

            function i4(t, {
                x: e,
                y: i
            }) {
                i6(t.x, e.translate, e.scale, e.originPoint), i6(t.y, i.translate, i.scale, i.originPoint)
            }

            function i9(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function i8(t, e, i, n, r = .5) {
                let s = eb(t.min, t.max, r);
                i6(t, e, i, s, n)
            }

            function i7(t, e) {
                i8(t.x, e.x, e.scaleX, e.scale, e.originX), i8(t.y, e.y, e.scaleY, e.scale, e.originY)
            }

            function nt(t, e) {
                return iJ(function(t, e) {
                    if (!e) return t;
                    let i = e({
                            x: t.left,
                            y: t.top
                        }),
                        n = e({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: i.y,
                        left: i.x,
                        bottom: n.y,
                        right: n.x
                    }
                }(t.getBoundingClientRect(), e))
            }
            let ne = ({
                    current: t
                }) => t ? t.ownerDocument.defaultView : null,
                ni = new WeakMap;
            class nn {
                constructor(t) {
                    this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = iZ(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    let {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    let {
                        dragSnapToOrigin: n
                    } = this.getProps();
                    this.panSession = new ij(t, {
                        onSessionStart: t => {
                            let {
                                dragSnapToOrigin: i
                            } = this.getProps();
                            i ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(iE(t).point)
                        },
                        onStart: (t, e) => {
                            let {
                                drag: i,
                                dragPropagation: n,
                                onDragStart: r
                            } = this.getProps();
                            if (i && !n && (this.openDragLock && this.openDragLock(), this.openDragLock = "x" === i || "y" === i ? iv[i] ? null : (iv[i] = !0, () => {
                                    iv[i] = !1
                                }) : iv.x || iv.y ? null : (iv.x = iv.y = !0, () => {
                                    iv.x = iv.y = !1
                                }), !this.openDragLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), iQ(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (ta.test(e)) {
                                    let {
                                        projection: i
                                    } = this.visualElement;
                                    if (i && i.layout) {
                                        let n = i.layout.layoutBox[t];
                                        n && (e = iF(n) * (parseFloat(e) / 100))
                                    }
                                }
                                this.originPoint[t] = e
                            }), r && V.postRender(() => r(t, e)), ie(this.visualElement, "transform");
                            let {
                                animationState: s
                            } = this.visualElement;
                            s && s.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            let {
                                dragPropagation: i,
                                dragDirectionLock: n,
                                onDirectionLock: r,
                                onDrag: s
                            } = this.getProps();
                            if (!i && !this.openDragLock) return;
                            let {
                                offset: o
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let i = null;
                                    return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                                }(o), null !== this.currentDirection && r && r(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, o), this.updateAxis("y", e.point, o), this.visualElement.render(), s && s(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => iQ(t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: n,
                        contextWindow: ne(this.visualElement)
                    })
                }
                stop(t, e) {
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    r && V.postRender(() => r(t, e))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, i) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!i || !nr(t, n, this.currentDirection)) return;
                    let r = this.getAxisMotionValue(t),
                        s = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (s = function(t, {
                        min: e,
                        max: i
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? eb(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? eb(i, t, n.max) : Math.min(t, i)), t
                    }(s, this.constraints[t], this.elastic[t])), r.set(s)
                }
                resolveConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        dragElastic: i
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, r = this.constraints;
                    e && iI(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = function(t, {
                        top: e,
                        left: i,
                        bottom: n,
                        right: r
                    }) {
                        return {
                            x: iW(t.x, i, r),
                            y: iW(t.y, e, n)
                        }
                    }(n.layoutBox, e) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: iK(t, "left", "right"),
                            y: iK(t, "top", "bottom")
                        }
                    }(i), r !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && iQ(t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(n.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: i
                    } = this.getProps();
                    if (!e || !iI(e)) return !1;
                    let n = e.current;
                    (0, Y.V)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: r
                    } = this.visualElement;
                    if (!r || !r.layout) return !1;
                    let s = function(t, e, i) {
                            let n = nt(t, i),
                                {
                                    scroll: r
                                } = e;
                            return r && (i9(n.x, r.offset.x), i9(n.y, r.offset.y)), n
                        }(n, r.root, this.visualElement.getTransformPagePoint()),
                        o = {
                            x: iH((t = r.layout.layoutBox).x, s.x),
                            y: iH(t.y, s.y)
                        };
                    if (i) {
                        let t = i(function({
                            x: t,
                            y: e
                        }) {
                            return {
                                top: e.min,
                                right: t.max,
                                bottom: e.max,
                                left: t.min
                            }
                        }(o));
                        this.hasMutatedConstraints = !!t, t && (o = iJ(t))
                    }
                    return o
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: n,
                        dragTransition: r,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: o
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all(iQ(o => {
                        if (!nr(o, e, this.currentDirection)) return;
                        let l = a && a[o] || {};
                        s && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: i ? t[o] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...r,
                            ...l
                        };
                        return this.startAxisValueAnimation(o, u)
                    })).then(o)
                }
                startAxisValueAnimation(t, e) {
                    let i = this.getAxisMotionValue(t);
                    return ie(this.visualElement, t), i.start(eQ(t, i, 0, e, this.visualElement, !1))
                }
                stopAnimation() {
                    iQ(t => this.getAxisMotionValue(t).stop())
                }
                pauseAnimation() {
                    iQ(t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    })
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    let e = `_drag${t.toUpperCase()}`,
                        i = this.visualElement.getProps();
                    return i[e] || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    iQ(e => {
                        let {
                            drag: i
                        } = this.getProps();
                        if (!nr(e, i, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: i,
                                max: s
                            } = n.layout.layoutBox[e];
                            r.set(t[e] - eb(i, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: i
                    } = this.visualElement;
                    if (!iI(e) || !i || !this.constraints) return;
                    this.stopAnimation();
                    let n = {
                        x: 0,
                        y: 0
                    };
                    iQ(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            let i = e.get();
                            n[t] = function(t, e) {
                                let i = .5,
                                    n = iF(t),
                                    r = iF(e);
                                return r > n ? i = et(e.min, e.max - n, t.min) : n > r && (i = et(t.min, t.max - r, e.min)), te(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: r
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = r ? r({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.resolveConstraints(), iQ(e => {
                        if (!nr(e, t, null)) return;
                        let i = this.getAxisMotionValue(e),
                            {
                                min: r,
                                max: s
                            } = this.constraints[e];
                        i.set(eb(r, s, n[e]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    ni.set(this.visualElement, this);
                    let t = iD(this.visualElement.current, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        }),
                        e = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            iI(t) && t.current && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: i
                        } = this.visualElement,
                        n = i.addEventListener("measure", e);
                    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), V.read(e);
                    let r = ik(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = i.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (iQ(e => {
                                let i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        r(), t(), n(), s && s()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: n = !1,
                            dragConstraints: r = !1,
                            dragElastic: s = .35,
                            dragMomentum: o = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: n,
                        dragConstraints: r,
                        dragElastic: s,
                        dragMomentum: o
                    }
                }
            }

            function nr(t, e, i) {
                return (!0 === e || e === t) && (null === i || i === t)
            }
            class ns extends id {
                constructor(t) {
                    super(t), this.removeGroupControls = C.l, this.removeListeners = C.l, this.controls = new nn(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || C.l
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let no = t => (e, i) => {
                t && V.postRender(() => t(e, i))
            };
            class na extends id {
                constructor() {
                    super(...arguments), this.removePointerDownListener = C.l
                }
                onPointerDown(t) {
                    this.session = new ij(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: ne(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: i,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: no(t),
                        onStart: no(e),
                        onMove: i,
                        onEnd: (t, e) => {
                            delete this.session, n && V.postRender(() => n(t, e))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = iD(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            var nl = i(5155),
                nu = i(2115),
                nh = i(9656),
                nd = i(4710);
            let nc = (0, nu.createContext)({}),
                np = {
                    hasAnimatedSinceResize: !0,
                    hasEverUpdated: !1
                };

            function nm(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let nf = {
                    correct: (t, e) => {
                        if (!e.target) return t;
                        if ("string" == typeof t) {
                            if (!tl.test(t)) return t;
                            t = parseFloat(t)
                        }
                        let i = nm(t, e.target.x),
                            n = nm(t, e.target.y);
                        return `${i}% ${n}%`
                    }
                },
                nv = {},
                {
                    schedule: ng,
                    cancel: ny
                } = D(queueMicrotask, !1);
            class nx extends nu.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: n
                    } = this.props, {
                        projection: r
                    } = t;
                    Object.assign(nv, nw), r && (e.group && e.group.add(r), i && i.register && n && i.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), np.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: i,
                        drag: n,
                        isPresent: r
                    } = this.props, s = i.projection;
                    return s && (s.isPresent = r, n || t.layoutDependency !== e || void 0 === e ? s.willUpdate() : this.safeToRemove(), t.isPresent === r || (r ? s.promote() : s.relegate() || V.postRender(() => {
                        let t = s.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), ng.postRender(() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), i && i.deregister && i.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function nb(t) {
                let [e, i] = function() {
                    let t = (0, nu.useContext)(nh.t);
                    if (null === t) return [!0, null];
                    let {
                        isPresent: e,
                        onExitComplete: i,
                        register: n
                    } = t, r = (0, nu.useId)();
                    (0, nu.useEffect)(() => n(r), []);
                    let s = (0, nu.useCallback)(() => i && i(r), [r, i]);
                    return !e && i ? [!1, s] : [!0]
                }(), n = (0, nu.useContext)(nd.L);
                return (0, nl.jsx)(nx, { ...t,
                    layoutGroup: n,
                    switchLayoutGroup: (0, nu.useContext)(nc),
                    isPresent: e,
                    safeToRemove: i
                })
            }
            let nw = {
                    borderRadius: { ...nf,
                        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                    },
                    borderTopLeftRadius: nf,
                    borderTopRightRadius: nf,
                    borderBottomLeftRadius: nf,
                    borderBottomRightRadius: nf,
                    boxShadow: {
                        correct: (t, {
                            treeScale: e,
                            projectionDelta: i
                        }) => {
                            let n = tY.parse(t);
                            if (n.length > 5) return t;
                            let r = tY.createTransformer(t),
                                s = "number" != typeof n[0] ? 1 : 0,
                                o = i.x.scale * e.x,
                                a = i.y.scale * e.y;
                            n[0 + s] /= o, n[1 + s] /= a;
                            let l = eb(o, a, .5);
                            return "number" == typeof n[2 + s] && (n[2 + s] /= l), "number" == typeof n[3 + s] && (n[3 + s] /= l), r(n)
                        }
                    }
                },
                nP = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                nS = nP.length,
                nT = t => "string" == typeof t ? parseFloat(t) : t,
                nA = t => "number" == typeof t || tl.test(t);

            function nM(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let nE = nk(0, .5, W),
                nC = nk(.5, .95, C.l);

            function nk(t, e, i) {
                return n => n < t ? 0 : n > e ? 1 : i(et(t, e, n))
            }

            function nD(t, e) {
                t.min = e.min, t.max = e.max
            }

            function nV(t, e) {
                nD(t.x, e.x), nD(t.y, e.y)
            }

            function nj(t, e) {
                t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
            }

            function n_(t, e, i, n, r) {
                return t -= e, t = n + 1 / i * (t - n), void 0 !== r && (t = n + 1 / r * (t - n)), t
            }

            function nR(t, e, [i, n, r], s, o) {
                ! function(t, e = 0, i = 1, n = .5, r, s = t, o = t) {
                    if (ta.test(e) && (e = parseFloat(e), e = eb(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
                    let a = eb(s.min, s.max, n);
                    t === s && (a -= e), t.min = n_(t.min, e, i, a, r), t.max = n_(t.max, e, i, a, r)
                }(t, e[i], e[n], e[r], e.scale, s, o)
            }
            let nO = ["x", "scaleX", "originX"],
                nL = ["y", "scaleY", "originY"];

            function nI(t, e, i, n) {
                nR(t.x, e, nO, i ? i.x : void 0, n ? n.x : void 0), nR(t.y, e, nL, i ? i.y : void 0, n ? n.y : void 0)
            }

            function nF(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function nB(t) {
                return nF(t.x) && nF(t.y)
            }

            function nU(t, e) {
                return t.min === e.min && t.max === e.max
            }

            function nz(t, e) {
                return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
            }

            function nN(t, e) {
                return nz(t.x, e.x) && nz(t.y, e.y)
            }

            function n$(t) {
                return iF(t.x) / iF(t.y)
            }

            function nW(t, e) {
                return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
            }
            class nH {
                constructor() {
                    this.members = []
                }
                add(t) {
                    e1(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if (e5(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let i = this.members.findIndex(e => t === e);
                    if (0 === i) return !1;
                    for (let t = i; t >= 0; t--) {
                        let i = this.members[t];
                        if (!1 !== i.isPresent) {
                            e = i;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    let i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.instance && i.scheduleRender(), t.scheduleRender(), t.resumeFrom = i, e && (t.resumeFrom.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        let {
                            crossfade: n
                        } = t.options;
                        !1 === n && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        let {
                            options: e,
                            resumingFrom: i
                        } = t;
                        e.onExitComplete && e.onExitComplete(), i && i.options.onExitComplete && i.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }
            let nK = (t, e) => t.depth - e.depth;
            class nY {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    e1(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    e5(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(nK), this.isDirty = !1, this.children.forEach(t)
                }
            }

            function nX(t) {
                let e = it(t) ? t.get() : t;
                return eJ(e) ? e.toValue() : e
            }
            let nG = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                },
                nq = "undefined" != typeof window && void 0 !== window.MotionDebug,
                nZ = ["", "X", "Y", "Z"],
                nQ = {
                    visibility: "hidden"
                },
                nJ = 0;

            function n0(t, e, i, n) {
                let {
                    latestValues: r
                } = e;
                r[t] && (i[t] = r[t], e.setStaticValue(t, 0), n && (n[t] = 0))
            }

            function n1({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: n,
                resetTransform: r
            }) {
                return class {
                    constructor(t = {}, i = null == e ? void 0 : e()) {
                        this.id = nJ++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, nq && (nG.totalNodes = nG.resolvedTargetDeltas = nG.recalculatedProjection = 0), this.nodes.forEach(n3), this.nodes.forEach(re), this.nodes.forEach(ri), this.nodes.forEach(n6), nq && window.MotionDebug.record(nG)
                        }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new nY)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new e2), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, i = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = e instanceof SVGElement && "svg" !== e.tagName, this.instance = e;
                        let {
                            layoutId: n,
                            layout: r,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), i && (r || n) && (this.isLayoutDirty = !0), t) {
                            let i;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, i && i(), i = function(t, e) {
                                    let i = t9.now(),
                                        n = ({
                                            timestamp: e
                                        }) => {
                                            let r = e - i;
                                            r >= 250 && (j(n), t(r - 250))
                                        };
                                    return V.read(n, !0), () => j(n)
                                }(n, 250), np.hasAnimatedSinceResize && (np.hasAnimatedSinceResize = !1, this.nodes.forEach(rt))
                            })
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && s && (n || r) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: i,
                            layout: n
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let r = this.options.transition || s.getDefaultTransition() || rl,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = s.getProps(),
                                l = !this.targetLayout || !nN(this.targetLayout, n) || i,
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || u || e && (l || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, u);
                                let e = { ...w(r, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || rt(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, j(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(rn), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function t(e) {
                                if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
                                let {
                                    visualElement: i
                                } = e.options;
                                if (!i) return;
                                let n = i.props[e7];
                                if (window.MotionHasOptimisedAnimation(n, "transform")) {
                                    let {
                                        layout: t,
                                        layoutId: i
                                    } = e.options;
                                    window.MotionCancelOptimisedAnimation(n, "transform", V, !(t || i))
                                }
                                let {
                                    parent: r
                                } = e;
                                r && !r.hasCheckedOptimisedAppear && t(r)
                            }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        let n = this.getTransformTemplate();
                        this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(n9);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(n8), this.isUpdating = !1, this.nodes.forEach(n7), this.nodes.forEach(n5), this.nodes.forEach(n2), this.clearAllSnapshots();
                        let t = t9.now();
                        _.delta = te(0, 1e3 / 60, t - _.timestamp), _.timestamp = t, _.isProcessing = !0, R.update.process(_), R.preRender.process(_), R.render.process(_), _.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, ng.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(n4), this.sharedNodes.forEach(rr)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, V.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        V.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = iZ(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e) {
                            let e = n(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: t,
                                isRoot: e,
                                offset: i(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : e
                            }
                        }
                    }
                    resetTransform() {
                        if (!r) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            e = this.projectionDelta && !nB(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            n = i ? i(this.latestValues, "") : void 0,
                            s = n !== this.prevTransformTemplateValue;
                        t && (e || i5(this.latestValues) || s) && (r(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            n = this.removeElementScroll(i);
                        return t && (n = this.removeTransform(n)), rd((e = n).x), rd(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        var t;
                        let {
                            visualElement: e
                        } = this.options;
                        if (!e) return iZ();
                        let i = e.measureViewportBox();
                        if (!((null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) || this.path.some(rp))) {
                            let {
                                scroll: t
                            } = this.root;
                            t && (i9(i.x, t.offset.x), i9(i.y, t.offset.y))
                        }
                        return i
                    }
                    removeElementScroll(t) {
                        var e;
                        let i = iZ();
                        if (nV(i, t), null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) return i;
                        for (let e = 0; e < this.path.length; e++) {
                            let n = this.path[e],
                                {
                                    scroll: r,
                                    options: s
                                } = n;
                            n !== this.root && r && s.layoutScroll && (r.wasRoot && nV(i, t), i9(i.x, r.offset.x), i9(i.y, r.offset.y))
                        }
                        return i
                    }
                    applyTransform(t, e = !1) {
                        let i = iZ();
                        nV(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && i7(i, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), i5(n.latestValues) && i7(i, n.latestValues)
                        }
                        return i5(this.latestValues) && i7(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        let e = iZ();
                        nV(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t];
                            if (!i.instance || !i5(i.latestValues)) continue;
                            i1(i.latestValues) && i.updateSnapshot();
                            let n = iZ();
                            nV(n, i.measurePageBox()), nI(e, i.latestValues, i.snapshot ? i.snapshot.layoutBox : void 0, n)
                        }
                        return i5(this.latestValues) && nI(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== _.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e, i, n, r;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let o = !!this.resumingFrom || this !== s;
                        if (!(t || o && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        let {
                            layout: a,
                            layoutId: l
                        } = this.options;
                        if (this.layout && (a || l)) {
                            if (this.resolvedRelativeTargetAt = _.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = iZ(), this.relativeTargetOrigin = iZ(), i$(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), nV(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = iZ(), this.targetWithTransforms = iZ()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), i = this.target, n = this.relativeTarget, r = this.relativeParent.target, iz(i.x, n.x, r.x), iz(i.y, n.y, r.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : nV(this.target, this.layout.layoutBox), i4(this.target, this.targetDelta)) : nV(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let t = this.getClosestProjectingParent();
                                    t && !!t.resumingFrom == !!this.resumingFrom && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = iZ(), this.relativeTargetOrigin = iZ(), i$(this.relativeTargetOrigin, this.target, t.target), nV(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                nq && nG.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || i1(this.parent.latestValues) || i2(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        let e = this.getLead(),
                            i = !!this.resumingFrom || this !== e,
                            n = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (n = !1), i && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === _.timestamp && (n = !1), n) return;
                        let {
                            layout: r,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || s)) return;
                        nV(this.layoutCorrected, this.layout.layoutBox);
                        let o = this.treeScale.x,
                            a = this.treeScale.y;
                        ! function(t, e, i, n = !1) {
                            let r, s;
                            let o = i.length;
                            if (o) {
                                e.x = e.y = 1;
                                for (let a = 0; a < o; a++) {
                                    s = (r = i[a]).projectionDelta;
                                    let {
                                        visualElement: o
                                    } = r.options;
                                    (!o || !o.props.style || "contents" !== o.props.style.display) && (n && r.options.layoutScroll && r.scroll && r !== r.root && i7(t, {
                                        x: -r.scroll.offset.x,
                                        y: -r.scroll.offset.y
                                    }), s && (e.x *= s.x.scale, e.y *= s.y.scale, i4(t, s)), n && i5(r.latestValues) && i7(t, r.latestValues))
                                }
                                e.x < 1.0000000000001 && e.x > .999999999999 && (e.x = 1), e.y < 1.0000000000001 && e.y > .999999999999 && (e.y = 1)
                            }
                        }(this.layoutCorrected, this.treeScale, this.path, i), e.layout && !e.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (e.target = e.layout.layoutBox, e.targetWithTransforms = iZ());
                        let {
                            target: l
                        } = e;
                        if (!l) {
                            this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                            return
                        }
                        this.projectionDelta && this.prevProjectionDelta ? (nj(this.prevProjectionDelta.x, this.projectionDelta.x), nj(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), iU(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === o && this.treeScale.y === a && nW(this.projectionDelta.x, this.prevProjectionDelta.x) && nW(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), nq && nG.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        var e;
                        if (null === (e = this.options.visualElement) || void 0 === e || e.scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = iG(), this.projectionDelta = iG(), this.projectionDeltaWithTransform = iG()
                    }
                    setAnimationOrigin(t, e = !1) {
                        let i;
                        let n = this.snapshot,
                            r = n ? n.latestValues : {},
                            s = { ...this.latestValues
                            },
                            o = iG();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let a = iZ(),
                            l = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            h = !u || u.members.length <= 1,
                            d = !!(l && !h && !0 === this.options.crossfade && !this.path.some(ra));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            let n = e / 1e3;
                            if (rs(o.x, t.x, n), rs(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var u, c, p, m;
                                i$(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, m = this.relativeTargetOrigin, ro(p.x, m.x, a.x, n), ro(p.y, m.y, a.y, n), i && (u = this.relativeTarget, c = i, nU(u.x, c.x) && nU(u.y, c.y)) && (this.isProjectionDirty = !1), i || (i = iZ()), nV(i, this.relativeTarget)
                            }
                            l && (this.animationValues = s, function(t, e, i, n, r, s) {
                                r ? (t.opacity = eb(0, void 0 !== i.opacity ? i.opacity : 1, nE(n)), t.opacityExit = eb(void 0 !== e.opacity ? e.opacity : 1, 0, nC(n))) : s && (t.opacity = eb(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, n));
                                for (let r = 0; r < nS; r++) {
                                    let s = `border${nP[r]}Radius`,
                                        o = nM(e, s),
                                        a = nM(i, s);
                                    (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || nA(o) === nA(a) ? (t[s] = Math.max(eb(nT(o), nT(a), n), 0), (ta.test(a) || ta.test(o)) && (t[s] += "%")) : t[s] = a)
                                }(e.rotate || i.rotate) && (t.rotate = eb(e.rotate || 0, i.rotate || 0, n))
                            }(s, r, this.latestValues, n, d, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && (j(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = V.update(() => {
                            np.hasAnimatedSinceResize = !0, this.currentAnimation = function(t, e, i) {
                                let n = it(0) ? 0 : e9(0);
                                return n.start(eQ("", n, 1e3, i)), n.animation
                            }(0, 0, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: n,
                                latestValues: r
                            } = t;
                        if (e && i && n) {
                            if (this !== t && this.layout && n && rc(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                i = this.target || iZ();
                                let e = iF(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let n = iF(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + n
                            }
                            nV(e, i), i7(e, r), iU(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new nH), this.sharedNodes.get(t).add(e);
                        let i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        let n = {};
                        i.z && n0("z", t, n, this.animationValues);
                        for (let e = 0; e < nZ.length; e++) n0(`rotate${nZ[e]}`, t, n, this.animationValues), n0(`skew${nZ[e]}`, t, n, this.animationValues);
                        for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, i;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return nQ;
                        let n = {
                                visibility: ""
                            },
                            r = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = nX(null == t ? void 0 : t.pointerEvents) || "", n.transform = r ? r(this.latestValues, "") : "none", n;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = nX(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !i5(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1), e
                        }
                        let o = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), n.transform = function(t, e, i) {
                            let n = "",
                                r = t.x.translate / e.x,
                                s = t.y.translate / e.y,
                                o = (null == i ? void 0 : i.z) || 0;
                            if ((r || s || o) && (n = `translate3d(${r}px, ${s}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                                let {
                                    transformPerspective: t,
                                    rotate: e,
                                    rotateX: r,
                                    rotateY: s,
                                    skewX: o,
                                    skewY: a
                                } = i;
                                t && (n = `perspective(${t}px) ${n}`), e && (n += `rotate(${e}deg) `), r && (n += `rotateX(${r}deg) `), s && (n += `rotateY(${s}deg) `), o && (n += `skewX(${o}deg) `), a && (n += `skewY(${a}deg) `)
                            }
                            let a = t.x.scale * e.x,
                                l = t.y.scale * e.y;
                            return (1 !== a || 1 !== l) && (n += `scale(${a}, ${l})`), n || "none"
                        }(this.projectionDeltaWithTransform, this.treeScale, o), r && (n.transform = r(o, n.transform));
                        let {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        for (let t in n.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, s.animationValues ? n.opacity = s === this ? null !== (i = null !== (e = o.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== i ? i : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : n.opacity = s === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0, nv) {
                            if (void 0 === o[t]) continue;
                            let {
                                correct: e,
                                applyTo: i
                            } = nv[t], r = "none" === n.transform ? o[t] : e(o[t], s);
                            if (i) {
                                let t = i.length;
                                for (let e = 0; e < t; e++) n[i[e]] = r
                            } else n[t] = r
                        }
                        return this.options.layoutId && (n.pointerEvents = s === this ? nX(null == t ? void 0 : t.pointerEvents) || "" : "none"), n
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(n9), this.root.sharedNodes.clear()
                    }
                }
            }

            function n5(t) {
                t.updateLayout()
            }

            function n2(t) {
                var e;
                let i = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && i && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: n
                    } = t.layout, {
                        animationType: r
                    } = t.options, s = i.source !== t.layout.source;
                    "size" === r ? iQ(t => {
                        let n = s ? i.measuredBox[t] : i.layoutBox[t],
                            r = iF(n);
                        n.min = e[t].min, n.max = n.min + r
                    }) : rc(r, i.layoutBox, e) && iQ(n => {
                        let r = s ? i.measuredBox[n] : i.layoutBox[n],
                            o = iF(e[n]);
                        r.max = r.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + o)
                    });
                    let o = iG();
                    iU(o, e, i.layoutBox);
                    let a = iG();
                    s ? iU(a, t.applyTransform(n, !0), i.measuredBox) : iU(a, e, i.layoutBox);
                    let l = !nB(o),
                        u = !1;
                    if (!t.resumeFrom) {
                        let n = t.getClosestProjectingParent();
                        if (n && !n.resumeFrom) {
                            let {
                                snapshot: r,
                                layout: s
                            } = n;
                            if (r && s) {
                                let o = iZ();
                                i$(o, i.layoutBox, r.layoutBox);
                                let a = iZ();
                                i$(a, e, s.layoutBox), nN(o, a) || (u = !0), n.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = o, t.relativeParent = n)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: i,
                        delta: a,
                        layoutDelta: o,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function n3(t) {
                nq && nG.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function n6(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function n4(t) {
                t.clearSnapshot()
            }

            function n9(t) {
                t.clearMeasurements()
            }

            function n8(t) {
                t.isLayoutDirty = !1
            }

            function n7(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function rt(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function re(t) {
                t.resolveTargetDelta()
            }

            function ri(t) {
                t.calcProjection()
            }

            function rn(t) {
                t.resetSkewAndRotation()
            }

            function rr(t) {
                t.removeLeadSnapshot()
            }

            function rs(t, e, i) {
                t.translate = eb(e.translate, 0, i), t.scale = eb(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function ro(t, e, i, n) {
                t.min = eb(e.min, i.min, n), t.max = eb(e.max, i.max, n)
            }

            function ra(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let rl = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                ru = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                rh = ru("applewebkit/") && !ru("chrome/") ? Math.round : C.l;

            function rd(t) {
                t.min = rh(t.min), t.max = rh(t.max)
            }

            function rc(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !(.2 >= Math.abs(n$(e) - n$(i)))
            }

            function rp(t) {
                var e;
                return t !== t.root && (null === (e = t.scroll) || void 0 === e ? void 0 : e.wasRoot)
            }
            let rm = n1({
                    attachResizeListener: (t, e) => ik(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                rf = {
                    current: void 0
                },
                rv = n1({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!rf.current) {
                            let t = new rm({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), rf.current = t
                        }
                        return rf.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                });

            function rg(t, e, i) {
                let {
                    props: n
                } = t;
                t.animationState && n.whileHover && t.animationState.setActive("whileHover", "Start" === i);
                let r = n["onHover" + i];
                r && V.postRender(() => r(e, iE(e)))
            }
            class ry extends id {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = function(t, e, i = {}) {
                        let [n, r, s] = ig(t, i), o = iy(t => {
                            let {
                                target: i
                            } = t, n = e(t);
                            if (!n || !i) return;
                            let s = iy(t => {
                                n(t), i.removeEventListener("pointerleave", s)
                            });
                            i.addEventListener("pointerleave", s, r)
                        });
                        return n.forEach(t => {
                            t.addEventListener("pointerenter", o, r)
                        }), s
                    }(t, t => (rg(this.node, t, "Start"), t => rg(this.node, t, "End"))))
                }
                unmount() {}
            }
            class rx extends id {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = ex(ik(this.node.current, "focus", () => this.onFocus()), ik(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }

            function rb(t, e, i) {
                let {
                    props: n
                } = t;
                t.animationState && n.whileTap && t.animationState.setActive("whileTap", "Start" === i);
                let r = n["onTap" + ("End" === i ? "" : i)];
                r && V.postRender(() => r(e, iE(e)))
            }
            class rw extends id {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = function(t, e, i = {}) {
                        let [n, r, s] = ig(t, i), o = t => {
                            let n = t.currentTarget;
                            if (!iM(t) || ib.has(n)) return;
                            ib.add(n);
                            let s = e(t),
                                o = (t, e) => {
                                    window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", l), iM(t) && ib.has(n) && (ib.delete(n), s && s(t, {
                                        success: e
                                    }))
                                },
                                a = t => {
                                    o(t, i.useGlobalTarget || iA(n, t.target))
                                },
                                l = t => {
                                    o(t, !1)
                                };
                            window.addEventListener("pointerup", a, r), window.addEventListener("pointercancel", l, r)
                        };
                        return n.forEach(t => {
                            iT.has(t.tagName) || -1 !== t.tabIndex || (t.tabIndex = 0), (i.useGlobalTarget ? window : t).addEventListener("pointerdown", o, r), t.addEventListener("focus", t => iS(t, r), r)
                        }), s
                    }(t, t => (rb(this.node, t, "Start"), (t, {
                        success: e
                    }) => rb(this.node, t, e ? "End" : "Cancel")), {
                        useGlobalTarget: this.node.props.globalTapTarget
                    }))
                }
                unmount() {}
            }
            let rP = new WeakMap,
                rS = new WeakMap,
                rT = t => {
                    let e = rP.get(t.target);
                    e && e(t)
                },
                rA = t => {
                    t.forEach(rT)
                },
                rM = {
                    some: 0,
                    all: 1
                };
            class rE extends id {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: t = {}
                    } = this.node.getProps(), {
                        root: e,
                        margin: i,
                        amount: n = "some",
                        once: r
                    } = t, s = {
                        root: e ? e.current : void 0,
                        rootMargin: i,
                        threshold: "number" == typeof n ? n : rM[n]
                    };
                    return function(t, e, i) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            rS.has(i) || rS.set(i, {});
                            let n = rS.get(i),
                                r = JSON.stringify(e);
                            return n[r] || (n[r] = new IntersectionObserver(rA, {
                                root: t,
                                ...e
                            })), n[r]
                        }(e);
                        return rP.set(t, i), n.observe(t), () => {
                            rP.delete(t), n.unobserve(t)
                        }
                    }(this.node.current, s, t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, r && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: i,
                            onViewportLeave: n
                        } = this.node.getProps(), s = e ? i : n;
                        s && s(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return i => t[i] !== e[i]
                    }(t, e)) && this.startObserver()
                }
                unmount() {}
            }
            var rC = i(7249);
            let rk = (0, nu.createContext)({});
            var rD = i(5403);
            let rV = (0, nu.createContext)({
                strict: !1
            });

            function rj(t) {
                return r(t.animate) || d.some(e => a(t[e]))
            }

            function r_(t) {
                return !!(rj(t) || t.variants)
            }

            function rR(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            let rO = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                rL = {};
            for (let t in rO) rL[t] = {
                isEnabled: e => rO[t].some(t => !!e[t])
            };
            var rI = i(5687);
            let rF = Symbol.for("motionComponentSymbol"),
                rB = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function rU(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (rB.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }

            function rz(t, {
                style: e,
                vars: i
            }, n, r) {
                for (let s in Object.assign(t.style, e, r && r.getProjectionStyles(n)), i) t.style.setProperty(s, i[s])
            }
            let rN = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

            function r$(t, e, i, n) {
                for (let i in rz(t, e, void 0, n), e.attrs) t.setAttribute(rN.has(i) ? i : e8(i), e.attrs[i])
            }

            function rW(t, {
                layout: e,
                layoutId: i
            }) {
                return p.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!nv[t] || "opacity" === t)
            }

            function rH(t, e, i) {
                var n;
                let {
                    style: r
                } = t, s = {};
                for (let o in r)(it(r[o]) || e.style && it(e.style[o]) || rW(o, t) || (null === (n = null == i ? void 0 : i.getValue(o)) || void 0 === n ? void 0 : n.liveStyle) !== void 0) && (s[o] = r[o]);
                return s
            }

            function rK(t, e, i) {
                let n = rH(t, e, i);
                for (let i in t)(it(t[i]) || it(e[i])) && (n[-1 !== c.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
                return n
            }
            var rY = i(9234);
            let rX = t => (e, i) => {
                    let n = (0, nu.useContext)(rk),
                        s = (0, nu.useContext)(nh.t),
                        o = () => (function({
                            scrapeMotionValuesFromProps: t,
                            createRenderState: e,
                            onMount: i
                        }, n, s, o) {
                            let a = {
                                latestValues: function(t, e, i, n) {
                                    let s = {},
                                        o = n(t, {});
                                    for (let t in o) s[t] = nX(o[t]);
                                    let {
                                        initial: a,
                                        animate: u
                                    } = t, h = rj(t), d = r_(t);
                                    e && d && !h && !1 !== t.inherit && (void 0 === a && (a = e.initial), void 0 === u && (u = e.animate));
                                    let c = !!i && !1 === i.initial,
                                        p = (c = c || !1 === a) ? u : a;
                                    if (p && "boolean" != typeof p && !r(p)) {
                                        let e = Array.isArray(p) ? p : [p];
                                        for (let i = 0; i < e.length; i++) {
                                            let n = l(t, e[i]);
                                            if (n) {
                                                let {
                                                    transitionEnd: t,
                                                    transition: e,
                                                    ...i
                                                } = n;
                                                for (let t in i) {
                                                    let e = i[t];
                                                    if (Array.isArray(e)) {
                                                        let t = c ? e.length - 1 : 0;
                                                        e = e[t]
                                                    }
                                                    null !== e && (s[t] = e)
                                                }
                                                for (let e in t) s[e] = t[e]
                                            }
                                        }
                                    }
                                    return s
                                }(n, s, o, t),
                                renderState: e()
                            };
                            return i && (a.mount = t => i(n, t, a)), a
                        })(t, e, n, s);
                    return i ? o() : (0, rY.M)(o)
                },
                rG = () => ({
                    style: {},
                    transform: {},
                    transformOrigin: {},
                    vars: {}
                }),
                rq = () => ({ ...rG(),
                    attrs: {}
                }),
                rZ = (t, e) => e && "number" == typeof t ? e.transform(t) : t,
                rQ = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                rJ = c.length;

            function r0(t, e, i) {
                let {
                    style: n,
                    vars: r,
                    transformOrigin: s
                } = t, o = !1, a = !1;
                for (let t in e) {
                    let i = e[t];
                    if (p.has(t)) {
                        o = !0;
                        continue
                    }
                    if (q(t)) {
                        r[t] = i;
                        continue
                    } {
                        let e = rZ(i, tJ[t]);
                        t.startsWith("origin") ? (a = !0, s[t] = e) : n[t] = e
                    }
                }
                if (!e.transform && (o || i ? n.transform = function(t, e, i) {
                        let n = "",
                            r = !0;
                        for (let s = 0; s < rJ; s++) {
                            let o = c[s],
                                a = t[o];
                            if (void 0 === a) continue;
                            let l = !0;
                            if (!(l = "number" == typeof a ? a === (o.startsWith("scale") ? 1 : 0) : 0 === parseFloat(a)) || i) {
                                let t = rZ(a, tJ[o]);
                                if (!l) {
                                    r = !1;
                                    let e = rQ[o] || o;
                                    n += `${e}(${t}) `
                                }
                                i && (e[o] = t)
                            }
                        }
                        return n = n.trim(), i ? n = i(e, r ? "" : n) : r && (n = "none"), n
                    }(e, t.transform, i) : n.transform && (n.transform = "none")), a) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: i = 0
                    } = s;
                    n.transformOrigin = `${t} ${e} ${i}`
                }
            }

            function r1(t, e, i) {
                return "string" == typeof t ? t : tl.transform(e + i * t)
            }
            let r5 = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                r2 = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function r3(t, {
                attrX: e,
                attrY: i,
                attrScale: n,
                originX: r,
                originY: s,
                pathLength: o,
                pathSpacing: a = 1,
                pathOffset: l = 0,
                ...u
            }, h, d) {
                if (r0(t, u, d), h) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: c,
                    style: p,
                    dimensions: m
                } = t;
                c.transform && (m && (p.transform = c.transform), delete c.transform), m && (void 0 !== r || void 0 !== s || p.transform) && (p.transformOrigin = function(t, e, i) {
                    let n = r1(e, t.x, t.width),
                        r = r1(i, t.y, t.height);
                    return `${n} ${r}`
                }(m, void 0 !== r ? r : .5, void 0 !== s ? s : .5)), void 0 !== e && (c.x = e), void 0 !== i && (c.y = i), void 0 !== n && (c.scale = n), void 0 !== o && function(t, e, i = 1, n = 0, r = !0) {
                    t.pathLength = 1;
                    let s = r ? r5 : r2;
                    t[s.offset] = tl.transform(-n);
                    let o = tl.transform(e),
                        a = tl.transform(i);
                    t[s.array] = `${o} ${a}`
                }(c, o, a, l, !1)
            }
            let r6 = t => "string" == typeof t && "svg" === t.toLowerCase(),
                r4 = {
                    useVisualState: rX({
                        scrapeMotionValuesFromProps: rK,
                        createRenderState: rq,
                        onMount: (t, e, {
                            renderState: i,
                            latestValues: n
                        }) => {
                            V.read(() => {
                                try {
                                    i.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                                } catch (t) {
                                    i.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), V.render(() => {
                                r3(i, n, r6(e.tagName), t.transformTemplate), r$(e, i)
                            })
                        }
                    })
                },
                r9 = {
                    useVisualState: rX({
                        scrapeMotionValuesFromProps: rH,
                        createRenderState: rG
                    })
                };

            function r8(t, e, i) {
                for (let n in e) it(e[n]) || rW(n, i) || (t[n] = e[n])
            }
            let r7 = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function st(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || r7.has(t)
            }
            let se = t => !st(t);
            try {
                ! function(t) {
                    t && (se = e => e.startsWith("on") ? !st(e) : t(e))
                }(require("@emotion/is-prop-valid").default)
            } catch (t) {}
            let si = {
                    current: null
                },
                sn = {
                    current: !1
                },
                sr = new WeakMap,
                ss = [...tb, tF, tY],
                so = t => ss.find(tx(t)),
                sa = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
            class sl {
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: n,
                    blockInitialAnimation: r,
                    visualState: s
                }, o = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = tE, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                        let t = t9.now();
                        this.renderScheduledAt < t && (this.renderScheduledAt = t, V.render(this.render, !1, !0))
                    };
                    let {
                        latestValues: a,
                        renderState: l
                    } = s;
                    this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = e.initial ? { ...a
                    } : {}, this.renderState = l, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.options = o, this.blockInitialAnimation = !!r, this.isControllingVariants = rj(e), this.isVariantNode = r_(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    let {
                        willChange: u,
                        ...h
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (let t in h) {
                        let e = h[t];
                        void 0 !== a[t] && it(e) && e.set(a[t], !1)
                    }
                }
                mount(t) {
                    this.current = t, sr.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), sn.current || function() {
                        if (sn.current = !0, rI.B) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => si.current = t.matches;
                                t.addListener(e), e()
                            } else si.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || si.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    for (let t in sr.delete(this.current), this.projection && this.projection.unmount(), j(this.notifyUpdate), j(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[t].clear();
                    for (let t in this.features) {
                        let e = this.features[t];
                        e && (e.unmount(), e.isMounted = !1)
                    }
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let i;
                    this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
                    let n = p.has(t),
                        r = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && V.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        s = e.on("renderRequest", this.scheduleRender);
                    window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, () => {
                        r(), s(), i && i(), e.owner && e.stop()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                updateFeatures() {
                    let t = "animation";
                    for (t in rL) {
                        let e = rL[t];
                        if (!e) continue;
                        let {
                            isEnabled: i,
                            Feature: n
                        } = e;
                        if (!this.features[t] && n && i(this.props) && (this.features[t] = new n(this)), this.features[t]) {
                            let e = this.features[t];
                            e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : iZ()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < sa.length; e++) {
                        let i = sa[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let n = t["on" + i];
                        n && (this.propEventSubscriptions[i] = this.on(i, n))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        for (let n in e) {
                            let r = e[n],
                                s = i[n];
                            if (it(r)) t.addValue(n, r);
                            else if (it(s)) t.addValue(n, e9(r, {
                                owner: t
                            }));
                            else if (s !== r) {
                                if (t.hasValue(n)) {
                                    let e = t.getValue(n);
                                    !0 === e.liveStyle ? e.jump(r) : e.hasAnimated || e.set(r)
                                } else {
                                    let e = t.getStaticValue(n);
                                    t.addValue(n, e9(void 0 !== e ? e : r, {
                                        owner: t
                                    }))
                                }
                            }
                        }
                        for (let n in i) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    let i = this.values.get(t);
                    e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = e9(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    var i;
                    let n = void 0 === this.latestValues[t] && this.current ? null !== (i = this.getBaseTargetFromProps(this.props, t)) && void 0 !== i ? i : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != n && ("string" == typeof n && (X(n) || K(n)) ? n = parseFloat(n) : !so(n) && tY.test(e) && (n = t5(t, e)), this.setBaseTarget(t, it(n) ? n.get() : n)), it(n) ? n.get() : n
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    let i;
                    let {
                        initial: n
                    } = this.props;
                    if ("string" == typeof n || "object" == typeof n) {
                        let r = l(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        r && (i = r[t])
                    }
                    if (n && void 0 !== i) return i;
                    let r = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === r || it(r) ? void 0 !== this.initialValues[t] && void 0 === i ? void 0 : this.baseTarget[t] : r
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new e2), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
            class su extends sl {
                constructor() {
                    super(...arguments), this.KeyframeResolver = t3
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    it(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
            }
            class sh extends su {
                constructor() {
                    super(...arguments), this.type = "html", this.renderInstance = rz
                }
                readValueFromInstance(t, e) {
                    if (p.has(e)) {
                        let t = t1(e);
                        return t && t.default || 0
                    } {
                        let i = window.getComputedStyle(t),
                            n = (q(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return nt(t, e)
                }
                build(t, e, i) {
                    r0(t, e, i.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return rH(t, e, i)
                }
            }
            class sd extends su {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = iZ
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (p.has(e)) {
                        let t = t1(e);
                        return t && t.default || 0
                    }
                    return e = rN.has(e) ? e : e8(e), t.getAttribute(e)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return rK(t, e, i)
                }
                build(t, e, i) {
                    r3(t, e, this.isSVGTag, i.transformTemplate)
                }
                renderInstance(t, e, i, n) {
                    r$(t, e, i, n)
                }
                mount(t) {
                    this.isSVGTag = r6(t.tagName), super.mount(t)
                }
            }
            let sc = function(t) {
                if ("undefined" == typeof Proxy) return t;
                let e = new Map;
                return new Proxy((...e) => t(...e), {
                    get: (i, n) => "create" === n ? t : (e.has(n) || e.set(n, t(n)), e.get(n))
                })
            }((M = {
                animation: {
                    Feature: ic
                },
                exit: {
                    Feature: im
                },
                inView: {
                    Feature: rE
                },
                tap: {
                    Feature: rw
                },
                focus: {
                    Feature: rx
                },
                hover: {
                    Feature: ry
                },
                pan: {
                    Feature: na
                },
                drag: {
                    Feature: ns,
                    ProjectionNode: rv,
                    MeasureLayout: nb
                },
                layout: {
                    ProjectionNode: rv,
                    MeasureLayout: nb
                }
            }, E = (t, e) => rU(t) ? new sd(e) : new sh(e, {
                allowProjection: t !== nu.Fragment
            }), function(t, {
                forwardMotionProps: e
            } = {
                forwardMotionProps: !1
            }) {
                return function(t) {
                    let {
                        preloadedFeatures: e,
                        createVisualElement: i,
                        useRender: n,
                        useVisualState: r,
                        Component: s
                    } = t;
                    e && function(t) {
                        for (let e in t) rL[e] = { ...rL[e],
                            ...t[e]
                        }
                    }(e);
                    let o = (0, nu.forwardRef)(function(t, e) {
                        var o;
                        let l;
                        let u = { ...(0, nu.useContext)(rC.Q),
                                ...t,
                                layoutId: function(t) {
                                    let {
                                        layoutId: e
                                    } = t, i = (0, nu.useContext)(nd.L).id;
                                    return i && void 0 !== e ? i + "-" + e : e
                                }(t)
                            },
                            {
                                isStatic: h
                            } = u,
                            d = function(t) {
                                let {
                                    initial: e,
                                    animate: i
                                } = function(t, e) {
                                    if (rj(t)) {
                                        let {
                                            initial: e,
                                            animate: i
                                        } = t;
                                        return {
                                            initial: !1 === e || a(e) ? e : void 0,
                                            animate: a(i) ? i : void 0
                                        }
                                    }
                                    return !1 !== t.inherit ? e : {}
                                }(t, (0, nu.useContext)(rk));
                                return (0, nu.useMemo)(() => ({
                                    initial: e,
                                    animate: i
                                }), [rR(e), rR(i)])
                            }(t),
                            c = r(t, h);
                        if (!h && rI.B) {
                            (0, nu.useContext)(rV).strict;
                            let t = function(t) {
                                let {
                                    drag: e,
                                    layout: i
                                } = rL;
                                if (!e && !i) return {};
                                let n = { ...e,
                                    ...i
                                };
                                return {
                                    MeasureLayout: (null == e ? void 0 : e.isEnabled(t)) || (null == i ? void 0 : i.isEnabled(t)) ? n.MeasureLayout : void 0,
                                    ProjectionNode: n.ProjectionNode
                                }
                            }(u);
                            l = t.MeasureLayout, d.visualElement = function(t, e, i, n, r) {
                                var s, o;
                                let {
                                    visualElement: a
                                } = (0, nu.useContext)(rk), l = (0, nu.useContext)(rV), u = (0, nu.useContext)(nh.t), h = (0, nu.useContext)(rC.Q).reducedMotion, d = (0, nu.useRef)(null);
                                n = n || l.renderer, !d.current && n && (d.current = n(t, {
                                    visualState: e,
                                    parent: a,
                                    props: i,
                                    presenceContext: u,
                                    blockInitialAnimation: !!u && !1 === u.initial,
                                    reducedMotionConfig: h
                                }));
                                let c = d.current,
                                    p = (0, nu.useContext)(nc);
                                c && !c.projection && r && ("html" === c.type || "svg" === c.type) && function(t, e, i, n) {
                                    let {
                                        layoutId: r,
                                        layout: s,
                                        drag: o,
                                        dragConstraints: a,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    } = e;
                                    t.projection = new i(t.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                                        if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                                    }(t.parent)), t.projection.setOptions({
                                        layoutId: r,
                                        layout: s,
                                        alwaysMeasureLayout: !!o || a && iI(a),
                                        visualElement: t,
                                        animationType: "string" == typeof s ? s : "both",
                                        initialPromotionConfig: n,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    })
                                }(d.current, i, r, p);
                                let m = (0, nu.useRef)(!1);
                                (0, nu.useInsertionEffect)(() => {
                                    c && m.current && c.update(i, u)
                                });
                                let f = i[e7],
                                    v = (0, nu.useRef)(!!f && !(null === (s = window.MotionHandoffIsComplete) || void 0 === s ? void 0 : s.call(window, f)) && (null === (o = window.MotionHasOptimisedAnimation) || void 0 === o ? void 0 : o.call(window, f)));
                                return (0, rD.E)(() => {
                                    c && (m.current = !0, window.MotionIsMounted = !0, c.updateFeatures(), ng.render(c.render), v.current && c.animationState && c.animationState.animateChanges())
                                }), (0, nu.useEffect)(() => {
                                    c && (!v.current && c.animationState && c.animationState.animateChanges(), v.current && (queueMicrotask(() => {
                                        var t;
                                        null === (t = window.MotionHandoffMarkAsComplete) || void 0 === t || t.call(window, f)
                                    }), v.current = !1))
                                }), c
                            }(s, c, u, i, t.ProjectionNode)
                        }
                        return (0, nl.jsxs)(rk.Provider, {
                            value: d,
                            children: [l && d.visualElement ? (0, nl.jsx)(l, {
                                visualElement: d.visualElement,
                                ...u
                            }) : null, n(s, t, (o = d.visualElement, (0, nu.useCallback)(t => {
                                t && c.mount && c.mount(t), o && (t ? o.mount(t) : o.unmount()), e && ("function" == typeof e ? e(t) : iI(e) && (e.current = t))
                            }, [o])), c, h, d.visualElement)]
                        })
                    });
                    return o[rF] = s, o
                }({ ...rU(t) ? r4 : r9,
                    preloadedFeatures: M,
                    useRender: function(t = !1) {
                        return (e, i, n, {
                            latestValues: r
                        }, s) => {
                            let o = (rU(e) ? function(t, e, i, n) {
                                    let r = (0, nu.useMemo)(() => {
                                        let i = rq();
                                        return r3(i, e, r6(n), t.transformTemplate), { ...i.attrs,
                                            style: { ...i.style
                                            }
                                        }
                                    }, [e]);
                                    if (t.style) {
                                        let e = {};
                                        r8(e, t.style, t), r.style = { ...e,
                                            ...r.style
                                        }
                                    }
                                    return r
                                } : function(t, e) {
                                    let i = {},
                                        n = function(t, e) {
                                            let i = t.style || {},
                                                n = {};
                                            return r8(n, i, t), Object.assign(n, function({
                                                transformTemplate: t
                                            }, e) {
                                                return (0, nu.useMemo)(() => {
                                                    let i = rG();
                                                    return r0(i, e, t), Object.assign({}, i.vars, i.style)
                                                }, [e])
                                            }(t, e)), n
                                        }(t, e);
                                    return t.drag && !1 !== t.dragListener && (i.draggable = !1, n.userSelect = n.WebkitUserSelect = n.WebkitTouchCallout = "none", n.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (i.tabIndex = 0), i.style = n, i
                                })(i, r, s, e),
                                a = function(t, e, i) {
                                    let n = {};
                                    for (let r in t)("values" !== r || "object" != typeof t.values) && (se(r) || !0 === i && st(r) || !e && !st(r) || t.draggable && r.startsWith("onDrag")) && (n[r] = t[r]);
                                    return n
                                }(i, "string" == typeof e, t),
                                l = e !== nu.Fragment ? { ...a,
                                    ...o,
                                    ref: n
                                } : {},
                                {
                                    children: u
                                } = i,
                                h = (0, nu.useMemo)(() => it(u) ? u.get() : u, [u]);
                            return (0, nu.createElement)(e, { ...l,
                                children: h
                            })
                        }
                    }(e),
                    createVisualElement: E,
                    Component: t
                })
            }))
        },
        5687: (t, e, i) => {
            i.d(e, {
                B: () => n
            });
            let n = "undefined" != typeof window
        },
        9234: (t, e, i) => {
            i.d(e, {
                M: () => r
            });
            var n = i(2115);

            function r(t) {
                let e = (0, n.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        5403: (t, e, i) => {
            i.d(e, {
                E: () => r
            });
            var n = i(2115);
            let r = i(5687).B ? n.useLayoutEffect : n.useEffect
        },
        5107: (t, e, i) => {
            i.d(e, {
                $: () => r,
                V: () => s
            });
            var n = i(6054);
            let r = n.l,
                s = n.l
        },
        6054: (t, e, i) => {
            i.d(e, {
                l: () => n
            });
            let n = t => t
        }
    }
]);