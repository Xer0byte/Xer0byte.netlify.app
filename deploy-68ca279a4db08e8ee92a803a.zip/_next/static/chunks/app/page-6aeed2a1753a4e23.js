(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [974], {
        8972: (e, t, i) => {
            Promise.resolve().then(i.bind(i, 3006))
        },
        3006: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                default: () => M
            });
            var n = i(5155),
                a = i(2115),
                r = i(5683),
                s = i(1714),
                o = i(3635);
            let l = e => {
                let {
                    activeSection: t,
                    onInteraction: i
                } = e, r = (0, a.useRef)(null), s = (0, a.useRef)({
                    x: 0,
                    y: 0
                }), l = (0, a.useRef)(null), c = (0, a.useRef)([]), d = (0, a.useRef)(!1), m = (0, a.useRef)(6e3), h = (0, a.useRef)({
                    start: "#000000",
                    middle: "#000000",
                    end: "#0B0B1F"
                }), x = () => Math.min(Math.floor(window.innerWidth * window.innerHeight / 15e3 * (window.devicePixelRatio > 1 ? .5 : 1)), 120), u = (e, t) => {
                    e.beginPath(), t.forEach(t => {
                        e.moveTo(t.x, t.y), e.arc(t.x, t.y, t.size, 0, 2 * Math.PI)
                    }), e.fill()
                }, p = (0, o.useDrag)(e => {
                    let {
                        movement: [t, i],
                        down: n
                    } = e;
                    n && g(i / window.innerHeight * Math.PI, t / window.innerWidth * Math.PI)
                }), g = (e, t) => {
                    c.current.forEach(i => {
                        let {
                            x: n,
                            y: a,
                            z: r
                        } = w(i.x - window.innerWidth / 2, i.y - window.innerHeight / 2, i.z, e, t);
                        i.x = n + window.innerWidth / 2, i.y = a + window.innerHeight / 2, i.z = r
                    })
                }, v = (e, t) => ({
                    x: e,
                    y: t,
                    baseX: e,
                    baseY: t,
                    originalX: e,
                    originalY: t,
                    vx: (Math.random() - .5) * 4,
                    vy: (Math.random() - .5) * 4,
                    size: 2 * Math.random() + 1,
                    color: "white",
                    active: !0,
                    z: 0,
                    rotationSpeed: .02 * Math.random() - .01,
                    depth: 1e3 * Math.random(),
                    distanceFromMouse: 0,
                    trail: [],
                    angle: Math.random() * Math.PI * 2,
                    orbitSpeed: (Math.random() - .25) * .03,
                    orbitRadius: 150 * Math.random() + 50
                });
                (0, a.useEffect)(() => {
                    let e;
                    let n = l.current,
                        a = n.getContext("2d", {
                            alpha: !1
                        }),
                        o = () => {
                            let e = x();
                            c.current = Array(e).fill(null).map(() => ({
                                x: Math.random() * window.innerWidth,
                                y: Math.random() * window.innerHeight,
                                baseX: Math.random() * window.innerWidth,
                                baseY: Math.random() * window.innerHeight,
                                originalX: 0,
                                originalY: 0,
                                vx: 0,
                                vy: 0,
                                size: "home" === t ? 2 * Math.random() + 1 : 1.5,
                                color: "white",
                                active: !1,
                                z: 0,
                                rotationSpeed: "home" === t ? .02 * Math.random() - .01 : 0,
                                depth: "home" === t ? 1e3 * Math.random() : 0,
                                distanceFromMouse: 0,
                                trail: [],
                                angle: Math.random() * Math.PI * 2,
                                orbitSpeed: (Math.random() - .25) * .03,
                                orbitRadius: 150 * Math.random() + 50
                            }))
                        },
                        p = (e, n, a) => {
                            let r = Array(a).fill(null).map(() => v(e, n));
                            c.current = [...c.current, ...r].slice(0, m.current), i({
                                type: "click",
                                section: t
                            })
                        };
                    "home" !== t ? a.filter = "blur(3px)" : a.filter = "none";
                    let g = performance.now(),
                        w = e => {
                            if (e - g < 16) {
                                r.current = requestAnimationFrame(w);
                                return
                            }
                            g = e;
                            let t = a.createRadialGradient(n.width / 2, n.height / 2, 0, n.width / 2, n.height / 2, .8 * n.width);
                            t.addColorStop(0, h.current.start), t.addColorStop(.5, h.current.middle), t.addColorStop(1, h.current.end), a.fillStyle = t, a.fillRect(0, 0, n.width, n.height), a.fillStyle = "rgba(0, 0, 0, 0.1)", a.fillRect(0, 0, n.width, n.height);
                            for (let e = 0; e < c.current.length; e += 50) f(c.current.slice(e, e + 50));
                            a.shadowBlur = 0, a.fillStyle = "white", u(a, c.current), c.current.forEach((e, t) => {
                                for (let i = t + 1; i < c.current.length; i++) {
                                    let t = c.current[i],
                                        n = e.x - t.x,
                                        r = e.y - t.y,
                                        s = Math.sqrt(n * n + r * r);
                                    s < 100 && (a.strokeStyle = "rgba(255, 255, 255, ".concat(.2 * (1 - s / 100), ")"), a.beginPath(), a.moveTo(e.x, e.y), a.lineTo(t.x, t.y), a.stroke())
                                }
                            }), r.current = requestAnimationFrame(w)
                        },
                        f = e => {
                            e.forEach(e => {
                                e.vx *= .98, e.vy *= .98, e.x += e.vx, e.y += e.vy, (e.x < 0 || e.x > n.width) && (e.vx *= -1), (e.y < 0 || e.y > n.height) && (e.vy *= -1);
                                let t = s.current.x - e.x,
                                    i = s.current.y - e.y,
                                    a = Math.sqrt(t * t + i * i);
                                if (a < 200) {
                                    let n = (200 - a) / 200;
                                    e.vx -= t * n * .02, e.vy -= i * n * .02
                                }
                            })
                        },
                        b = () => {
                            clearTimeout(e), e = setTimeout(() => {
                                n.width = window.innerWidth, n.height = window.innerHeight, o()
                            }, 250)
                        },
                        j = 0,
                        y = e => {
                            let t = Date.now();
                            t - j > 16 && (s.current = {
                                x: e.clientX,
                                y: e.clientY
                            }, j = t), s.current = {
                                x: e.clientX,
                                y: e.clientY
                            }, d.current = !0
                        },
                        N = e => {
                            p(e.clientX, e.clientY, 10), c.current.forEach(t => {
                                100 > Math.hypot(t.x - e.clientX, t.y - e.clientY) && (t.vx += (t.x - e.clientX) * .1, t.vy += (t.y - e.clientY) * .1)
                            })
                        };
                    return r.current && cancelAnimationFrame(r.current), window.addEventListener("resize", b), window.addEventListener("mousemove", y), window.addEventListener("click", N), b(), w(performance.now()), () => {
                        r.current && cancelAnimationFrame(r.current), clearTimeout(e), window.removeEventListener("resize", b), window.removeEventListener("mousemove", y), window.removeEventListener("click", N)
                    }
                }, [t, i]), (0, a.useEffect)(() => {
                    let e = {
                        home: {
                            start: "#111011",
                            middle: "#0f0d0d",
                            end: "#1d1d1d"
                        },
                        work: {
                            start: "#0B0B1F",
                            middle: "#1A1A2F",
                            end: "#0F0F1F"
                        },
                        about: {
                            start: "#000000",
                            middle: "#0F1A2F",
                            end: "#0B0B2F"
                        },
                        contact: {
                            start: "#000000",
                            middle: "#0D1B2F",
                            end: "#0A0A1F"
                        }
                    };
                    h.current = e[t] || e.home
                }, [t]);
                let w = (e, t, i, n, a) => {
                    let r = Math.cos(a),
                        s = Math.sin(a);
                    return {
                        x: e * r + i * s,
                        y: t * Math.cos(n) - i * Math.sin(n),
                        z: i * r - e * s
                    }
                };
                return (0, a.useEffect)(() => {
                    let e = e => {
                        "home" === t && c.current.forEach(t => {
                            t.orbitRadius += .1 * e.deltaY, t.orbitRadius = Math.max(50, Math.min(300, t.orbitRadius))
                        })
                    };
                    return window.addEventListener("wheel", e), () => window.removeEventListener("wheel", e)
                }, [t]), (0, n.jsx)("canvas", {
                    ref: l,
                    className: "absolute inset-0 transition-all duration-500 ".concat("home" !== t ? "opacity-50" : "opacity-100"),
                    ...p(),
                    onMouseLeave: () => {
                        d.current = !1
                    }
                })
            };
            var c = i(5565);

            function d() {
                let [e, t] = (0, a.useState)(null), i = [{
                    id: 1,
                    title: "Architectural & Engineering Design Solutions",
                    description: "AutoCAD is a powerful software used for creating precise 2D and 3D designs in architectural, civil, and mechanical engineering projects. It enables accurate modeling, efficient visualization, and seamless integration with other engineering applications, significantly enhancing project outcomes and efficiency.",
                    technologies: ["AutoCAD", "Revit", "Civil engineering tools", "OpenAI API"],
                    image: "/projects/library.png",
                    link: "https://github.com/Xer0byte/Superior-Univerity-Library-Ai",
                    details: {
                        features: ["Custom architectural design solutions", "Civil engineering for site development and infrastructure", "Mechanical engineering focusing on water supply and drainage systems", "Proficient use of AutoCAD and Revit for precise designs", "Sustainable engineering solutions"],
                        impact: "Improved design accuracy by 70% through the proficient use of AutoCAD and Revit in architectural, civil, and mechanical engineering projects."
                    }
                }, {
                    id: 2,
                    title: "Python Data Analysis Services",
                    description: "Python is a versatile programming language widely used for data analysis, enabling efficient data processing, visualization, and modeling. It offers powerful libraries such as Pandas, NumPy, and Matplotlib, which streamline the analysis of large datasets and provide valuable insights for decision-making.",
                    technologies: ["Python", "Pandas", "GPT-4", "Node.js", "MongoDB","NumPy","Seaborn","HuggingFace","FastAI"],
                    image: "/projects/boot-writer.jpg",
                    link: "https://github.com/Xer0byte/BookWriter-Lamma3.1-OPENAI",
                    details: {
                        features: ["Data cleaning and preprocessing using Python libraries", "Advanced statistical analysis and modeling", "Data visualization with interactive charts and graphs", "Integration with machine learning algorithms for predictive analytics", "Customizable reports and dashboards for data-driven decision-making"],
                        impact: "Enhanced data processing efficiency by 65% through Python’s data manipulation capabilities."
                    }
                }, {
                    id: 3,
                    title: "Web Development Services",
                    description: "Web development involves designing and building responsive, user-friendly websites and applications using modern technologies. It includes front-end and back-end development to create seamless digital experiences, ensuring performance, security, and scalability.",
                    technologies: ["HTML", "CSS", "JavaScript", "Node.js", "Python","OpenAI","GPT-4","Replit"],
                    image: "/projects/foot-ai.jpg",
                    link: "https://github.com/Xer0byte/BRP-SizeMeasure",
                    details: {
                        features: ["Custom website design and development", "Responsive and mobile-friendly interfaces", "Backend development for dynamic functionality", "SEO optimization for better search rankings", "Integration with databases and APIs"],
                        impact: "Increased website performance by 70% through optimized coding and responsive design."
                    }
                }];
                return (0, n.jsx)(s.P.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    className: "w-full max-w-6xl mx-auto p-8",
                    children: (0, n.jsx)(r.N, {
                        mode: "wait",
                        children: e ? (0, n.jsx)(m, {
                            project: i.find(t => t.id === e),
                            onClose: () => t(null)
                        }) : (0, n.jsx)(s.P.div, {
                            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
                            children: i.map(e => (0, n.jsxs)(s.P.div, {
                                whileHover: {
                                    scale: 1.05
                                },
                                className: "bg-black/20 backdrop-blur-sm rounded-lg p-4 cursor-pointer",
                                onClick: () => t(e.id),
                                layoutId: "project-".concat(e.id),
                                children: [(0, n.jsxs)("div", {
                                    className: "relative h-48 mb-4",
                                    children: [(0, n.jsx)(c.default, {
                                        src: e.image,
                                        alt: e.title,
                                        layout: "fill",
                                        objectFit: "cover",
                                        className: "rounded-lg"
                                    }), (0, n.jsx)("div", {
                                        className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-lg"
                                    })]
                                }), (0, n.jsx)("h3", {
                                    className: "text-xl font-bold text-white",
                                    children: e.title
                                }), (0, n.jsx)("p", {
                                    className: "text-gray-300 mt-2 line-clamp-2",
                                    children: e.description
                                }), (0, n.jsx)("div", {
                                    className: "flex flex-wrap gap-2 mt-4",
                                    children: e.technologies.map(e => (0, n.jsx)("span", {
                                        className: "px-2 py-1 bg-white/10 rounded-full text-sm text-white",
                                        children: e
                                    }, e))
                                })]
                            }, e.id))
                        })
                    })
                })
            }

            function m(e) {
                let {
                    project: t,
                    onClose: i
                } = e;
                return (0, n.jsxs)(s.P.div, {
                    layoutId: "project-".concat(t.id),
                    className: "bg-black/40 backdrop-blur-md rounded-lg p-8 max-w-4xl mx-auto",
                    children: [(0, n.jsx)("button", {
                        onClick: i,
                        className: "absolute top-4 right-4 text-white hover:text-gray-300",
                        children: "✕"
                    }), (0, n.jsx)(c.default, {
                        src: t.image,
                        alt: t.title,
                        width: 800,
                        height: 400,
                        className: "w-full h-64 object-cover rounded-lg mb-6"
                    }), (0, n.jsx)("h2", {
                        className: "text-3xl font-bold text-white mb-4",
                        children: t.title
                    }), (0, n.jsx)("p", {
                        className: "text-gray-300 mb-6",
                        children: t.description
                    }), (0, n.jsxs)("div", {
                        className: "grid md:grid-cols-2 gap-6",
                        children: [(0, n.jsxs)("div", {
                            children: [(0, n.jsx)("h3", {
                                className: "text-xl font-bold text-white mb-3",
                                children: "Key Features"
                            }), (0, n.jsx)("ul", {
                                className: "list-disc list-inside text-gray-300 space-y-2",
                                children: t.details.features.map((e, t) => (0, n.jsx)("li", {
                                    children: e
                                }, t))
                            })]
                        }), (0, n.jsxs)("div", {
                            children: [(0, n.jsx)("h3", {
                                className: "text-xl font-bold text-white mb-3",
                                children: "Impact"
                            }), (0, n.jsx)("p", {
                                className: "text-gray-300",
                                children: t.details.impact
                            }), (0, n.jsx)("div", {
                                className: "mt-6",
                                children: (0, n.jsxs)("a", {
                                    href: t.link,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-white",
                                    children: ["View Project ", (0, n.jsx)("span", {
                                        children: "→"
                                    })]
                                })
                            })]
                        })]
                    })]
                })
            }
            let h = ["Python", "C++", "AI", "HTML", "CSS", "JS", "Node.js" , "Computer Engineering", "Problem Solving", "Web Development", " SEO(Expert)", "AutoCAD", "Revit", "Database Management"],
                x = (0, a.memo)(e => {
                    let {
                        title: t,
                        institution: i,
                        period: a,
                        details: r,
                        coursework: s
                    } = e;
                    return (0, n.jsxs)("div", {
                        className: "relative pl-8 border-l-2 border-emerald-800",
                        children: [(0, n.jsx)("div", {
                            className: "absolute w-4 h-4 bg-emerald-800 rounded-full -left-[9px] top-0"
                        }), (0, n.jsx)("h3", {
                            className: "text-xl font-bold",
                            children: t
                        }), (0, n.jsxs)("p", {
                            className: "text-gray-300",
                            children: [i, " (", a, ")"]
                        }), (0, n.jsx)("p", {
                            className: "mt-2 text-gray-400",
                            children: r
                        }), s && (0, n.jsx)("p", {
                            className: "mt-1 text-gray-400",
                            children: s
                        })]
                    })
                });
            x.displayName = "EducationItem";
            let u = (0, a.memo)(e => {
                let {
                    title: t,
                    issuer: i,
                    location: a,
                    year: r
                } = e;
                return (0, n.jsxs)("div", {
                    className: "bg-zinc-900/40 hover:bg-zinc-800/40 transition-all p-4 md:p-6 rounded-lg  border border-zinc-800 hover:border-zinc-700",
                    children: [(0, n.jsx)("h3", {
                        className: "text-lg md:text-xl font-bold mb-2 text-emerald-400",
                        children: t
                    }), (0, n.jsx)("p", {
                        className: "text-gray-200 text-sm md:text-base",
                        children: i
                    }), (0, n.jsxs)("p", {
                        className: "text-gray-400 text-sm",
                        children: [a, ", ", r]
                    })]
                })
            });
            u.displayName = "CertificationCard";
            let p = (0, a.memo)(e => {
                let {
                    company: t,
                    role: i,
                    duration: a,
                    location: r,
                    type: s,
                    skills: o,
                    description: l
                } = e;
                return (0, n.jsxs)("div", {
                    className: "bg-zinc-900/40 hover:bg-zinc-800/40 transition-all p-4 md:p-6 rounded-lg  border border-zinc-800 hover:border-zinc-700",
                    children: [(0, n.jsx)("h3", {
                        className: "text-lg md:text-xl font-bold text-emerald-400",
                        children: i
                    }), (0, n.jsx)("p", {
                        className: "text-base md:text-lg text-gray-100 mb-2",
                        children: t
                    }), (0, n.jsxs)("div", {
                        className: "flex flex-wrap gap-2 text-xs md:text-sm text-gray-300 mb-3",
                        children: [(0, n.jsx)("span", {
                            children: s
                        }), (0, n.jsx)("span", {
                            children: "•"
                        }), (0, n.jsx)("span", {
                            children: a
                        }), (0, n.jsx)("span", {
                            children: "•"
                        }), (0, n.jsx)("span", {
                            children: r
                        })]
                    }), l && (0, n.jsx)("p", {
                        className: "text-gray-300 mb-3 text-sm md:text-base",
                        children: l
                    }), (0, n.jsx)("div", {
                        className: "flex flex-wrap gap-1.5 md:gap-2",
                        children: o.map(e => (0, n.jsx)("span", {
                            className: "text-xs md:text-sm bg-zinc-800/80 px-2 py-1 rounded-full  text-emerald-400",
                            children: e
                        }, e))
                    })]
                })
            });

            function g() {
                let [e, t] = (0, a.useState)(0), i = (0, a.useMemo)(() => ["intro", "experience", "skills", "education", "certifications"], []), [r, o] = (0, a.useState)(!1), l = (0, a.useRef)(Date.now()), c = (0, a.useRef)(null), d = (0, a.useRef)(0), m = (0, a.useCallback)(e => {
                    let n = Date.now();
                    if (!(n - l.current < 800) && e >= 0 && e < i.length && !r) {
                        o(!0), t(e), l.current = n;
                        let a = document.getElementById(i[e]);
                        a && a.scrollIntoView({
                            behavior: "smooth"
                        }), setTimeout(() => o(!1), 800)
                    }
                }, [r, i]);
                return (0, a.useEffect)(() => {
                    let t = t => {
                        "ArrowUp" === t.key ? (t.preventDefault(), m(e - 1)) : "ArrowDown" === t.key && (t.preventDefault(), m(e + 1))
                    };
                    return window.addEventListener("keydown", t), () => window.removeEventListener("keydown", t)
                }, [e, m]), (0, a.useEffect)(() => {
                    let t = t => {
                        t.preventDefault(), r || (d.current += t.deltaY, c.current && clearTimeout(c.current), c.current = setTimeout(() => {
                            Math.abs(d.current) > 50 && m(e + (d.current > 0 ? 1 : -1)), d.current = 0
                        }, 50))
                    };
                    return window.addEventListener("wheel", t, {
                        passive: !1
                    }), () => window.removeEventListener("wheel", t)
                }, [e, r, m]), (0, a.useEffect)(() => {
                    let t = 0,
                        i = 0,
                        n = e => {
                            t = e.touches[0].clientY, i = Date.now()
                        },
                        a = n => {
                            if (r) return;
                            let a = n.changedTouches[0].clientY,
                                s = Date.now() - i,
                                o = t - a;
                            s < 300 && Math.abs(o) > 50 && m(e + (o > 0 ? 1 : -1))
                        };
                    return window.addEventListener("touchstart", n, {
                        passive: !0
                    }), window.addEventListener("touchend", a, {
                        passive: !0
                    }), () => {
                        window.removeEventListener("touchstart", n), window.removeEventListener("touchend", a)
                    }
                }, [e, r, m]), (0, a.useEffect)(() => {
                    let e = e => e.preventDefault();
                    return document.body.style.overflow = "hidden", document.addEventListener("scroll", e, {
                        passive: !1
                    }), document.addEventListener("touchmove", e, {
                        passive: !1
                    }), () => {
                        document.body.style.overflow = "auto", document.removeEventListener("scroll", e), document.removeEventListener("touchmove", e)
                    }
                }, []), (0, n.jsxs)("div", {
                    className: "h-screen bg-black overflow-hidden",
                    children: [(0, n.jsx)("nav", {
                        className: "fixed left-8 top-1/2 -translate-y-1/2 z-50 space-y-6",
                        children: i.map((t, i) => (0, n.jsxs)("button", {
                            onClick: () => !r && m(i),
                            className: "group flex items-center gap-3",
                            children: [(0, n.jsx)("div", {
                                className: "w-2 h-2 rounded-full transition-all duration-300 \n              ".concat(e === i ? "bg-emerald-400 scale-150" : "bg-zinc-700")
                            }), (0, n.jsx)("span", {
                                className: "text-sm uppercase tracking-wider opacity-0 group-hover:opacity-100 \n              transition-opacity duration-300 ".concat(e === i ? "text-emerald-400" : "text-zinc-400"),
                                children: t
                            })]
                        }, t))
                    }), (0, n.jsx)("div", {
                        className: "h-screen overflow-hidden",
                        children: (0, n.jsxs)("div", {
                            className: "h-full transition-transform duration-800 ease-in-out",
                            style: {
                                transform: "translateY(-".concat(100 * e, "vh)"),
                                transition: "transform 0.8s cubic-bezier(0.645, 0.045, 0.355, 1)"
                            },
                            children: [(0, n.jsx)(s.P.section, {
                                id: "intro",
                                className: "h-screen flex items-center justify-center p-8",
                                initial: {
                                    opacity: 0
                                },
                                whileInView: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                children: (0, n.jsxs)("div", {
                                    className: "max-w-3xl",
                                    children: [(0, n.jsx)(s.P.h1, {
                                        className: "text-4xl md:text-6xl font-bold text-emerald-400 mb-6",
                                        initial: {
                                            y: 20
                                        },
                                        animate: {
                                            y: 0
                                        },
                                        children: "GHAZNAIN AHMAD"
                                    }), (0, n.jsx)("p", {
                                        className: "text-xl md:text-2xl text-zinc-300 leading-relaxed",
                                        children: "Dynamic Tech Specialist with expertise in Python Data Analysis, Full-Stack Web Development, and Generative AI. Proficient in AutoCAD (Mechanical & Architectural), C++, SEO Optimization, and MS Office. Adept at designing scalable web applications, data-driven insights, and automation solutions to drive efficiency and innovation."
                                    })]
                                })
                            }), (0, n.jsx)("section", {
                                id: "experience",
                                className: "h-screen flex items-center p-8",
                                children: (0, n.jsxs)("div", {
                                    className: "max-w-4xl mx-auto space-y-8",
                                    children: [(0, n.jsx)("h2", {
                                        className: "text-3xl font-bold text-emerald-400 mb-8",
                                        children: "Work Experience"
                                    }), (0, n.jsx)("div", {
                                        className: "grid gap-6",
                                        children: (0, n.jsxs)(s.P.div, {
                                            initial: {
                                                opacity: 0,
                                                y: 20
                                            },
                                            whileInView: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            transition: {
                                                staggerChildren: .2
                                            },
                                            children: [(0, n.jsx)(p, {
                                                company: "Benchmark | Innovative Engineering Solutions | Wadic",
                                                role: "AutoCAD Engineer (Mechanical & Architectural)",
                                                duration: "Jun 2024 - Present \xb7 3 mos",
                                                location: "Lahore, Punjab, Pakistan \xb7 On-site",
                                                type: "Full-time",
                                                skills: ["AutoCAD 2D & 3D", " Structural Design", " Plumbing & Drainage Systems", " Blueprint Drafting", " Technical Drawings"]
                                            }), (0, n.jsx)(p, {
                                                company: "Freelance | Remote",
                                                role: "Web Developer",
                                                duration: "Oct 2024 - Present \xb7 7 mos",
                                                location: "Lahore, Punjab, Pakistan \xb7 Remote",
                                                type: "Full-time",
                                                skills: ["Full-Stack Web Development (HTML, CSS, JavaScript, React, Next.js)", "SEO Optimization", "Website Performance Enhancement"]
                                            }), (0, n.jsx)(p, {
                                                company: "Freelance | Remote",
                                                role: "Data Analyst (Python Specialist)",
                                                duration: "Oct 2023 - May 2024 \xb7 3 mos",
                                                location: "San Jose, California, United States \xb7 Remote",
                                                type: "Freelance",
                                                description: "Data Analyst (Python Specialist) - Video Downsampling Integration for Testing Pipeline",
                                                skills: ["Video Production Python (Data Analytics, Pandas, NumPy)", "Data Cleaning", "Python", "Visualization (Matplotlib, Seaborn)", " MS Office"]
                                            }), (0, n.jsx)("div", {
                                                className: "bg-zinc-900/40 p-6 rounded-lg",
                                                children: (0, n.jsx)("p", {
                                                    className: "text-gray-200 text-center",
                                                    children: "Additionally, I have been working as a freelance developer since last year, building a strong portfolio and maintaining excellent client relationships across various projects."
                                                })
                                            })]
                                        })
                                    })]
                                })
                            }), (0, n.jsx)("section", {
                                id: "skills",
                                className: "h-screen flex items-center p-8",
                                children: (0, n.jsxs)("div", {
                                    className: "max-w-4xl mx-auto",
                                    children: [(0, n.jsx)("h2", {
                                        className: "text-3xl font-bold text-emerald-400 mb-8",
                                        children: "Skills"
                                    }), (0, n.jsx)(s.P.div, {
                                        className: "grid grid-cols-2 md:grid-cols-3 gap-4",
                                        initial: {
                                            opacity: 0
                                        },
                                        whileInView: {
                                            opacity: 1
                                        },
                                        transition: {
                                            staggerChildren: .1
                                        },
                                        children: h.map(e => (0, n.jsx)(s.P.div, {
                                            initial: {
                                                opacity: 0,
                                                scale: .9
                                            },
                                            whileInView: {
                                                opacity: 1,
                                                scale: 1
                                            },
                                            whileHover: {
                                                scale: 1.05
                                            },
                                            className: "bg-zinc-900/50 rounded-lg p-4 text-center",
                                            children: (0, n.jsx)("span", {
                                                className: "text-emerald-400",
                                                children: e
                                            })
                                        }, e))
                                    })]
                                })
                            }), (0, n.jsx)("section", {
                                id: "education",
                                className: "h-screen flex items-center p-8",
                                children: (0, n.jsxs)("div", {
                                    className: "max-w-4xl mx-auto",
                                    children: [(0, n.jsx)("h2", {
                                        className: "text-3xl font-bold text-emerald-400 mb-8",
                                        children: "Education"
                                    }), (0, n.jsxs)("div", {
                                        className: "space-y-8",
                                        children: [(0, n.jsx)(x, {
                                            title: "Bachlor's of Computer Science ",
                                            institution: "NCBA&E (National College of Business Administration & Economics), Lahore ",
                                            period: "2024 - 2028",
                                            details: "Computer Science | Full-Stack Development & AI, Software Development with Intelligent Systems, TensorFlow & Model Training"
                                        }), (0, n.jsx)(x, {
                                            title: "Intermediate in Computer Science (ICS)",
                                            institution: "GC University (GCU), Lahore",
                                            period: "2023 - 2024",
                                            details: "Web Development, Computer Programming, Database Management, Strong foundation in Programming, Mathematics, and Computer Applications",
                                            coursework: "Relevant Coursework: Web Development Techniques, Programming Languages: C++, Python (Basics),Concepts: Object-Oriented Programming (OOP), Logic Building"
                                        }), (0, n.jsx)(x, {
                                            title: "AutoCAD with Revit ",
                                            institution: "NAVTTC (National Vocational and Technical Training Commission)",
                                            period: "2023 - 2024",
                                            details: "2D & 3D Drafting (Civil & Mechanical),  Drainage & Water Supply System Designs, Structural & Architectural Drawings, Technical Drawings & Floor Plans",
                                            coursework: " AutoCAD Engineering (Civil & Mechanical) – 1 Year 2 Months (NAVTTC, LITE College, Mechanical Work Experience – 4 Months (Drainage & Water Supply Systems), Hands-on Training in Blueprint Reading & CAD Modeling,  Experience with Engineering Drawings & Construction Plans"
                                        })]
                                    })]
                                })
                            }), (0, n.jsx)("section", {
                                id: "certifications",
                                className: "h-screen flex items-center p-8",
                                children: (0, n.jsxs)("div", {
                                    className: "max-w-4xl mx-auto",
                                    children: [(0, n.jsx)("h2", {
                                        className: "text-3xl font-bold text-emerald-400 mb-8",
                                        children: "Certifications"
                                    }), (0, n.jsxs)(s.P.div, {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-6",
                                        initial: {
                                            opacity: 0
                                        },
                                        whileInView: {
                                            opacity: 1
                                        },
                                        transition: {
                                            staggerChildren: .2
                                        },
                                        children: [(0, n.jsx)(u, {
                                            title: "AutoCAD With Revit",
                                            issuer: "NAVTTC (National Vocational and Technical Training Commission)",
                                            location: "Lahore, Pakistan",
                                            year: "2024"
                                        }), (0, n.jsx)(u, {
                                            title: "Intermediate in Computer Science (ICS)",
                                            issuer: "BISE LAHORE",
                                            location: "Lahore, Pakistan",
                                            year: "2024"
                                        }), (0, n.jsx)("div", {
                                            className: "col-span-full text-center mt-4",
                                            children: (0, n.jsx)("p", {
                                                className: "text-gray-300 text-sm md:text-base",
                                                children: "+ 18 more professional certifications in various technical domains"
                                            })
                                        })]
                                    })]
                                })
                            })]
                        })
                    })]
                })
            }
            p.displayName = "ExperienceItem";
            let v = () => (0, n.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "32",
                    height: "32",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    children: (0, n.jsx)("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
                    })
                }),
                w = () => (0, n.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "32",
                    height: "32",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    children: (0, n.jsx)("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"
                    })
                }),
                f = () => (0, n.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "32",
                    height: "32",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    children: (0, n.jsx)("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                    })
                }),
                b = () => (0, n.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "32",
                    height: "32",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    children: (0, n.jsx)("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"
                    })
                });

            function j() {
                let [e, t] = (0, a.useState)(null), i = [{
                    id: 1,
                    title: "Architectural & Engineering Design Solutions",
                    description: "Providing innovative architectural, civil, and mechanical engineering solutions using AutoCAD and Revit",
                    icon: (0, n.jsx)(v, {}),
                    details: ["Custom architectural design solutions", "Civil engineering for site development and infrastructure", "Mechanical engineering focusing on water supply and drainage systems", "Proficient use of AutoCAD and Revit for precise designs", "Sustainable engineering solutions" ],
                    technologies: ["AutoCAD", "Revit", "GPT-4", "Civil engineering tools", "OpenAI API"]
                }, {
                    id: 2,
                    title: "Python Data Analysis Services",
                    description: "Transforming raw data into actionable insights using Python tools like Pandas, NumPy, and Matplotlib.",
                    icon: (0, n.jsx)(w, {}),
                    details: ["Data cleaning and preprocessing", "Data visualization using Matplotlib and Seaborn", "Statistical analysis and trend identification", "Advanced data manipulation with Pandas and NumPy", "Custom analytical solutions for business needs"],
                    technologies: ["Pandas", "NumPy", "Matplotlib", "Seaborn", "HuggingFace", "FastAI"]
                }, {
                    id: 3,
                    title: "Web Development Services",
                    description: "Creating dynamic, responsive, and user-friendly websites using HTML, CSS, JavaScript, PHP, Node.js, Python, and other modern technologies.",
                    icon: (0, n.jsx)(f, {}),
                    details: ["Custom website design and development", "Front-end and back-end development", "E-commerce and business website solutions", "Responsive web design for all devices", "Integration of advanced functionalities for user experience"],
                    technologies: ["HTML", "CSS", "JavaScript", "PHP", "Node.js", "Python", "FastAI"]
                }, {
                    id: 4,
                    title: "SEO Optimization Services",
                    description: "Providing comprehensive SEO optimization services, including keyword research, on-page & off-page optimization, and technical SEO to improve search engine rankings.",
                    icon: (0, n.jsx)(b, {}),
                    details: ["Keyword research and analysis", "On-page and off-page SEO optimization", "Technical SEO audits and improvements", "Content creation and strategy", "Backlink building and authority development", "Local SEO and international SEO strategies"],
                    technologies: ["Google Analytics", "Google Search Console", "SEMrush", "Ahrefs", "Moz"]
                }];
                return (0, n.jsx)(s.P.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    className: "w-full max-w-7xl mx-auto p-8 bg-gradient-to-b from-black/5 to-black/10",
                    children: (0, n.jsx)("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-8",
                        children: i.map(i => (0, n.jsxs)(s.P.div, {
                            whileHover: {
                                scale: 1.02,
                                transition: {
                                    duration: .3
                                }
                            },
                            className: "\n              relative overflow-hidden\n              ".concat(e === i.id ? "md:col-span-2" : "", "\n              bg-gradient-to-br from-white/10 via-white/5 to-transparent\n              backdrop-blur-xl rounded-3xl p-8\n              border border-white/20 hover:border-white/40\n              cursor-pointer\n              shadow-[0_8px_30px_rgb(255,255,255,0.1)]\n              hover:shadow-[0_8px_40px_rgb(255,255,255,0.2)]\n              transition-all duration-500\n            "),
                            onClick: () => t(e === i.id ? null : i.id),
                            children: [(0, n.jsx)("div", {
                                className: "absolute top-4 right-4",
                                children: (0, n.jsx)("span", {
                                    className: "text-white/60 text-sm flex items-center gap-2",
                                    children: e === i.id ? (0, n.jsxs)(n.Fragment, {
                                        children: [(0, n.jsx)("span", {
                                            children: "Close details"
                                        }), (0, n.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: [(0, n.jsx)("line", {
                                                x1: "18",
                                                y1: "6",
                                                x2: "6",
                                                y2: "18"
                                            }), (0, n.jsx)("line", {
                                                x1: "6",
                                                y1: "6",
                                                x2: "18",
                                                y2: "18"
                                            })]
                                        })]
                                    }) : (0, n.jsxs)(n.Fragment, {
                                        children: [(0, n.jsx)("span", {
                                            children: "Click for details"
                                        }), (0, n.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: [(0, n.jsx)("line", {
                                                x1: "12",
                                                y1: "5",
                                                x2: "12",
                                                y2: "19"
                                            }), (0, n.jsx)("line", {
                                                x1: "5",
                                                y1: "12",
                                                x2: "19",
                                                y2: "12"
                                            })]
                                        })]
                                    })
                                })
                            }), (0, n.jsxs)("div", {
                                className: "flex items-start gap-6",
                                children: [(0, n.jsx)("div", {
                                    className: "text-white hover:text-white/90 transition-colors",
                                    children: i.icon
                                }), (0, n.jsxs)("div", {
                                    className: "flex-1",
                                    children: [(0, n.jsx)("h3", {
                                        className: "text-2xl font-bold text-white mb-3 tracking-tight",
                                        children: i.title
                                    }), (0, n.jsx)("p", {
                                        className: "text-white/80",
                                        children: i.description
                                    }), (0, n.jsx)("a", {
                                        href: "mailto:ghaznain1122@gmail.com",
                                        className: "inline-block mt-2 px-4 py-2 bg-white/10 hover:bg-white/20  rounded-full text-sm text-white/90 border border-white/20  transition-all duration-300",
                                        children: "Get in Touch"
                                    }), e === i.id && (0, n.jsx)(s.P.div, {
                                        initial: {
                                            opacity: 0,
                                            height: 0
                                        },
                                        animate: {
                                            opacity: 1,
                                            height: "auto"
                                        },
                                        transition: {
                                            duration: .3
                                        },
                                        className: "mt-6",
                                        children: (0, n.jsxs)("div", {
                                            className: "grid md:grid-cols-2 gap-6",
                                            children: [(0, n.jsxs)("div", {
                                                children: [(0, n.jsx)("h4", {
                                                    className: "text-white/90 font-semibold mb-3 text-lg",
                                                    children: "Capabilities"
                                                }), (0, n.jsx)("ul", {
                                                    className: "list-disc list-inside text-white/80 space-y-2",
                                                    children: i.details.map((e, t) => (0, n.jsx)("li", {
                                                        className: "hover:text-white transition-colors",
                                                        children: e
                                                    }, t))
                                                })]
                                            }), (0, n.jsxs)("div", {
                                                children: [(0, n.jsx)("h4", {
                                                    className: "text-white/90 font-semibold mb-3 text-lg",
                                                    children: "Technologies"
                                                }), (0, n.jsx)("div", {
                                                    className: "flex flex-wrap gap-2",
                                                    children: i.technologies.map((e, t) => (0, n.jsx)("span", {
                                                        className: "px-4 py-1.5 bg-white/5 hover:bg-white/10 rounded-full  text-sm text-white/90 border border-white/10  transition-colors duration-300",
                                                        children: e
                                                    }, t))
                                                })]
                                            })]
                                        })
                                    })]
                                })]
                            })]
                        }, i.id))
                    })
                })
            }
            let y = [{
                name: "LinkedIn",
                url: "https://www.linkedin.com/in/ghaznain-ahmad/",
                icon: (0, n.jsx)("svg", {
                    className: "w-8 h-8",
                    viewBox: "0 0 24 24",
                    fill: "currentColor",
                    children: (0, n.jsx)("path", {
                        d: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
                    })
                }),
                backgroundColor: "bg-[#0077B5]"
            }, {
                name: "GitHub",
                url: "https://github.com/Xer0byte",
                icon: (0, n.jsx)("svg", {
                    className: "w-8 h-8",
                    viewBox: "0 0 24 24",
                    fill: "currentColor",
                    children: (0, n.jsx)("path", {
                        d: "M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"
                    })
                }),
                backgroundColor: "bg-[#333]"
            }, {
                name: "Upwork",
                url: "https://www.upwork.com/freelancers/~01f1d12759171916f1",
                icon: (0, n.jsx)("svg", {
                    className: "w-8 h-8",
                    viewBox: "0 0 24 24",
                    fill: "currentColor",
                    children: (0, n.jsx)("path", {
                        d: "M18.561 13.158c-1.102 0-2.135-.467-3.074-1.227l.228-1.076.008-.042c.207-1.143.849-3.06 2.839-3.06 1.492 0 2.703 1.212 2.703 2.703-.001 1.489-1.212 2.702-2.704 2.702zm0-8.14c-2.539 0-4.51 1.649-5.31 4.366-1.22-1.834-2.148-4.036-2.687-5.892H7.828v7.112c-.002 1.406-1.141 2.546-2.547 2.546-1.405 0-2.543-1.14-2.543-2.546V3.492H0v7.112c0 2.917 2.37 5.295 5.281 5.295s5.281-2.378 5.281-5.295v-1.19c.529 1.107 1.182 2.229 1.974 3.221l-1.673 7.873h2.797l1.213-5.71c1.063.679 2.285 1.109 3.688 1.109 3 0 5.439-2.452 5.439-5.45 0-3-2.439-5.439-5.439-5.439z"
                    })
                }),
                backgroundColor: "bg-[#6FDA44]"
            }, {
                name: "Email",
                url: "mailto:ghaznain1122@gmail.com",
                icon: (0, n.jsx)("svg", {
                    className: "w-8 h-8",
                    viewBox: "0 0 24 24",
                    fill: "currentColor",
                    children: (0, n.jsx)("path", {
                        d: "M12 12.713l11.985-7.99A1.5 1.5 0 0022.5 3h-21a1.5 1.5 0 00-1.485 1.723L12 12.713zM12 14.287L.015 6.297A1.5 1.5 0 000 7.5v9a1.5 1.5 0 001.5 1.5h21a1.5 1.5 0 001.5-1.5v-9a1.5 1.5 0 00-.015-.203L12 14.287z"
                    })
                }),
                backgroundColor: "bg-[#EA4335]"
            }];

            function N() {
                return (0, n.jsx)(s.P.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    className: "w-full max-w-4xl mx-auto p-8 text-white",
                    children: (0, n.jsxs)("div", {
                        className: "space-y-8",
                        children: [(0, n.jsxs)("header", {
                            className: "text-center mb-12",
                            children: [(0, n.jsx)("h1", {
                                className: "text-4xl font-bold mb-4",
                                children: "Let's Work Together"
                            }), (0, n.jsx)("p", {
                                className: "text-gray-300 text-lg",
                                children: "Connect with me on various platforms or hire me for your next project"
                            })]
                        }), (0, n.jsx)("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-6",
                            children: y.map(e => (0, n.jsxs)(s.P.a, {
                                href: e.url,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "".concat(e.backgroundColor, " p-6 rounded-lg flex items-center gap-4 hover:scale-105 transition-transform"),
                                whileHover: {
                                    y: -5
                                },
                                children: [(0, n.jsx)("span", {
                                    className: "text-4xl",
                                    children: e.icon
                                }), (0, n.jsxs)("div", {
                                    children: [(0, n.jsx)("h3", {
                                        className: "text-xl font-bold",
                                        children: e.name
                                    }), (0, n.jsxs)("p", {
                                        className: "text-sm text-white/80",
                                        children: ["Connect on ", e.name]
                                    })]
                                })]
                            }, e.name))
                        }), (0, n.jsxs)("div", {
                            className: "mt-12 text-center",
                            children: [(0, n.jsx)("p", {
                                className: "text-gray-300 mb-4",
                                children: "Looking for a dedicated developer for your project?"
                            }), (0, n.jsx)(s.P.a, {
                                href: "mailto:ghaznain1122@gmail.com",
                                className: "inline-block bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-white/90 transition-colors",
                                whileHover: {
                                    scale: 1.05
                                },
                                whileTap: {
                                    scale: .95
                                },
                                children: "Get in Touch"
                            })]
                        })]
                    })
                })
            }
            let k = () => (0, n.jsxs)("div", {
                className: "relative",
                children: [(0, n.jsx)("svg", {
                    style: {
                        position: "absolute",
                        width: 0,
                        height: 0
                    },
                    children: (0, n.jsx)("defs", {
                        children: (0, n.jsxs)("filter", {
                            id: "neuralNoise",
                            children: [(0, n.jsx)("feTurbulence", {
                                type: "fractalNoise",
                                baseFrequency: "0.01",
                                numOctaves: "3",
                                seed: "1",
                                children: (0, n.jsx)("animate", {
                                    attributeName: "baseFrequency",
                                    dur: "5s",
                                    values: "0.01;0.005;0.01",
                                    repeatCount: "indefinite"
                                })
                            }), (0, n.jsx)("feDisplacementMap", { in: "SourceGraphic",
                                scale: "5"
                            })]
                        })
                    })
                }), (0, n.jsx)("div", {
                    className: "flex justify-center",
                    children: "Xer0byte".split("").map((e, t) => (0, n.jsx)(s.P.span, {
                        className: "text-6xl font-bold inline-block neural-text",
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        animate: {
                            opacity: 1,
                            y: 0,
                            filter: ["brightness(1)", "brightness(1.5)", "brightness(1)"]
                        },
                        transition: {
                            duration: .5,
                            delay: .1 * t,
                            filter: {
                                duration: 2,
                                repeat: 1 / 0,
                                repeatType: "reverse"
                            }
                        },
                        children: e
                    }, t))
                })]
            });

            function M() {
                let [e, t] = (0, a.useState)(!1), [i, o] = (0, a.useState)("home");
                (0, a.useEffect)(() => {
                    t(!0)
                }, []);
                let c = t => {
                        e && ("hover" === t.type || "click" === t.type && o(t.section || "home"))
                    },
                    m = t => {
                        e && i !== t && (o(t), setTimeout(() => {
                            c({
                                type: "click",
                                section: t
                            })
                        }, 100))
                    };
                return e ? (0, n.jsxs)("div", {
                    className: "relative w-screen h-screen overflow-hidden luxury-gradient",
                    children: [(0, n.jsx)(l, {
                        activeSection: i,
                        onInteraction: c
                    }), (0, n.jsx)(r.N, {
                        mode: "wait",
                        initial: !1,
                        children: (0, n.jsxs)(s.P.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3
                            },
                            className: "absolute inset-0 flex items-center justify-center overflow-y-auto ".concat("home" !== i ? "backdrop-blur-md bg-black/30" : ""),
                            children: ["home" === i && (0, n.jsx)("div", {
                                className: "text-center text-white",
                                children: (0, n.jsx)(k, {})
                            }), "about" === i && (0, n.jsx)(g, {}), "projects" === i && (0, n.jsx)(d, {}), "services" === i && (0, n.jsx)(j, {}), "hire" === i && (0, n.jsx)(N, {})]
                        }, i)
                    }), (0, n.jsx)("div", {
                        className: "absolute bottom-2 right-3 text-white/70 text-sm",
                        children: (0, n.jsxs)("p", {
                            children: ["by", " ", (0, n.jsx)("a", {
                                href: "https://github.com/Xer0byte",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "hover:text-white transition-colors",
                                children: "Xer0byte"
                            })]
                        })
                    }), (0, n.jsx)("nav", {
                        className: "absolute bottom-8 left-1/2 transform -translate-x-1/2",
                        children: (0, n.jsx)("div", {
                            className: "flex gap-4 bg-black/20 backdrop-blur-sm px-6 py-3 rounded-full",
                            children: ["home", "about", "projects", "services", "hire"].map(e => (0, n.jsx)("button", {
                                onClick: () => m(e),
                                className: "px-4 py-2 rounded-full transition-colors ".concat(i === e ? "bg-white text-black" : "text-white"),
                                children: e.charAt(0).toUpperCase() + e.slice(1)
                            }, e))
                        })
                    })]
                }) : (0, n.jsx)("div", {
                    className: "relative w-screen h-screen overflow-hidden luxury-gradient",
                    children: (0, n.jsx)("div", {
                        className: "absolute inset-0 flex items-center justify-center",
                        children: (0, n.jsx)("div", {
                            className: "text-center text-white",
                            children: (0, n.jsx)(k, {})
                        })
                    })
                })
            }
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [450, 441, 517, 358], () => t(8972)), _N_E = e.O()
    }
]);